﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;
using LibrarySystemProject2.DAO;
using LibrarySystemProject2.Class;

namespace LibrarySystemProject2
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        Search_info getval = new Search_info();
        string authorinfosearch = "";
        
        protected void Page_Load(object sender, EventArgs e)
        {
           if (RadioButton1.Checked == true)
            {
                MultiView1.SetActiveView(View1);
            }
           else
            {
                MultiView1.SetActiveView(View2);
            }
        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (RadioButton1.Checked == true)
            {
                   MultiView1.SetActiveView(View1);
                   MultiView2.Visible = false;
            }
            
        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (RadioButton2.Checked == true)
            {
                MultiView1.SetActiveView(View2);
                MultiView2.Visible = false;
                
            }
        }


        void BinddataBooksearch()
        {
            MultiView2.Visible = true;
            MultiView2.SetActiveView(View3);
            string strConn;
            string sqlBooksearch = "";

            
                string bookinfodd = DropDownList1.SelectedItem.Value;
                string bookinfoinput = TextBox1.Text;
                strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

                SqlConnection Conn = new SqlConnection(strConn);
                Conn.Open();

                if (bookinfoinput == "")
                {
                    MultiView2.SetActiveView(View5);
                    Label14.Text = "Not found book search result !! , try again";
                }

                if (bookinfodd == "Author")
                {
                    sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                    sqlBooksearch += " FROM Book_Info, Author_Info";
                    sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                    sqlBooksearch += " AND (Author_Info.Author_name LIKE '%" + bookinfoinput + "%')";
                }
                else if (bookinfodd == "Title")
                {
                    sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                    sqlBooksearch += " FROM Book_Info, Author_Info";
                    sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                    sqlBooksearch += " AND (Book_Info.Title LIKE '%" + bookinfoinput + "%')";
                }
                else if (bookinfodd == "Subject")
                {
                    sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                    sqlBooksearch += " FROM Book_Info, Author_Info, Book_Subject";
                    sqlBooksearch += " WHERE (Book_Info.Booksubject_id=Book_Subject.Booksubject_id)";
                    sqlBooksearch += " AND (Book_Subject.Booksubject_name LIKE '%" + bookinfoinput + "%')";
                    sqlBooksearch += " AND (Author_Info.Author_id = Book_Info.Author_id)";
                }
                else if (bookinfodd == "Word")
                {
                    sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                    sqlBooksearch += " FROM Book_Info, Author_Info";
                    sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                    sqlBooksearch += " AND (Book_Info.Keyword LIKE '%" + bookinfoinput + "%')";
                }
                else if (bookinfodd == "Call Number")
                {
                    sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                    sqlBooksearch += " FROM Book_Info, Author_Info";
                    sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                    sqlBooksearch += " AND (Book_Info.Call_number LIKE '%" + bookinfoinput + "%')";
                }
                else if (bookinfodd == "ISBN")
                {
                    sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                    sqlBooksearch += " FROM Book_Info, Author_Info";
                    sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                    sqlBooksearch += " AND (Book_Info.ISBN LIKE '%" + bookinfoinput + "%')";
                }

                SqlDataAdapter da = new SqlDataAdapter(sqlBooksearch, Conn);

                DataSet ds = new DataSet();
            
            try
            {
                da.Fill(ds, "BookSearch");
            }
            
            catch (Exception)
            {
                MultiView2.SetActiveView(View5);
                Label14.Text = "Not found book search result !! , try again";

            }

            
            GridView1.DataSource = ds.Tables["BookSearch"];
            GridView1.DataBind();
            Label18.Text = "Search book information result : " + bookinfodd + " : " +bookinfoinput+"";
            
            if (GridView1.Rows.Count == 0)
            {
                MultiView2.SetActiveView(View5);
                Label14.Text = "Not found book search result !! , try again";
            }
            
            
        }
        protected void Button1_Click(object sender, EventArgs e)
        {

            BinddataBooksearch();


        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BinddataBooksearch();
        }

        

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string titletext, authortext;
            //LinkButton titletextb = GridView1.SelectedRow.FindControl("LinkButton1") as LinkButton;

            authortext = GridView1.SelectedRow.Cells[2].Text;
            titletext = GridView1.SelectedRow.Cells[1].Text;
            Session["titletext"] = titletext;
            Session["authortext"] = authortext;
            //Server.Transfer("search_info2.aspx");
            Response.Redirect("search_info2.aspx");
            Session.Timeout = 5;
            //Response.Write("<script>window.open('search_info2.aspx','_blank')</script>"); 
            
        }
        
        void BinddataMembersearch()
        {
            MultiView2.Visible = true;
            MultiView2.SetActiveView(View4);
            string strConn = "";
            string sqlMembersearch = "";
            string sqlMemberDetailGridview = "";

            string SqlMemberFine = "";
            string SqlMemberFine2 = "";
            int Allfine = 0;
            DateTime calfinedate;
            int finalFine = 0;
            int all_fine_remain = 0;
            DateTime today;

            
                string memberinfodd = DropDownList2.SelectedItem.Value;
                string memberinfoinput = TextBox2.Text;
                strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

                SqlConnection Conn = new SqlConnection(strConn);
                Conn.Open();

                if (memberinfodd == "Student ID")
                {
                    sqlMembersearch = "SELECT Member_id, Member_type.Membertype_name, Name, Department.Department_name, Student_id, Email, Create_date, Phone_number, Expire_date, Mobile_number, Address, Image";
                    sqlMembersearch += " FROM Member_Info, Member_Type, Department";
                    sqlMembersearch += " WHERE (Student_id='" + TextBox2.Text + "')";
                    sqlMembersearch += " AND (Member_Info.Membertype_id=Member_type.MemberType_id)";
                    sqlMembersearch += " AND (Member_Info.Department_id=Department.Department_id)";
                }
                else if (memberinfodd == "Member ID")
                {
                    sqlMembersearch = "SELECT Member_id, Member_type.Membertype_name, Name, Department.Department_name, Student_id, Email, Create_date, Phone_number, Expire_date, Mobile_number, Address, Image";
                    sqlMembersearch += " FROM Member_Info, Member_Type, Department";
                    sqlMembersearch += " WHERE (Member_id='" + TextBox2.Text + "')";
                    sqlMembersearch += " AND (Member_Info.Membertype_id=Member_type.MemberType_id)";
                    sqlMembersearch += " AND (Member_Info.Department_id=Department.Department_id)";
                }
                else if (memberinfodd == "Member name")
                {
                    sqlMembersearch = "SELECT Member_id, Member_type.Membertype_name, Name, Department.Department_name, Student_id, Email, Create_date, Phone_number, Expire_date, Mobile_number, Address, Image";
                    sqlMembersearch += " FROM Member_Info, Member_Type, Department";
                    sqlMembersearch += " WHERE (name='" + TextBox2.Text + "')";
                    sqlMembersearch += " AND (Member_Info.Membertype_id=Member_type.MemberType_id)";
                    sqlMembersearch += " AND (Member_Info.Department_id=Department.Department_id)";
                }


                SqlDataAdapter da = new SqlDataAdapter(sqlMembersearch, Conn);
                DataTable dt = new DataTable();
                try
                {

                    da.Fill(dt);
                }
                catch (Exception)
                {
                    MultiView2.SetActiveView(View5);
                    Label14.Text = "Not found member search result !! , try again";

                }

                if (dt.Rows.Count > 0 && dt.Rows.Count <= 1)
                {
                    MultiView2.SetActiveView(View4);
                    Image1.ImageUrl = "MemberPic/" + (string)dt.Rows[0]["Image"];
                    Label2.Text = Convert.ToString(dt.Rows[0]["Member_id"]);
                    Label3.Text = (string)dt.Rows[0]["Membertype_name"];
                    Label4.Text = (string)dt.Rows[0]["Name"];
                    Label5.Text = (string)dt.Rows[0]["Department_name"];
                    Label6.Text = Convert.ToString(dt.Rows[0]["Student_id"]);
                    Label7.Text = (string)dt.Rows[0]["Email"];
                    Label8.Text = Convert.ToString(dt.Rows[0]["Create_date"]);
                    Label9.Text = (string)dt.Rows[0]["Phone_number"];
                    Label10.Text = Convert.ToString(dt.Rows[0]["Expire_date"]);
                    Label11.Text = (string)dt.Rows[0]["Mobile_number"];
                    Label12.Text = (string)dt.Rows[0]["Address"];

                }
                else
                {
                    MultiView2.SetActiveView(View5);
                    Label14.Text = "Not found member search result !! , try again";
                }

                sqlMemberDetailGridview = "SELECT Book_Info.Register_number, Book_Info.Call_number, Book_Info.Title, Book_Info.Date_return";
                sqlMemberDetailGridview += " FROM Book_Info, Book_Status";
                sqlMemberDetailGridview += " WHERE Member_id=" + Label2.Text + " AND Book_Status.Bookstatus_name = 'Borrowed' AND Book_Info.Bookstatus_id = Book_Status.Bookstatus_id";


                try
                {
                    SqlDataAdapter da2 = new SqlDataAdapter(sqlMemberDetailGridview, Conn);
                    DataSet ds = new DataSet();
                    da2.Fill(ds, "MemberDetailSearch");
                    GridView2.DataSource = ds.Tables["MemberDetailSearch"];
                    GridView2.DataBind();
                    Label15.Text = "";
                    
                }
                catch (Exception) 
                {
                    Label15.Text = "Not found member borrow record !";
                }
                if (GridView2.Rows.Count == 0)
                {
                    Label15.Text = "Not found member borrow record !";
                }


                //show book fine of overdue
                SqlMemberFine = "SELECT Date_return FROM History WHERE Member_id='" + Label2.Text + "' AND Date_return_actual IS NULL ";
                SqlMemberFine2 = "SELECT Fine FROM History WHERE Member_id='" + Label2.Text + "' AND Fine_pay = 'false'";

                SqlDataAdapter da3 = new SqlDataAdapter(SqlMemberFine, Conn);
                DataTable dt3 = new DataTable();
                try
                {

                    da3.Fill(dt3);
                }
                catch (Exception)
                {
                    Label13.Text = "Can't calculate all fine";
                }

                if (dt3.Rows.Count > 0)
                {

                    for (int i = 0;i < dt3.Rows.Count; i++)
                    {
                        today = System.DateTime.Today.Date;
                        string finedate = Convert.ToString(dt3.Rows[i]["Date_return"]);
                        calfinedate = Convert.ToDateTime(finedate);

                        if (today > calfinedate)
                        {
                            Allfine = today.Subtract(calfinedate).Days;
                            Allfine = Allfine * 5;
                            finalFine += Allfine;
                        }
                        else
                        {
                            Allfine = 0;
                            finalFine += Allfine;
                        }
                    }
                }

                else
                {
                    Label13.Text = "Can't calculate all fine2"; 
                }

                Label13.Text = "" + finalFine + " บาท";  //ค่าปรับคืนเกินเวลา



                //show book fine of arrears
                SqlMemberFine2 = "SELECT Fine FROM History WHERE Member_id='" + Label2.Text + "' AND Fine_pay = 'false'";
                SqlDataAdapter da4 = new SqlDataAdapter(SqlMemberFine2, Conn);
                DataTable dt4 = new DataTable();
                try
                {

                    da4.Fill(dt4);
                }
                catch (Exception)
                {
                    Label16.Text = "Can't calculate all fine";
                }

                if (dt4.Rows.Count > 0)
                {

                    for (int i = 0; i < dt4.Rows.Count; i++)
                    {
                        int fine_remain = Convert.ToInt16(dt4.Rows[i]["Fine"]);
                        all_fine_remain += fine_remain;
                    }
                }

                else
                {
                    Label16.Text = "Can't calculate all fine2";
                }
                Label16.Text = "" + all_fine_remain + " บาท";  //ค่าปรับค้างจ่าย


                Label17.Text = "" + (finalFine + all_fine_remain) + " บาท";  //ค่าปรับทั้งหมด
            Conn.Close();


            
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            BinddataMembersearch();
            
        }

        protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView2.PageIndex = e.NewPageIndex;
            BinddataMembersearch();
        }

        



        protected void authorlink()
        {
            
            MultiView2.Visible = true;
            MultiView2.SetActiveView(View6);
            string sqlauthorsearch = "";
            string strConn = "";
            strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();

            sqlauthorsearch = "SELECT Title, Author_Info.Author_name";
            sqlauthorsearch += " FROM Book_Info, Author_Info";
            sqlauthorsearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
            sqlauthorsearch += " AND (Author_Info.Author_name = '" + authorinfosearch + "')";

            SqlDataAdapter da = new SqlDataAdapter(sqlauthorsearch, Conn);

            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds, "AuthorSearch");
            }

            catch (Exception)
            {
                Label19.Text = "Not found book search result !! , try again";
            }


            GridView3.DataSource = ds.Tables["AuthorSearch"];
            GridView3.DataBind();
            Label19.Text = "Search author information result : " + authorinfosearch;
        }



        /*
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            string testread = "";
            //LinkButton titletextb = GridView1.SelectedRow.FindControl("LinkButton1") as LinkButton;
            //authorinfosearch = GridView1.SelectedRow.Cells[2].Text;
            if (GridView1.SelectedRow.Cells[2].Text != null)
            {
                testread = GridView1.SelectedRow.Cells[2].Text;
                Label19.Text = testread;
            }
            //Label18.Text = "" + GridView1.Rows.Count;
            if (GridView1.FindControl("LinkButton1") != null)
            {

                    LinkButton titletextb = GridView1.SelectedRow.FindControl("LinkButton1") as LinkButton;
                    authorinfosearch = titletextb.Text;
                    
            }
            authorlink();
            
            
        }
        */

       

    }
}
