﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace LibrarySystemProject2
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login1_Authenticate1(object sender, AuthenticateEventArgs e)
        {
            string username = Login1.UserName;
            string pwd = Login1.Password;

            string strConn;
            strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();

            string sqlUserName;
            sqlUserName = "SELECT Username,Password , User_id FROM UserInfo ";
            sqlUserName += " WHERE (Username = @Username";
            sqlUserName += " AND Password = @Password)";


            SqlCommand com = new SqlCommand(sqlUserName, Conn);
            com.Parameters.AddWithValue("@Username", username);
            com.Parameters.AddWithValue("@Password", pwd);



            string CurrentName;
            CurrentName = (string)com.ExecuteScalar();

            if (CurrentName != null)
            {
                Session["UserAuthentication"] = username;
                //Session["User_id"] = username;
                Session.Timeout = 5;
                Response.Redirect("index.aspx");

            }
            else
            {
                Session["UserAuthentication"] = "";
            }
        }

        
    }
}
