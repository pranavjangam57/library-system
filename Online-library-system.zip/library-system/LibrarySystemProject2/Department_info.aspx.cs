﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Xml.Linq;
using CAMT;
using System.Data.SqlClient;
using System.Web.Configuration;
using LibrarySystemProject2.Class;
using LibrarySystemProject2.DAO;
using System.Web.UI.WebControls;

namespace LibrarySystemProject2
{
    public partial class WebForm21 : System.Web.UI.Page
    {
        SqlConnection objConn;
        SqlCommand objCmd;
        String strSQL;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();
        String strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

            objConn = new SqlConnection(strConnString);
            objConn.Open();

            if (!Page.IsPostBack)
            {
                BindData();
            }
        }
        protected void Add_Click(object sender, EventArgs e)
        {
            Department department = new Department();
            DepartmentDAO departmentDAO = new DepartmentDAO();

            department.setDepartmentName(departmentBox.Text.ToString());
            departmentDAO.addDepartment(department);
            text.Text = departmentDAO.getMessage();
            BindData();
            //Response.Redirect("Department_info.aspx");
        }
        protected void BindData()
        {
            String strSQL;
            strSQL = "SELECT * FROM Department";
            
            SqlConnection objConn = new SqlConnection(strConnString);
            SqlCommand objCmd = new SqlCommand();
            SqlDataAdapter dtAdapter = new SqlDataAdapter();

            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;


            dtAdapter.SelectCommand = objCmd;
            try
            {

                dtAdapter.Fill(ds);
               
            }
            catch (Exception ex)
            {
                text.Text = "Can't show data";
            }
                myGridView.DataSource = ds;
                myGridView.AllowPaging = true;
                myGridView.DataBind();
            dtAdapter = null;
            objConn.Close();
            objConn = null;

        }

        protected void Page_UnLoad()
        {
            objConn.Close();
            objConn = null;
        }

        protected void EditCommand(object sender, GridViewEditEventArgs e)
        {
            myGridView.EditIndex = e.NewEditIndex;
            myGridView.ShowFooter = false;
            BindData();
        }

        protected void modCancelCommand(object sender, GridViewCancelEditEventArgs e)
        {
            myGridView.EditIndex = -1;
            myGridView.ShowFooter = false;
            BindData();
        }

        protected void modDeleteCommand(object sender, GridViewDeleteEventArgs e)
        {
            strSQL = "DELETE FROM Department WHERE Department_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";
            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                text.Text = "Delete department successful";
            }
            catch (Exception ex)
            {
                text.Text = "Cannot delete this department name";
            }

            myGridView.EditIndex = -1;
            BindData();
        }

        protected void modUpdateCommand(object sender, GridViewUpdateEventArgs e)
        {
            TextBox txtName = (TextBox)myGridView.Rows[e.RowIndex].FindControl("txtEditDpName");

            strSQL = "UPDATE Department SET Department_name = '" + txtName.Text + "'WHERE Department_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";

            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                text.Text = "Update department successful";
                //Response.Write(txtName.Text);
            }
            catch (Exception ex)
            {
                text.Text = "Cannot update this department name";
            }


            myGridView.EditIndex = -1;
            myGridView.ShowFooter = false;
            BindData();
        }
        protected void myGridView_RowDataBound(Object s, GridViewRowEventArgs e)
        {
            string totalRecord = this.myGridView.Rows.Count.ToString();
            int totalRows = Convert.ToInt16(totalRecord) + 1;
            Label No = (Label)(e.Row.FindControl("No"));

            if (No != null)
            {
                No.Text = "" + totalRows + "";
            }


        }
        protected void ShowPageCommand(Object s, GridViewPageEventArgs e)
        {
            myGridView.PageIndex = e.NewPageIndex;
            BindData();
        }
    }
}
