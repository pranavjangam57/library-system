﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;
using CAMT;
using LibrarySystemProject2.Class;
using LibrarySystemProject2.DAO;
using System.Globalization;

namespace LibrarySystemProject2
{
    public partial class Book_edit : System.Web.UI.Page
    {
        SqlConnection objConn;
        SqlCommand objCmd;
        String strSQL;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();
        String strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
        string str;

        
        protected void Page_Load(object sender, EventArgs e)
        {

            objConn = new SqlConnection(strConnString);
            objConn.Open();
            if (!Page.IsPostBack)
            {
                Show_panel.Visible = false;
                Edit_panel.Visible = false;
                buttom.Visible = false;
                head.Visible = false;
                Tabhide.Visible = true;
                Tabshow.Visible = true;
                Message.Visible = false;
                Bs_id.Visible = false;
                Book_id.Visible = false;
                At_id.Visible = false;
                DateTime test = new DateTime(2010,11,8);
                DateTime t2 = new DateTime(2010, 8, 5);
                TimeSpan diffTime = DateTime.Today.Subtract(t2);
                //Response.Write(diffTime.Days*5);
                
            }
            //Tabhide.Click += new EventHandler(Tabhide_Click);
            //Tabshow.Click += new EventHandler(Tabshow_Click);
            //Submit.Click += new EventHandler(Submit_Click);
            //UpdateProgress1.DisplayAfter = 100;
            //UpdateProgress1.Visible = true;
           // UpdateProgress1.DynamicLayout = true;
            
            
        }

        protected void BindData()
        {
            if (selectList.SelectedValue == "Author")
            {
                strSQL = "SELECT Book_id,Title, Author_Info.Author_name";
                strSQL += " FROM Book_Info, Author_Info";
                strSQL += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                strSQL += " AND (Author_Info.Author_name LIKE '%" + this.searchBox.Text + "%')";
            }
            else if (selectList.SelectedValue == "Subject")
            {
                strSQL = "SELECT Book_id,Title, Author_Info.Author_name";
                strSQL += " FROM Book_Info, Author_Info, Book_Subject";
                strSQL += " WHERE (Book_Info.Booksubject_id=Book_Subject.Booksubject_id)";
                strSQL += " AND (Book_Subject.Booksubject_name LIKE '%" + this.searchBox.Text + "%')";
                strSQL += " AND (Author_Info.Author_id = Book_Info.Author_id)";
            }
            else if (selectList.SelectedValue == "Title")
            {
                strSQL = "SELECT Book_id,Title, Author_Info.Author_name";
                strSQL += " FROM Book_Info, Author_Info";
                strSQL += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                strSQL += " AND (Book_Info.Title LIKE '%" + this.searchBox.Text + "%')";
            }
            else if (selectList.SelectedValue == "Keyword")
            {
                strSQL = "SELECT Book_id,Title, Author_Info.Author_name";
                strSQL += " FROM Book_Info, Author_Info";
                strSQL += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                strSQL += " AND (Book_Info.Keyword LIKE '%" + this.searchBox.Text + "%')";
            }
            else if (selectList.SelectedValue == "Call_number")
            {
                strSQL = "SELECT Book_id,Title, Author_Info.Author_name";
                strSQL += " FROM Book_Info, Author_Info";
                strSQL += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                strSQL += " AND (Book_Info.Call_number LIKE '%" + this.searchBox.Text + "%')";
            }
            else if (selectList.SelectedValue == "ISBN")
            {
                strSQL = "SELECT Book_id,Title, Author_Info.Author_name";
                strSQL += " FROM Book_Info, Author_Info";
                strSQL += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                strSQL += " AND (Book_Info.ISBN LIKE '%" + this.searchBox.Text + "%')";
            }

            SqlConnection objConn = new SqlConnection(strConnString);
            SqlCommand objCmd = new SqlCommand();
            SqlDataAdapter dtAdapter = new SqlDataAdapter();

            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;


            dtAdapter.SelectCommand = objCmd;

            dtAdapter.Fill(ds);

            //*** BindData to GridView ***//
            searchView.DataSource = ds;
            searchView.AllowPaging = true;
            searchView.DataBind();
            if (searchView.Rows.Count == 0 || this.searchBox.Text == "")
            {
                message2.Text = "Not found book information";
                Show_panel.Visible = false;
                Edit_panel.Visible = false;
                buttom.Visible = false;
                head.Visible = false;
            }
            dtAdapter = null;
            objConn.Close();
            objConn = null;
            
        }

        protected void searchView_RowDataBound(Object s, GridViewRowEventArgs e)
        {
            string totalRecord = this.searchView.Rows.Count.ToString();
            int totalRows = Convert.ToInt16(totalRecord) + 1;
            //*** No. ***//
            Label No = (Label)(e.Row.FindControl("No"));

            if (No != null)
            {
                No.Text = "" + totalRows + "";
            }

            Label Name = (Label)(e.Row.FindControl("Name"));
            HyperLink detail = (HyperLink)(e.Row.FindControl("Detail"));
            if(Name != null)
            {
                Name.Text = (string)DataBinder.Eval(e.Row.DataItem, "Title");
                //detail.Text = "Detail...";
                //detail.NavigateUrl = "Member_edit.aspx?ID=" + Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "Book_id"));
            }
            Label Author = (Label)(e.Row.FindControl("Author")); ;
            if(Author != null)
            {
                Author.Text = Convert.ToString( DataBinder.Eval(e.Row.DataItem, "Author_name"));
            }
            Label book_id = (Label)(e.Row.FindControl("Book_id"));
            if (book_id != null)
            {
                book_id.Text = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "Book_id")).ToString();
            }
            
        }
        protected void ShowPageCommand(Object s, GridViewPageEventArgs e)
        {
            searchView.PageIndex = e.NewPageIndex;
            BindData();
        }

        protected void Search_Click(object sender, EventArgs e)
        {
            //System.Threading.Thread.Sleep(300); //ของหน่วงเวลาจะได้เห็น
            message2.Text = "";
            Show_panel.Visible = true;
            Edit_panel.Visible = false;
            buttom.Visible = true;
            head.Visible = true;
            Message.Visible = false;
            BindData();
        }

        protected void searchView_SelectedIndexChanged(object sender, EventArgs e)
        {
            Edit_panel.Visible = true;
            var selectedRow = searchView.SelectedRow.FindControl("Book_id");
            str = ((Label)selectedRow).Text;
            // handle the vent of select command
 
            Show_panel.Visible = false;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            //*** DataTable ***//
            SqlDataAdapter dtAdapter;
            DataTable dt = new DataTable();
            strSQL = "SELECT * FROM Book_Info WHERE Book_id = '" + Convert.ToInt32(str) + "'";
            dtAdapter = new SqlDataAdapter(strSQL, objConn);
            dtAdapter.Fill(dt);
            
            if (dt.Rows.Count > 0 && dt.Rows.Count <= 1)
            {
                string time = DateTime.Parse(dt.Rows[0]["Date_import"].ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                string t2 = DateTime.Parse(dt.Rows[0]["Date_import"].ToString()).ToString("yyyy/MM/dd", new CultureInfo("en-US"));
                string today = DateTime.Parse(DateTime.Today.ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));

                this.Bs_id.Text = Convert.ToString(dt.Rows[0]["Booksubject_id"]);
                this.Book_id.Text = Convert.ToString(dt.Rows[0]["Book_id"]);
                this.At_id.Text = Convert.ToString(dt.Rows[0]["Author_id"]);
                this.TitleInput.Text = (string)dt.Rows[0]["Title"];
                this.Callnumber.Text = Convert.ToString(dt.Rows[0]["Call_number"]);
                this.RegisterNumber.Text = (string)dt.Rows[0]["Register_number"];
                this.BookType.SelectedValue = Convert.ToString(dt.Rows[0]["Booktype_id"]);
                this.AuthorList.SelectedValue = Convert.ToString(dt.Rows[0]["Author_id"]);
                this.PageInput.Text = Convert.ToString(dt.Rows[0]["Page"]);
                this.Volume.Text = Convert.ToString(dt.Rows[0]["Volume"]);
                this.Series.Text = Convert.ToString(dt.Rows[0]["Series"]);
                this.DateImport.Text = time;
                this.Year.Text = Convert.ToString(dt.Rows[0]["Year"]); 
                this.Edition.Text = Convert.ToString(dt.Rows[0]["Edition"]);
                this.Publisher.Text = Convert.ToString(dt.Rows[0]["Publisher"]);
                this.PublisherLocation.Text = Convert.ToString(dt.Rows[0]["Publisher_location"]);
                this.ISBN.Text = Convert.ToString(dt.Rows[0]["ISBN"]);
                this.Note.Text = Convert.ToString(dt.Rows[0]["Note"]);
                this.Keyword.Text = Convert.ToString(dt.Rows[0]["Keyword"]);
                this.BookStatus.SelectedValue = Convert.ToString(dt.Rows[0]["Bookstatus_id"]);
                this.Location.SelectedValue = Convert.ToString(dt.Rows[0]["Location"]);
                this.BookCopy.Text = Convert.ToString(dt.Rows[0]["Book_copy"]);
                this.Source.SelectedItem.Value = Convert.ToString(dt.Rows[0]["Source"]);
                this.BookSubject.SelectedValue = Convert.ToString(dt.Rows[0]["Booksubject_id"]);
                At_id.Text = Convert.ToDateTime(today).Subtract(Convert.ToDateTime(time)).Days.ToString();
            }
            else
            {
                Show_panel.Visible = false;
                Book_id.Visible = true;
                Book_id.Text = "Not found this book information";
            }
            objConn.Close();
            objConn = null;
        
        }
        protected void NewAuthor_bt_CheckedChanged(object sender, EventArgs e)
        {
            //System.Threading.Thread.Sleep(300); //ของหน่วงเวลาจะได้เห็น
            if ((NewAuthor_bt.Checked == true))
            {
                NewAuthor.Enabled = true;
                AuthorList.Enabled = false;
            }
        }

        protected void SelectAuthor_bt_CheckedChanged(object sender, EventArgs e)
        {
            //System.Threading.Thread.Sleep(300); //ของหน่วงเวลาจะได้เห็น
            if ((SelectAuthor_bt.Checked == true))
            {
                AuthorList.Enabled = true;
                NewAuthor.Enabled = false;
            }
        }

        protected void Newsubject_bt_CheckedChanged(object sender, EventArgs e)
        {
            //System.Threading.Thread.Sleep(300); //ของหน่วงเวลาจะได้เห็น
            if ((Newsubject_bt.Checked == true))
            {
                NewSubject.Enabled = true;
                BookSubject.Enabled = false;
            }
        }

        protected void Selectsubject_bt_CheckedChanged(object sender, EventArgs e)
        {
            //System.Threading.Thread.Sleep(300); //ของหน่วงเวลาจะได้เห็น
            if ((Selectsubject_bt.Checked == true))
            {
                NewSubject.Enabled = false;
                BookSubject.Enabled = true;
            }
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            //System.Threading.Thread.Sleep(300); //ของหน่วงเวลาจะได้เห็น
            BookInfo book = new BookInfo();
            BookInfoDAO bookInfo = new BookInfoDAO();
            AuthorInfo author = new AuthorInfo();
            AuthorInfoDAO authorDAO = new AuthorInfoDAO();
            BooksubjectInfo booksubject = new BooksubjectInfo();
            BooksubjectInfoDAO booksubjectDAO = new BooksubjectInfoDAO();

            
            if ((NewAuthor_bt.Checked == true))
            {
               /* author.setAuthorName(NewAuthor.Text);
                book.setAuthorID(author.getMaxID());
                authorDAO.addNewAuthor(author);
                author.setOldAuthorID(Convert.ToInt32(At_id.Text));
                author.setOldAuthoBookTotal(Convert.ToInt32(At_id.Text));
                authorDAO.upDateOldBookTotal(author, book);*/
            }
             
            if ((SelectAuthor_bt.Checked == true))
            {
                
                if(AuthorList.SelectedValue != At_id.Text)
                {
                    book.setAuthorID(Convert.ToInt32(AuthorList.SelectedValue));
                    author.setOldAuthorID(Convert.ToInt32(At_id.Text));
                    author.setOldAuthoBookTotal(Convert.ToInt32(At_id.Text));
                    author.setBookTotal(AuthorList.SelectedValue);
                    authorDAO.upDateBookTotal(author, book);
                    authorDAO.upDateOldBookTotal(author,book);
                }
                else if (AuthorList.SelectedValue == At_id.Text)
                {
                    book.setAuthorID(Convert.ToInt32(AuthorList.SelectedValue));
                }
            }
            
            if ((Newsubject_bt.Checked == true))
            {
                book.setBookSubjectID(booksubject.getMaxID());
                booksubject.setBooksubjectName(NewSubject.Text);
                booksubjectDAO.addNewBookSubject(booksubject);
                book.setOldBooksubjectID(Convert.ToInt32(Bs_id.Text));
                book.setOldBooksubjectTotal(Convert.ToInt32(Bs_id.Text));
                booksubjectDAO.upDateOldBookTotal(booksubject, book);
            }
            
            
            if ((Selectsubject_bt.Checked == true))
            {
                
                
                if(BookSubject.SelectedValue != Bs_id.Text)
                {
                    book.setBookSubjectID(Convert.ToInt32(BookSubject.SelectedValue));
                    book.setOldBooksubjectID(Convert.ToInt32(Bs_id.Text));
                    book.setOldBooksubjectTotal(Convert.ToInt32(Bs_id.Text));
                    booksubjectDAO.upDateOldBookTotal(booksubject,book);
                    booksubject.setBookTotal(BookSubject.SelectedValue);
                    booksubjectDAO.upDateBookTotal(booksubject, book);
                }
                else if (BookSubject.SelectedValue == Bs_id.Text)
                {
                    book.setBookSubjectID(Convert.ToInt32(BookSubject.SelectedValue));
                }

            }
                book.setBookID(Book_id.Text);
                book.setBookCopy(Convert.ToInt32(BookCopy.Text));
                book.setBookStatusID(Convert.ToInt32(BookStatus.SelectedValue));
                book.setBookTypeID(Convert.ToInt32(BookType.SelectedValue));
                book.setCallNumber(Callnumber.Text);
                book.setDateImport(Convert.ToDateTime(DateImport.Text));
                book.setEdition(Convert.ToInt32(Edition.Text));
                book.setISBN(ISBN.Text.ToString());
                book.setKeyword(Keyword.Text.ToString());
                book.setLocation(Location.SelectedItem.Text.ToString());
                book.setNote(Note.Text.ToString());
                book.setPage(Convert.ToInt32(PageInput.Text));
                book.setPublisher(Publisher.Text.ToString());
                book.setPublisherLocation(PublisherLocation.Text.ToString());
                book.setRegisterNumber(RegisterNumber.Text.ToString());
                book.setSeries(Series.Text.ToString());
                book.setSource(Source.SelectedValue.ToString());
                book.setTitle(TitleInput.Text.ToString());
                book.setVolume(Convert.ToInt32(Volume.Text));
                book.setYear(Year.Text.ToString());

                bookInfo.editBook(book);
                Message.Visible = true;
                
                //Label3.Text = bookInfo.getMessage()+" from booksubject "+booksubjectDAO.getMessage();
                //Response.Write(book.getOldBooksubjectID()+"  "+book.getOldBooksubjectTotal());
               
                Show_panel.Visible = false;
                Edit_panel.Visible = true;
                Message.Text = bookInfo.getMessage();
                
        }

        protected void Tabshow_Click(object sender, EventArgs e)
        {
            //System.Threading.Thread.Sleep(300); //ของหน่วงเวลาจะได้เห็น
            Show_panel.Visible = true;
            //Tabhide.Visible = true;
            //Tabshow.Visible = false;
        }

        protected void Tabhide_Click(object sender, EventArgs e)
        {
            //System.Threading.Thread.Sleep(300); //ของหน่วงเวลาจะได้เห็น
            Show_panel.Visible = false;
            //Tabhide.Visible = false;
            //Tabshow.Visible = true;
        }
        
    }
}
