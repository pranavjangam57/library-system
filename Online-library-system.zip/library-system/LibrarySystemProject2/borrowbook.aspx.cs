﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using LibrarySystemProject2.Class;
using LibrarySystemProject2.DAO;

namespace LibrarySystemProject2
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        SqlConnection objConn = new SqlConnection();
        SqlCommand objCmd = new SqlCommand();
        String strConnString, strSQL;
        System.Globalization.CultureInfo locale = new System.Globalization.CultureInfo("en-US");
        BookInfo book = new BookInfo();
        MemberInfo member = new MemberInfo();
        MemberInfoDAO memberDAO = new MemberInfoDAO();
        DataTable dt = new DataTable();
        DataTable data;
        Boolean check_duplicate = true;
        string bookinfodd = "";
        string bookinfoinput = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            Show_panel2.Visible = false;
            Book_msg.Visible = true;

            if (this.Session["book"] == null)
            {
                data = new DataTable();
                data.Columns.Add(new DataColumn("ID", typeof(string)));
                data.Columns.Add(new DataColumn("Title", typeof(string)));
                data.Columns.Add(new DataColumn("Register_number", typeof(string)));
                data.Columns.Add(new DataColumn("Call_number", typeof(string)));
                data.Columns.Add(new DataColumn("Num", typeof(string)));
                data.Columns.Add(new DataColumn("Return_date", typeof(string)));
                this.Session["book"] = data;
            }
            else
            {
                data = (DataTable)this.Session["book"];
            }
            DayOfWeek today = DateTime.Today.DayOfWeek;
            //Response.Write(today);
            head.Visible = true;
            //head2.Visible = false;
            //head3.Visible = false;
            //head4.Visible = false;

            Show_panel.Visible = true;
            //Show_panel2.Visible = false;
            //Show_panel3.Visible = false;
            Show_panel4.Visible = true;
        }

        protected void Member_bt_Click(object sender, EventArgs e)
        {
            Alert_msg.Text = "";

            MultiView1.Visible = true;
            MultiView1.SetActiveView(View3);
            head2.Visible = true;
            Show_panel2.Visible = true;

            MultiView2.Visible = true;
            MultiView2.SetActiveView(View1);

            head3.Visible = true;
            Show_panel3.Visible = true;
            Session.Remove("book");
            viewData();
            
        }
        public void viewData()
        {
            MultiView1.SetActiveView(View3);
            MultiView2.SetActiveView(View1);
            Alert_msg.Visible = false;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();
            
            if(SearchField.Text == "")
            {
                Alert_msg.Visible = true;
                Alert_msg.Text = "Please enter the correct information";
                MultiView2.Visible = true;
                MultiView3.Visible = true;
            }
            //*** DataTable ***//
            SqlDataAdapter dtAdapter;
            DataTable dt = new DataTable();
            strSQL = "SELECT * FROM Member_Info, Member_Type , Department WHERE (" + SelectList.SelectedValue + " = '" + this.SearchField.Text + "') ";
            strSQL += "AND (Member_Info.Membertype_id = Member_Type.Membertype_id) AND (Member_Info.Department_id = Department.Department_id)";
            //strSQL = "SELECT * FROM Member_Info WHERE Member_id = 3";
            dtAdapter = new SqlDataAdapter(strSQL, objConn);
            dtAdapter.Fill(dt);

            if (dt.Rows.Count > 0 && dt.Rows.Count <= 1)
            {
                string registerdate = DateTime.Parse(dt.Rows[0]["Create_date"].ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                string expiredate = DateTime.Parse(dt.Rows[0]["Expire_date"].ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                MultiView1.SetActiveView(View3);
                MultiView2.SetActiveView(View1);
                
                this.ID.Text = Convert.ToString(dt.Rows[0]["Member_id"]);
                this.MemberPic.ImageUrl = "MemberPic/" + (string)dt.Rows[0]["Image"];
                this.Student_id.Text = (string)dt.Rows[0]["Student_id"];
                this.Name.Text = (string)dt.Rows[0]["Callname"] + " " + (string)dt.Rows[0]["Name"];
                this.Address.Text = Convert.ToString(dt.Rows[0]["Address"]);
                this.Email.Text = Convert.ToString(dt.Rows[0]["Email"]);
                this.Phone.Text = Convert.ToString(dt.Rows[0]["Phone_number"]);
                this.Mobile.Text = Convert.ToString(dt.Rows[0]["Mobile_number"]);
                this.RegisterDate.Text = registerdate;
                this.ExpireDate.Text = expiredate;
                this.Membertype.Text = Convert.ToString(dt.Rows[0]["Membertype_name"]);
                this.Department.Text = Convert.ToString(dt.Rows[0]["Department_name"]);
            }
            else
            {
                Alert_msg.Visible = true;
                Alert_msg.Text = "Not found this member information";
                
                MultiView1.Visible = true;
                MultiView2.Visible = true;
                MultiView3.Visible = true;

                head2.Visible = true;
                Show_panel2.Visible = true;

                head3.Visible = true;
                Show_panel3.Visible = true;

                head4.Visible = true;
                Show_panel4.Visible = true;
                 
            }


            //show book fine of overdue


            string SqlMemberFine = "";
            string SqlMemberFine2 = "";
            int Allfine = 0;
            DateTime calfinedate;
            int finalFine = 0;
            int all_fine_remain = 0;
            DateTime today;
            SqlDataAdapter da3,da4;
            DataTable dt3,dt4;
            try
            {
            MultiView1.SetActiveView(View3);
            MultiView2.SetActiveView(View1);
            SqlMemberFine = "SELECT Date_return FROM History WHERE Member_id='" + Convert.ToString(dt.Rows[0]["Member_id"]) + "' AND Date_return_actual IS NULL ";
            SqlMemberFine2 = "SELECT Fine FROM History WHERE Member_id='" + Convert.ToString(dt.Rows[0]["Member_id"]) + "' AND Fine_pay = 'false'";

            da3 = new SqlDataAdapter(SqlMemberFine, objConn);
            dt3 = new DataTable();
            

                da3.Fill(dt3);
            

            if (dt3.Rows.Count > 0)
            {

                for (int i = 0; i < dt3.Rows.Count; i++)
                {
                    today = System.DateTime.Today.Date;
                    string finedate = Convert.ToString(dt3.Rows[i]["Date_return"]);
                    calfinedate = Convert.ToDateTime(finedate);

                    if (today > calfinedate)
                    {
                        Allfine = today.Subtract(calfinedate).Days;
                        Allfine = Allfine * 5;
                        finalFine += Allfine;
                    }
                    else
                    {
                        Allfine = 0;
                        finalFine += Allfine;
                    }
                }
            }

            else
            {
                Fee_amount.Text = "Can't calculate all fine2";
            }

            Fee_amount.Text = "" + finalFine + " Rs";  //ค่าปรับคืนเกินเวลา


            }
            catch (Exception)
            {
                Alert_msg.Text = "Not found this member information, please check your word and try again !!";
                
                MultiView1.Visible = false;
                MultiView2.Visible = false;
                MultiView3.Visible = false;

                head2.Visible = false;
                Show_panel2.Visible = false;

                head3.Visible = false;
                Show_panel3.Visible = false;

                head4.Visible = false;
                Show_panel4.Visible = false;
            }




            try
            {
            MultiView1.SetActiveView(View3);
            MultiView2.SetActiveView(View1);
            //show book fine of arrears
            SqlMemberFine2 = "SELECT Fine FROM History WHERE Member_id='" + Convert.ToString(dt.Rows[0]["Member_id"]) + "' AND Fine_pay = 'false'";
            da4 = new SqlDataAdapter(SqlMemberFine2, objConn);
            dt4 = new DataTable();
            

                da4.Fill(dt4);
            

            if (dt4.Rows.Count > 0)
            {

                for (int i = 0; i < dt4.Rows.Count; i++)
                {
                    int fine_remain = Convert.ToInt16(dt4.Rows[i]["Fine"]);
                    all_fine_remain += fine_remain;
                }
            }

            else
            {
                
                Fee.Text = "Can't calculate all fine2";
            }
            }
            catch (Exception)
            {
                Alert_msg.Text = "Not found this member information, please check your word and try again !!";
                
                MultiView1.Visible = false;
                MultiView2.Visible = false;
                MultiView3.Visible = false;

                head2.Visible = false;
                Show_panel2.Visible = false;

                head3.Visible = false;
                Show_panel3.Visible = false;

                head4.Visible = false;
                Show_panel4.Visible = false;
            }
            Fee.Text = "" + all_fine_remain + " Rs";  //ค่าปรับค้างจ่าย


            Label17.Text = "" + (finalFine + all_fine_remain) + " Rs";  //ค่าปรับทั้งหมด



            objConn.Close();
            objConn = null;
        }

        protected void book_bt_Click(object sender, EventArgs e)
        {
            //MultiView3.Visible = true;
            //MultiView3.SetActiveView(View2);
            //head4.Visible = true;
            Show_panel4.Visible = true;
            MultiView1.SetActiveView(View3);
            head2.Visible = true;
            Show_panel2.Visible = true;
            Show_panel3.Visible = true;
            //MultiView1.Visible = true;
            //MultiView1.SetActiveView(View3);
            Sqve.Enabled = true;
            checkData();
            


        }

        public void checkData()
        {
            Book_msg.Text = "";
            MultiView3.Visible = true;
            MultiView3.SetActiveView(View2);
            head4.Visible = true;
            Show_panel4.Visible = true;
            bookinfodd = DropDownList1.SelectedItem.Value;
            bookinfoinput = BookField.Text;
            HolidayInfoDAO holiday = new HolidayInfoDAO();
            Alert_msg.Visible = false;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            //*** DataTable ***//
            SqlDataAdapter dtAdapter;
            //strSQL = "SELECT * FROM Book_Info WHERE " + DropDownList1.SelectedValue + " LIKE '%" + this.BookField.Text + "%' AND Bookstatus_id = 1";
            strSQL = "SELECT * FROM Member_Info , Book_Info, Bookcondition WHERE (" + DropDownList1.SelectedValue + " = '" + this.BookField.Text + "' AND Bookstatus_id = 1) AND (Book_Info.Booktype_id = Bookcondition.Booktype_id) ";
            strSQL += "AND (Member_Info.Membertype_id = Bookcondition.Membertype_id) AND (Member_Info.Member_id = '" + ID.Text + "')";
            //strSQL = "SELECT * FROM Member_Info WHERE Member_id = 3";
            dtAdapter = new SqlDataAdapter(strSQL, objConn);
            dtAdapter.Fill(dt);

            if (data.Rows.Count > 0)
            {
                for (int j = 0; j < data.Rows.Count; j++)
                {
                    if (bookinfodd == "Register_number")
                    {
                        string register_compare = "";
                        register_compare = (string)data.Rows[j]["Register_number"];
                        if (register_compare == bookinfoinput)
                        {
                            check_duplicate = false;
                        }
                    }
                    else if (bookinfodd == "Call_number")
                    {
                        string call_compare = "";
                        call_compare = (string)data.Rows[j]["Call_number"];
                        if (call_compare == bookinfoinput)
                        {
                            check_duplicate = false;
                        }
                    }

                }
            }


            if (bookinfoinput == "")
            {
                Book_msg.Visible = true;
                Book_msg.Text = "Please print register number Or? call number Correctly.";
                MultiView3.Visible = true;
                head4.Visible = true;
                Show_panel4.Visible = true;
            }
            if (check_duplicate == true)
            {


                MultiView3.Visible = true;
                MultiView3.SetActiveView(View2);
                //Book_msg.Visible = true;
                //Book_msg.Text = member.getExpireDateByID(ID.Text);

                string now = DateTime.Today.ToString("dd/MM/yyyy", new CultureInfo("en-US"));

                DateTime expire_date = Convert.ToDateTime(member.getExpireDateByID(ID.Text));
                DateTime today = Convert.ToDateTime(now);
                //Book_msg.Text = expire_date.ToString();
                
                   
                

                if (today < expire_date)
                {


                    try
                    {

                    if (book.getNumBorrow(Convert.ToInt32(ID.Text)) <= Convert.ToInt32(dt.Rows[0]["Amount_book"]))
                    {
                        if (dt.Rows.Count > 0)
                        {
                            int num = Convert.ToInt32((dt.Rows[0]["Borrow_duration"]));
                            string returndate, returndate_ac;
                            returndate_ac = DateTime.Parse(DateTime.Today.AddDays(num).ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                            int num_holiday = holiday.checkHoliday(returndate_ac);

                            if (DateTime.Parse(DateTime.Today.AddDays(num + num_holiday).ToString()).DayOfWeek.ToString() == "Saturday")
                            {
                                returndate = DateTime.Parse(DateTime.Today.AddDays(num + 2).ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                            }
                            if (DateTime.Parse(DateTime.Today.AddDays(num + num_holiday).ToString()).DayOfWeek.ToString() == "Sunday")
                            {
                                returndate = DateTime.Parse(DateTime.Today.AddDays(num + 1).ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                            }
                            else
                            {
                                returndate = DateTime.Parse(DateTime.Today.AddDays(num).ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                            }

                            Book_msg.Visible = true;
                            //Book_msg.Text = (string)dt.Rows[0]["Title"];
                            DataRow dr = data.NewRow();
                            dr["ID"] = Convert.ToString(dt.Rows[0]["Book_id"]);
                            dr["Title"] = (string)dt.Rows[0]["Title"];
                            dr["Register_number"] = (string)dt.Rows[0]["Register_number"];
                            dr["Call_number"] = (string)dt.Rows[0]["Call_number"];
                            dr["Num"] = Convert.ToString(dt.Rows[0]["Borrow_duration"]);
                            dr["Return_date"] = returndate;
                            data.Rows.Add(dr);
                            //Label18.Text = book.getNumBorrow(Convert.ToInt32(ID.Text)).ToString();
                            //Book_msg.Text = num_holiday.ToString();

                            GridView1.DataSource = data;
                            GridView1.DataBind();
                        }
                        else
                        {
                            Book_msg.Visible = true;
                            Book_msg.Text = "This book was borrowed and then!!";
                            MultiView1.SetActiveView(View3);
                            head2.Visible = true;
                            Show_panel2.Visible = true;
                            if (GridView1.Rows.Count == 0)
                            {
                                MultiView3.Visible = true;
                                Sqve.Enabled = true;
                            }
                            else
                            {
                                Sqve.Enabled = true;
                            }

                        }
                    }

                    else
                    {
                        Book_msg.Visible = true;
                        Book_msg.Text = "The full members definition borrowed books.!!!";
                        MultiView3.Visible = true;
                    }



                }
                catch(Exception)
                {
                    Book_msg.Text = "Please check book information and type register number or call number to correct";
                    if (GridView1.Rows.Count == 0)
                    {
                        MultiView3.Visible = false;
                        Sqve.Enabled = false;
                    }
                    else
                    {
                        Sqve.Enabled = true;
                    }
                
                }

                }
                else
                {
                    Book_msg.Visible = true;
                    Book_msg.Text = "สมากชิกหมดอายุในการยืมหนังสือ";
                    MultiView1.SetActiveView(View3);
                    head2.Visible = true;
                    Show_panel2.Visible = true;
                    MultiView3.Visible = false;
                }
            }
            else
            {
                Book_msg.Visible = true;
                Book_msg.Text = "This book is borrowed";
                MultiView3.Visible = true;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            objConn.Close();
            objConn = null;
        }



        protected void EditCommand(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            GridView1.ShowFooter = true;
            checkData();
        }
        protected void modUpdateCommand(object sender, GridViewUpdateEventArgs e)
        {
            
            TextBox txtDuration = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtDuration");
            Label duration = (Label)GridView1.Rows[e.RowIndex].FindControl("duration_lb");
            Response.Write(txtDuration.Text);
            DataRow dr = data.NewRow();
            dr["Num"] = txtDuration.Text;
            GridView1.EditIndex = -1;
            GridView1.ShowFooter = true;
            //checkData();
            
        }
        protected void modCancelCommand(object sender, GridViewCancelEditEventArgs e)
        {
           
            GridView1.EditIndex = -1;
            GridView1.ShowFooter = true;
            //checkData();
            
        }

        protected void Sqve_Click(object sender, EventArgs e)
        {
            BorrowBook borrowbook = new BorrowBook();
            head2.Visible = true;
            head3.Visible = true;
            head4.Visible = true;
            Show_panel2.Visible = true;
            Show_panel3.Visible = true;
            Show_panel4.Visible = true;
            for (int i = 0; i < GridView1.Rows.Count; i++ )
            {
                string today = DateTime.Today.ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                string strId = GridView1.Rows[i].Cells[1].Text;
                string regNum = GridView1.Rows[i].Cells[2].Text;
                string date_return = GridView1.Rows[i].Cells[6].Text;
                Book_msg.Visible = true;

                Response.Write(" Book id " + strId);
                Response.Write(" member id " + ID.Text);
                Response.Write(" date return " + date_return);
                Response.Write(" register number " + regNum);
                borrowbook.borrowBook(Convert.ToInt32(strId), Convert.ToInt32(ID.Text),date_return,today);
                borrowbook.setBorrowHistory(Convert.ToInt32(ID.Text), Convert.ToInt32(strId), regNum, date_return);
                Label18.Visible = true;
                Label18.Text = borrowbook.getMessage();
                Show_panel2.Visible = true;
                MultiView2.Visible = true;
            }
            Session.Remove("book");
            Sqve.Enabled = false;

        }

        protected void Tabshow_Click(object sender, EventArgs e)
        {
            Show_panel.Visible = true;
        }

        protected void Tabhide_Click(object sender, EventArgs e)
        {
            Show_panel.Visible = false;
        }



        protected void Tabshow_Click2(object sender, EventArgs e)
        {
            Show_panel2.Visible = true;
        }

        protected void Tabhide_Click2(object sender, EventArgs e)
        {
            Show_panel2.Visible = false;
        }



        protected void Tabshow_Click3(object sender, EventArgs e)
        {
            Show_panel3.Visible = true;
        }

        protected void Tabhide_Click3(object sender, EventArgs e)
        {
            Show_panel3.Visible = false;
        }



        protected void Tabshow_Click4(object sender, EventArgs e)
        {
            Show_panel4.Visible = true;
        }

        protected void Tabhide_Click4(object sender, EventArgs e)
        {
            Show_panel4.Visible = false;
        }

    }
}
