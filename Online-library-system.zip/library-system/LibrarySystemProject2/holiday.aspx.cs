﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using LibrarySystemProject2.DAO;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        SqlConnection objConn;
        SqlCommand objCmd;
        String strSQL;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {
            String strConnString;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            if (!Page.IsPostBack)
            {
                BindData();
            }
            //Label4.Text = "";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != "" && TextBox2.Text != "")
            {
                HolidayInfo holidayinfo = new HolidayInfo();
                HolidayInfoDAO holidayinfodao = new HolidayInfoDAO();

                holidayinfo.setDate(Convert.ToDateTime(TextBox1.Text));
                holidayinfo.setHolidayName(TextBox2.Text.ToString());
                holidayinfodao.addHoliday(holidayinfo);

                Label4.Text = holidayinfodao.getMessage();

                BindData();
                TextBox1.Text = "";
                TextBox2.Text = "";
            }
            else
            {
                Label4.Text = "Please fill all information";
                //Response.Write("<script language='javascript'>");
                //Response.Write("alert('Please fill all information')");
                //Response.Write("</script>");
            }
        }

        protected void BindData()
        {
            String strSQL;
            strSQL = "SELECT * FROM Holiday";

            SqlDataReader dtReader;
            objCmd = new SqlCommand(strSQL, objConn);
            dtReader = objCmd.ExecuteReader();

            dtAdapter.SelectCommand = objCmd;
            //*** BindData to GridView ***//
            myGridView.DataSource = dtReader;
            myGridView.DataBind();

            dtReader.Close();
            dtReader = null;

        }

        protected void Page_UnLoad()
        {
            objConn.Close();
            objConn = null;
        }

        protected void EditCommand(object sender, GridViewEditEventArgs e)
        {
            myGridView.EditIndex = e.NewEditIndex;
            myGridView.ShowFooter = false;
            BindData();
        }

        protected void modCancelCommand(object sender, GridViewCancelEditEventArgs e)
        {
            myGridView.EditIndex = -1;
            myGridView.ShowFooter = false;
            Label4.Text = "";
            BindData();
        }

        protected void modDeleteCommand(object sender, GridViewDeleteEventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            strSQL = "DELETE FROM Holiday WHERE Holiday_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";
            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                Label4.Text = "Delete successful !";
            }
            catch (Exception ex)
            {
                Label4.Text = "Cannot delete cause of : " + ex;

            }

            myGridView.EditIndex = -1;
            BindData();
        }

        protected void modUpdateCommand(object sender, GridViewUpdateEventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            
            TextBox txtDetail = (TextBox)myGridView.Rows[e.RowIndex].FindControl("txtDetail");
            strSQL = "UPDATE Holiday SET Holiday_name = '" + txtDetail.Text + "' WHERE Holiday_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";

            objCmd = new SqlCommand(strSQL, objConn);
            Label4.Text = myGridView.DataKeys[e.RowIndex].Value.ToString();
            try
            {
                objCmd.ExecuteNonQuery();
                Label4.Text = "Update successful !";

            }
            catch (Exception ex)
            {
                Label4.Text = ex.Message;
            }


            myGridView.EditIndex = -1;
            myGridView.ShowFooter = false;
            BindData();
        }
        protected void myGridView_RowDataBound(Object s, GridViewRowEventArgs e)
        {
            string totalRecord = this.myGridView.Rows.Count.ToString();
            int totalRows = Convert.ToInt16(totalRecord) + 1;
            //*** No. ***//
            Label No = (Label)(e.Row.FindControl("No"));

            if (No != null)
            {
                No.Text = "" + totalRows + "";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
        }

    }
}
