﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;
using CAMT;
using LibrarySystemProject2.Class;
using LibrarySystemProject2.DAO;
using System.Globalization;

namespace LibrarySystemProject2
{
    public partial class WebForm22 : System.Web.UI.Page
    {
        SqlConnection objConn;
        SqlCommand objCmd;
        String strSQL;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();
        String strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;


        protected void Page_Load(object sender, EventArgs e)
        {
            string today = DateTime.Today.ToString("dd/MM/yyyy", new CultureInfo("en-US"));
            this.DateImport.Text = today;
            MultiView1.SetActiveView(View1);
            MultiView2.Visible = false;
            MultiView3.Visible = false;
            MultiView3.Visible = false;
            
        }

        protected void NewAuthor_bt_CheckedChanged(object sender, EventArgs e)
        {
            if ((NewAuthor_bt.Checked == true))
            {
                MultiView2.Visible = true;
                MultiView2.SetActiveView(View2);
                NewAuthor.Enabled = true;
                AuthorList.Enabled = false;
            }
        }

        protected void SelectAuthor_bt_CheckedChanged(object sender, EventArgs e)
        {
            if ((SelectAuthor_bt.Checked == true))
            {
                MultiView2.Visible = true;
                MultiView2.SetActiveView(View2);
                AuthorList.Enabled = true;
                NewAuthor.Enabled = false;
            }
        }

        protected void Newsubject_bt_CheckedChanged(object sender, EventArgs e)
        {
            if ((Newsubject_bt.Checked == true))
            {
                MultiView2.Visible = true;
                MultiView2.SetActiveView(View2);
                NewSubject.Enabled = true;
                BookSubject.Enabled = false;
            }
        }

        protected void Selectsubject_bt_CheckedChanged(object sender, EventArgs e)
        {
            if ((Selectsubject_bt.Checked == true))
            {
                MultiView2.Visible = true;
                MultiView2.SetActiveView(View2);
                NewSubject.Enabled = false;
                BookSubject.Enabled = true;
            }
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            BookInfo book = new BookInfo();
            BookInfoDAO bookInfo = new BookInfoDAO();
            AuthorInfo author = new AuthorInfo();
            AuthorInfoDAO authorDAO = new AuthorInfoDAO();
            BooksubjectInfo booksubject = new BooksubjectInfo();
            BooksubjectInfoDAO booksubjectDAO = new BooksubjectInfoDAO();

            if (TitleInput.Text == "" || Callnumber.Text == "" || RegisterNumber.Text == "" || PageInput.Text == ""
                || DateImport.Text == "" || Year.Text == "" 
                || Publisher.Text == "" || PublisherLocation.Text == "" || ISBN.Text == "" 
                || Keyword.Text == "" || Note.Text == "")
            {
                MultiView2.Visible = true;
                MultiView2.SetActiveView(View2);
                Message.Text = "Please fill all information";
            }

            
            else
            {

                if (Edition.Text == "" || Volume.Text == "" || BookCopy.Text == "" || Series.Text == "")
                {
                    Edition.Text = "0";
                    Volume.Text = "0";
                    BookCopy.Text = "0";
                    Series.Text = "-";
                }

                if ((NewAuthor_bt.Checked == true))
                {
                    author.setAuthorName(NewAuthor.Text);
                    book.setAuthorID(author.getMaxID());
                    authorDAO.addNewAuthorFromBook(author);
                }
                if ((SelectAuthor_bt.Checked == true))
                {
                    author.setBookTotal(AuthorList.SelectedValue);
                    book.setAuthorID(Convert.ToInt32(AuthorList.SelectedValue));
                    authorDAO.upDateBookTotal(author, book);
                }
                if ((Newsubject_bt.Checked == true))
                {
                    book.setBookSubjectID(booksubject.getMaxID());
                    booksubject.setBooksubjectName(NewSubject.Text);
                    booksubjectDAO.addNewBookSubject(booksubject);
                }
                if ((Selectsubject_bt.Checked == true))
                {
                    booksubject.setBookTotal(BookSubject.SelectedValue);
                    book.setBookSubjectID(Convert.ToInt32(BookSubject.SelectedValue));
                    booksubjectDAO.upDateBookTotal(booksubject, book);
                }
                try
                {
                    book.setBorrowTime(0);
                    book.setBookCopy(Convert.ToInt32(BookCopy.Text));
                    book.setBookStatusID(Convert.ToInt32(BookStatus.SelectedValue));
                    book.setBookTypeID(Convert.ToInt32(BookType.SelectedValue));
                    book.setCallNumber(Callnumber.Text);
                    book.setDateImport(Convert.ToDateTime(DateImport.Text));
                    book.setEdition(Convert.ToInt32(Edition.Text));
                    book.setISBN(ISBN.Text.ToString());
                    book.setKeyword(Keyword.Text.ToString());
                    book.setLocation(Location.SelectedItem.Text.ToString());
                    book.setNote(Note.Text.ToString());
                    book.setPage(Convert.ToInt32(PageInput.Text));
                    book.setPublisher(Publisher.Text.ToString());
                    book.setPublisherLocation(PublisherLocation.Text.ToString());
                    book.setRegisterNumber(RegisterNumber.Text.ToString());
                    book.setSeries(Series.Text.ToString());
                    book.setSource(Source.SelectedValue);
                    book.setTitle(TitleInput.Text.ToString());
                    book.setVolume(Convert.ToInt32(Volume.Text));
                    book.setYear(Year.Text.ToString());
                    bookInfo.addNewBook(book);

                    
                    Message.Text = bookInfo.getMessage();
                    if (Message.Text == "Add book successful")
                    {
                        Submit.Enabled = false;
                    }
                }
                catch (Exception e2)
                {
                    Message.Text = "Wronng data type, Please try again!"+e2;
                }
                MultiView2.Visible = true;
                MultiView2.SetActiveView(View2);
                if (Message.Text == "Add book successful")
                {
                    Submit.Enabled = false;
                }
            }
        }

        protected void searchSubmit_Click(object sender, EventArgs e)
        {
            if (newBook.Checked)
            {
                MultiView2.SetActiveView(View2);
                MultiView2.Visible = true;
                MultiView4.Visible = false;
            }
            if (copyBook.Checked)
            {
                MultiView3.Visible = true;
                MultiView3.SetActiveView(View3);
                MultiView4.Visible = false;
                BindData();
            }
            Submit.Enabled = true;
            Add_Copy.Enabled = true;

            TitleInput.Text = ""; 
            Callnumber.Text = ""; 
            RegisterNumber.Text = "";
            PageInput.Text = "";
            //DateImport.Text = "";
            Year.Text = ""; 
            Publisher.Text = ""; 
            PublisherLocation.Text = ""; 
            ISBN.Text = ""; 
            Keyword.Text = "";
            Note.Text = "";
            Edition.Text = "";
            Volume.Text = "";
            BookCopy.Text = "";
            Series.Text = "";
            txtCallnumber.Text = ""; 
            txtRegister_number.Text = "";
            Date_Import.Text = "";


        }
        protected void BindData()
        {
            strSQL = "SELECT Book_id,Title,ISBN, Author_Info.Author_name";
            strSQL += " FROM Book_Info, Author_Info";
            strSQL += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
            if (listSearch.SelectedItem.Value == "ISBN")
            {
                strSQL += " AND (Book_Info.ISBN LIKE '%" + this.txtSearch.Text + "%') ORDER BY Title";
            }
            else if (listSearch.SelectedItem.Value == "Title")
            {
                strSQL += " AND (Book_Info.Title LIKE '%" + this.txtSearch.Text + "%')ORDER BY Title";
            }



            SqlConnection objConn = new SqlConnection(strConnString);
            SqlCommand objCmd = new SqlCommand();
            SqlDataAdapter dtAdapter = new SqlDataAdapter();

            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;


            dtAdapter.SelectCommand = objCmd;

            dtAdapter.Fill(ds);

            //*** BindData to GridView ***//
            GridView1.DataSource = ds;
            GridView1.AllowPaging = true;
            GridView1.DataBind();
            search_result.Text = GridView1.Rows.Count.ToString();

            dtAdapter = null;
            objConn.Close();
            objConn = null;

        }
        protected void searchView_RowDataBound(Object s, GridViewRowEventArgs e)
        {
            LinkButton title = (LinkButton)(e.Row.FindControl("LinkButton1"));
            if (title != null)
            {
                title.Text = (DataBinder.Eval(e.Row.DataItem, "Title")).ToString();
            }

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MultiView4.Visible = true;
            MultiView4.SetActiveView(View4);
            BindData2();
            string str="";
            
            var selectedRow = GridView1.SelectedRow.FindControl("Label3");
            str = ((Label)selectedRow).Text;
            // handle the vent of select command

            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            //*** DataTable ***//
            SqlDataAdapter dtAdapter;
            DataTable dt = new DataTable();
            strSQL = "SELECT * FROM Book_Info, Book_Type, Book_Subject, Author_Info WHERE Book_Info.Author_id = Author_Info.Author_id AND Book_Info.Booksubject_id = Book_Subject.Booksubject_id AND Book_Info.ISBN = '" + str + "'";
            strSQL += " AND Book_Type.Booktype_id = Book_Info.Booktype_id";

            dtAdapter = new SqlDataAdapter(strSQL, objConn);
            dtAdapter.Fill(dt);

            if (dt.Rows.Count > 0)
            {

                string today = DateTime.Parse(DateTime.Today.ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));

                this.txtTitle.Text = (string)dt.Rows[0]["Title"];
                this.txtAuthor_id.Text = Convert.ToString(dt.Rows[0]["Author_id"]);
                this.txtBT_id.Text = Convert.ToString(dt.Rows[0]["Booktype_id"]);
                this.txtBookType.Text = Convert.ToString(dt.Rows[0]["Booktype_name"]);
                this.txtAuthor.Text = Convert.ToString(dt.Rows[0]["Author_name"]);
                this.txtPage.Text = Convert.ToString(dt.Rows[0]["Page"]);
                this.txtVolume.Text = Convert.ToString(dt.Rows[0]["Volume"]);
                this.txtSeries.Text = Convert.ToString(dt.Rows[0]["Series"]);
                this.Date_Import.Text = today;
                this.txtYear.Text = Convert.ToString(dt.Rows[0]["Year"]);
                this.txtEdition.Text = Convert.ToString(dt.Rows[0]["Edition"]);
                this.txtPublisher.Text = Convert.ToString(dt.Rows[0]["Publisher"]);
                this.txtpublisherLocation.Text = Convert.ToString(dt.Rows[0]["Publisher_location"]);
                this.txtISBN.Text = Convert.ToString(dt.Rows[0]["ISBN"]);
                this.txtNote.Text = Convert.ToString(dt.Rows[0]["Note"]);
                this.txtKeyword.Text = Convert.ToString(dt.Rows[0]["Keyword"]);
                this.txtBookStatus.SelectedValue = Convert.ToString(dt.Rows[0]["Bookstatus_id"]);
                this.txtLocation.SelectedValue = Convert.ToString(dt.Rows[0]["Location"]);
                this.txtBookCopy.Text = Convert.ToString(dt.Rows[0]["Book_copy"]);
                this.txtSource.SelectedItem.Value = Convert.ToString(dt.Rows[0]["Source"]);
                this.txtBookSubject_id.Text = Convert.ToString(dt.Rows[0]["Booksubject_id"]);
                this.txtBooksubject.Text = Convert.ToString(dt.Rows[0]["Booksubject_name"]);

            }
            else
            {

            }
            objConn.Close();
            objConn = null;
        }
        protected void BindData2()
        {
            string str;
            var selectedRow = GridView1.SelectedRow.FindControl("Label3");
            str = ((Label)selectedRow).Text;

            strSQL = "SELECT Call_number,Location,Bookstatus_name, Register_number";
            strSQL += " FROM Book_Info, Author_Info, Book_Status";
            strSQL += " WHERE (Book_Info.Author_id=Author_Info.Author_id) AND (Book_Info.Bookstatus_id=Book_Status.Bookstatus_id)";
            strSQL += " AND (Book_Info.ISBN = '" + str + "')";

            SqlConnection objConn = new SqlConnection(strConnString);
            SqlCommand objCmd = new SqlCommand();
            SqlDataAdapter dtAdapter = new SqlDataAdapter();

            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;


            dtAdapter.SelectCommand = objCmd;

            dtAdapter.Fill(ds);

            //*** BindData to GridView ***//
            GridView2.DataSource = ds;
            GridView2.AllowPaging = true;
            GridView2.DataBind();
            //search_result.Text = GridView1.Rows.Count.ToString();

            dtAdapter = null;
            objConn.Close();
            objConn = null;

        }
        protected void ShowPageCommand(Object s, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            MultiView3.Visible = true;
            BindData();
        }

        protected void Add_Copy_Click(object sender, EventArgs e)
        {
            BookInfo book = new BookInfo();
            BookInfoDAO bookInfo = new BookInfoDAO();
            AuthorInfo author = new AuthorInfo();
            AuthorInfoDAO authorDAO = new AuthorInfoDAO();
            BooksubjectInfo booksubject = new BooksubjectInfo();
            BooksubjectInfoDAO booksubjectDAO = new BooksubjectInfoDAO();

            if (txtCallnumber.Text == "" || txtRegister_number.Text == "" || Date_Import.Text == "")
            {
                Message2.Text = "Please fill all information";
            }
            else
            {
                book.setAuthorID(Convert.ToInt32(txtAuthor_id.Text));


                book.setBookSubjectID(Convert.ToInt32(txtBookSubject_id.Text));

                book.setBorrowTime(0);
                book.setBookCopy(Convert.ToInt32(txtBookCopy.Text));
                book.setBookStatusID(Convert.ToInt32(txtBookStatus.SelectedValue));
                book.setBookTypeID(Convert.ToInt32(txtBT_id.Text));
                book.setCallNumber(txtCallnumber.Text);
                book.setDateImport(Convert.ToDateTime(Date_Import.Text));
                book.setEdition(Convert.ToInt32(txtEdition.Text));
                book.setISBN(txtISBN.Text.ToString());
                book.setKeyword(txtKeyword.Text.ToString());
                book.setLocation(txtLocation.SelectedItem.Text.ToString());
                book.setNote(txtNote.Text.ToString());
                book.setPage(Convert.ToInt32(txtPage.Text));
                book.setPublisher(txtPublisher.Text.ToString());
                book.setPublisherLocation(txtpublisherLocation.Text);
                book.setRegisterNumber(txtRegister_number.Text);
                book.setSeries(txtSeries.Text);
                book.setSource(txtSource.SelectedValue);
                book.setTitle(txtTitle.Text.ToString());
                book.setVolume(Convert.ToInt32(txtVolume.Text));
                book.setYear(txtYear.Text.ToString());

                bookInfo.addNewBook(book);
                authorDAO.upDateBookTotal(author, book);
                author.setBookTotal(txtAuthor_id.Text);
                booksubjectDAO.upDateBookTotal(booksubject, book);
                booksubject.setBookTotal(txtBookSubject_id.Text);
                MultiView4.Visible = true;
                Message2.Text = bookInfo.getMessage();
                if (Message2.Text == "Add book successful")
                {
                    Add_Copy.Enabled = false;
                }
                
            }

        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            MultiView3.Visible = true;
            MultiView3.SetActiveView(View3);
            Message2.Text = "";
        }

    }
}
