﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2
{
    public class BookInfo
    {
        string title, registerNumber, callNumber, series, year, publisher, publisher_location, ISBN, note, keyword, location, source, book_id;
        int page, volume, edition, bookCopy, reserveQueue, borrowTime, member_id, bookstatus_id, author_id, booktype_id, booksubject_id, oldbooksubject_total, oldbooksubject_id, num_borrow;
        DateTime dateImport, dateBorrow, dateReturn;
        int borrowtime;

        public int getNumBorrow(int member_id)
        {
            int num_borrow = 0;
            string strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();
            string strSQL = "SELECT COUNT(Member_id) FROM Book_Info WHERE Member_id = '" + member_id + "'";
            SqlCommand com = new SqlCommand();
            SqlDataReader dr;
            com.Connection = Conn;
            com.CommandType = CommandType.Text;
            com.CommandText = strSQL;
            dr = com.ExecuteReader();

            if (dr.Read())
            {
                try
                {
                    num_borrow = Convert.ToInt32(dr[0]);
                }
                catch (InvalidCastException)
                {

                }
            }
            
            dr.Close();
            return num_borrow;
        }
        public void setOldBooksubjectTotal(int booksubject_id)
        {
            string strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();
            string strSQL = "SELECT Book_total FROM Book_Subject WHERE Booksubject_id = '"+booksubject_id+"'";
            SqlCommand com = new SqlCommand();
            SqlDataReader dr;
            com.Connection = Conn;
            com.CommandType = CommandType.Text;
            com.CommandText = strSQL;
            dr = com.ExecuteReader();

            if (dr.Read())
            {
                try
                {
                    int data = Convert.ToInt32(dr[0]);
                    oldbooksubject_total = data-1;
                }
                catch (InvalidCastException)
                {

                }
            }
            dr.Close();
                       
        }
        public int getOldBooksubjectTotal()
        {
            return oldbooksubject_total;
        }
        public void setOldBooksubjectID(int oldbooksubject_id)
        {
            this.oldbooksubject_id = oldbooksubject_id;
        }
        public int getOldBooksubjectID()
        {
            return oldbooksubject_id;
        }
        public void setBookID(string book_id)
        {
            this.book_id = book_id;
        }
        public string getBookID()
        {
            return book_id;
        }
        public void setTitle(string title)
        {
            this.title = title;
        }
        public string getTitle()
        {
            return title;
        }
        public void setRegisterNumber(string registerNumber)
        {
            this.registerNumber = registerNumber;
        }
        public string getRegisterNumber()
        {
            return registerNumber;
        }
        public void setCallNumber(string callNumber)
        {
            this.callNumber = callNumber;
        }
        public string getCallNumber()
        {
            return callNumber;
        }
        public void setPublisher(string publisher)
        {
            this.publisher = publisher;
        }
        public string getPublisher()
        {
            return publisher;
        }
        public void setPublisherLocation(string publisher_location)
        {
            this.publisher_location = publisher_location;
        }
        public string getPublisherLocation()
        {
            return publisher_location;
        }
        public void setISBN(string ISBN)
        {
            this.ISBN = ISBN;
        }
        public string getISBN()
        {
            return ISBN;
        }
        public void setNote(string note)
        {
            this.note = note;
        }
        public string getNote()
        {
            return note;
        }
        public void setKeyword(string keyword)
        {
            this.keyword = keyword;
        }
        public string getKeyword()
        {
            return keyword;
        }
        public void setLocation(string location)
        {
            this.location = location;
        }
        public string getLocation()
        {
            return location;
        }
        public void setSource(string source)
        {
            this.source = source;
        }
        public string getSource()
        {
            return source;
        }
        public void setPage(int page)
        {
            this.page = page;
        }
        public int getPage()
        {
            return page;
        }
        public void setVolume(int volume)
        {
            this.volume = volume;
        }
        public int getVolume()
        {
            return volume;
        }
        public void setSeries(string series)
        {
            this.series = series;
        }
        public string getSeries()
        {
            return series;
        }
        public void setYear(string year)
        {
            this.year = year;
        }
        public string getYear()
        {
            return year;
        }
        public void setEdition(int edition)
        {
            this.edition = edition;
        }
        public int getEdition()
        {
            return edition;
        }
        public void setBookCopy(int bookCopy)
        {
            this.bookCopy = bookCopy;
        }
        public int getBookCopy()
        {
            return bookCopy;
        }
        public void setReserveQueue(int reserveQueue)
        {
            this.reserveQueue = reserveQueue;
        }
        public int getReserveQueue()
        {
            return reserveQueue;
        }
        public void setBorrowTime(int borrowTime)
        {
            this.borrowTime = borrowTime;
        }
        public int getBorrowTime()
        {
            return borrowTime;
        }
        public int getBorrowTimeByBorrow(int book_id)
        {
            
            string strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();
            string strSQL = "SELECT Borrow_time FROM Book_Info WHERE Book_id = '"+book_id+"'";
            SqlCommand com = new SqlCommand();
            SqlDataReader dr;
            com.Connection = Conn;
            com.CommandType = CommandType.Text;
            com.CommandText = strSQL;
            dr = com.ExecuteReader();

            if (dr.Read())
            {
                try
                {
                    int data = Convert.ToInt32(dr[0]);
                    borrowtime = data + 1;
                    
                }
                catch (InvalidCastException)
                {

                }
            }
            dr.Close();
            return borrowtime;
        }
        public void setMemberID(int member_id)
        {
            this.member_id = member_id;
        }
        public int getMemberID()
        {
            return member_id;
        }
        public void setAuthorID(int author_id)
        {
            this.author_id = author_id;
        }
        public int getAuthorID()
        {
            return author_id;
        }
        public void setBookStatusID(int bookstatus_id)
        {
            this.bookstatus_id = bookstatus_id;
        }
        public int getBookStatusID()
        {
            return bookstatus_id;
        }
        public void setBookTypeID(int booktype_id)
        {
            this.booktype_id = booktype_id;
        }
        public int getBookTypeID()
        {
            return booktype_id;
        }
        public void setBookSubjectID(int booksubject_id)
        {
            this.booksubject_id = booksubject_id;
        }
        public int getBookSubjectID()
        {
            return booksubject_id;
        }
        public void setDateImport(DateTime dateImport)
        {
            this.dateImport = dateImport;
        }
        public DateTime getDateImport()
        {
            return dateImport;
        }
        public void setDateBorrow(DateTime dateBorrow)
        {
            this.dateBorrow = dateBorrow;
        }
        public DateTime getDateBorrow()
        {
            return dateBorrow;
        }
        public void setDateReturn(DateTime dateReturn)
        {
            this.dateReturn = dateReturn;
        }
        public DateTime getDateReturn()
        {
            return dateReturn;
        }

    }
}
