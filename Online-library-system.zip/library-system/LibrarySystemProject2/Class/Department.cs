﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace LibrarySystemProject2.Class
{
    public class Department
    {
        string department_name;

        public void setDepartmentName(string department_name)
        {
            this.department_name = department_name;
        }
        public string getDepartmentName()
        {
            return department_name;
        }
    }
}
