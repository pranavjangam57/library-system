﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace CAMT
{
    public class AuthorInfo
    {
        string author_name;
        int author_number, book_total, maxID, oldauthor_id, oldauthor_book;

        public void setOldAuthoBookTotal(int author_id)
        {
            string strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();
            string strSQL = "SELECT Book_total FROM Author_Info WHERE Author_id = '" + author_id + "'";
            SqlCommand com = new SqlCommand();
            SqlDataReader dr;
            com.Connection = Conn;
            com.CommandType = CommandType.Text;
            com.CommandText = strSQL;
            dr = com.ExecuteReader();

            if (dr.Read())
            {
                try
                {
                    int data = Convert.ToInt32(dr[0]);
                    oldauthor_book = data - 1;
                }
                catch (InvalidCastException)
                {

                }
            }
            dr.Close();

        }
        public int getOldAuthorTotal()
        {
            return oldauthor_book;
        }
        public void setOldAuthorID(int oldauthor_id)
        {
            this.oldauthor_id = oldauthor_id;
        }
        public int getOldAuthorID()
        {
            return oldauthor_id;
        }
        public void setAuthorName(string author_name)
        {
            this.author_name = author_name;
        }
        public string getAuthorName()
        {
            return author_name;
        }
        public void setAuthorNumber(int author_number)
        {
            this.author_number = author_number;
        }
        public int getAuthorNumber()
        {
            return author_number;
        }
        public void setBookTotal(string author_name)
        {
            string strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();
            string strSQL = "SELECT Book_total FROM Author_Info WHERE Author_id = '" + author_name + "' ";
            SqlCommand com = new SqlCommand();
            SqlDataReader dr;
            com.Connection = Conn;
            com.CommandType = CommandType.Text;
            com.CommandText = strSQL;
            dr = com.ExecuteReader();

            if (dr.Read())
            {
                try
                {
                    int i = Convert.ToInt32(dr["Book_total"]);
                    book_total = i + 1;
                }
                catch (InvalidCastException)
                {
                    
                }
            }
            dr.Close();
        }
        public int getMaxID()
        {
            string strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();
            string strSQL = "SELECT MAX(Author_id) FROM Author_Info";
            SqlCommand com = new SqlCommand();
            SqlDataReader dr;
            com.Connection = Conn;
            com.CommandType = CommandType.Text;
            com.CommandText = strSQL;
            dr = com.ExecuteReader();

            if (dr.Read())
            {
                try
                {
                    int data = Convert.ToInt32(dr[0]);
                    maxID = data + 1;
                }
                catch (InvalidCastException)
                {
                    
                }
            }
            dr.Close();
            return maxID;
        }
        public int getBookTotal()
        {
            return book_total;
        }
    }
}
