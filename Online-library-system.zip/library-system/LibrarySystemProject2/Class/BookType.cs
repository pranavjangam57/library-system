﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace LibrarySystemProject2
{
    public class BookType
    {
        string booktype_name;
        int borrow_total;

        public void setBookTypeName(string booktype_name)
        {
            this.booktype_name = booktype_name;
        }
        public string getBookTypeName()
        {
            return booktype_name;
        }
        public void setBorrowTotal(int borrow_total)
        {
            this.borrow_total = borrow_total;
        }
        public int getBorrowTotal()
        {
            return borrow_total;
        }
    }
}
