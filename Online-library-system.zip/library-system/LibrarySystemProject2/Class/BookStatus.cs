﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace LibrarySystemProject2
{
    public class BookStatus
    {
        string bookstatus_name;


        public void setBookStatusName(string bookstatus_name)
        {
            this.bookstatus_name = bookstatus_name;
        }
        public string getBookStatusName()
        {
            return bookstatus_name;
        }
    }
}
