﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace LibrarySystemProject2
{
    public class UserInfo
    {
        string username, password, usertype;

        public void setUsername(string username)
        {
            this.username = username;
        }
        public string getUsername()
        {
            return username;
        }
        public void setPassword(string password)
        {
            this.password = password;
        }
        public string getPassword()
        {
            return password;
        }
        public void setUserType(string usertype)
        {
            this.usertype = usertype;
        }
        public string getUserType()
        {
            return usertype;
        }
    }
}
