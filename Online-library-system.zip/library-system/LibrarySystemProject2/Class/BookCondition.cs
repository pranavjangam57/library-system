﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace LibrarySystemProject2.Class
{
    public class BookCondition
    {

        int membertype_id;
        int booktype_id;
        int book_duration;
        int amount_book;

        public void setMembertypeid(int membertype_id)
        {
            this.membertype_id = membertype_id;
        }
        public int getMembertypeid()
        {
            return membertype_id;
        }

        public void setBooktypeid(int booktype_id)
        {
            this.booktype_id = booktype_id;
        }
        public int getBooktypeid()
        {
            return booktype_id;
        }

        public void setBookduration(int book_duration)
        {
            this.book_duration = book_duration;
        }
        public int getBookduration()
        {
            return book_duration;
        }

        public void setAmountbook(int amount_book)
        {
            this.amount_book = amount_book;
        }
        public int getAmountbook()
        {
            return amount_book;
        }

    }
}
