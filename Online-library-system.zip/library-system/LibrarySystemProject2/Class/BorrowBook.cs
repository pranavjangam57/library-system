﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Globalization;

namespace LibrarySystemProject2.Class
{
    public class BorrowBook
    {
        string msg;
        BookInfo book = new BookInfo();
        public void borrowBook(int book_id, int member_id, string return_date, string borrow_date)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            strSQL = "UPDATE Book_Info SET Bookstatus_id = 4 , Borrow_time = '"+book.getBorrowTimeByBorrow(book_id)+"' , Member_id = '"+member_id+"' ";
            strSQL += ", Date_borrow = Convert(datetime, '" + borrow_date + "', 103), Date_return = Convert(datetime, '" + return_date+ "', 103) WHERE Book_id = '" + book_id + "'";
            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                //msg = "Record Inserted";
                //msg = objCmd.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                //msg = "Record can not insert Error (" + ex.Message + ")";
            }

            objConn.Close();
            objConn = null;
        }
        public void setBorrowHistory(int member_id, int book_id, string register_number, string date_return)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            string today = DateTime.Today.ToString("dd/MM/yyyy", new CultureInfo("en-US"));
            strSQL = "INSERT INTO History (Member_id, Register_number, Book_id,Date_borrow, Date_return)";
            strSQL += "VALUES ('" + member_id + "' , '" + register_number + "' , '" + book_id + "' , Convert(datetime, '" + today + "', 103), Convert(datetime, '" + date_return + "', 103))";
            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Borrow book successful !!";
                
                //msg = objCmd.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                msg = "Record can not insert Error (" + ex.Message + ")";
            }

            objConn.Close();
            objConn = null;
        }
        public string getMessage()
        {
            return msg;
        }
    }
}
