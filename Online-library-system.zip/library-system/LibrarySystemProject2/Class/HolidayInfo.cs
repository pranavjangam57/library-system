﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace LibrarySystemProject2
{
    public class HolidayInfo
    {
        string holiday_name;
        DateTime date;

        public void setHolidayName(string holiday_name)
        {
            this.holiday_name = holiday_name;
        }
        public string getHolidayName()
        {
            return holiday_name;
        }
        public void setDate(DateTime date)
        {
            this.date = date;
        }
        public DateTime getDate()
        {
            return date;
        }
    }
}
