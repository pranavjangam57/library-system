﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Globalization;

namespace LibrarySystemProject2
{
    public class MemberInfo
    {
        string name, student_id, address, email, phone_number, mobile_number, image, strSQL, callname, create_date, expire_date;
        int membertype_id, department_id, member_id;
       // DateTime ;

        public void setCallname(string callname)
        {
            this.callname = callname;
        }
        public string getCallname()
        {
            return callname;
        }
        public void setSqlQueuery(string strSQL)
        {
            this.strSQL = strSQL;
        }
        public string getSqlQueuery()
        {
            return strSQL;
        }
        public void setMemberID(int member_id)
        {
            this.member_id = member_id;
        }
        public int getMemberID()
        {
            return member_id;
        }
        public void setName(string name)
        {
            this.name = name;
        }
        public string getName()
        {
            return name;
        }
        public void setStudentID(string student_id)
        {
            this.student_id = student_id;
        }
        public string getStudentID()
        {
            return student_id;
        }
        public void setAddress(string address)
        {
            this.address = address;
        }
        public string getAddress()
        {
            return address;
        }
        public void setEmail(string email)
        {
            this.email = email;
        }
        public string getEmail()
        {
            return email;
        }
        public void setPhoneNumber(string phone_number)
        {
            this.phone_number = phone_number;
        }
        public string getPhoneNumber()
        {
            return phone_number;
        }
        public void setMobileNumber(string mobile_number)
        {
            this.mobile_number = mobile_number;
        }
        public string getMobileNumber()
        {
            return mobile_number;
        }
        public void setImage(string image)
        {
            this.image = image;
        }
        public string getImage()
        {
            return image;
        }
        public void setMemberTypeID(int membertype_id)
        {
            this.membertype_id = membertype_id;
        }
        public int getMemberTypeID()
        {
            return membertype_id;
        }
        public void setDepartmentID(int department_id)
        {
            this.department_id = department_id;
        }
        public int getDepartmentID()
        {
            return department_id;
        }
        public void setCreateDate(string create_date)
        {
            this.create_date = create_date;
        }
        public string getCreateDate()
        {
            return create_date;
        }
        public void setExpireDate(string expire_date)
        {
            this.expire_date = expire_date;
        }
        public string getExpireDate()
        {
            return expire_date;
        }

        public string getExpireDateByID(string member_id)
        {
            string expire_date = "";
            string strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();
            string strSQL = "SELECT Expire_date FROM Member_Info WHERE Member_id = '" + member_id + "'";
            SqlCommand com = new SqlCommand();
            SqlDataReader dr;
            com.Connection = Conn;
            com.CommandType = CommandType.Text;
            com.CommandText = strSQL;
            dr = com.ExecuteReader();

            if (dr.Read())
            {
                try
                {
                    expire_date = DateTime.Parse(dr[0].ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));

                }
                catch (InvalidCastException)
                {

                }
            }

            dr.Close();
            return expire_date;
        }


    }
}
