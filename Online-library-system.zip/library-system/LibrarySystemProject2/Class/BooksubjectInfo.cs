﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace LibrarySystemProject2.Class
{
    public class BooksubjectInfo
    {
        int book_total, maxID;
        string booksubject_name,msg;

       
        public void setBooksubjectName(string booksubject_name)
        {
            this.booksubject_name = booksubject_name;
        }
        public string getBooksubjectName()
        {
            return booksubject_name;
        }
        public void setBookTotal(string book_name)
        {
            string strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();
            string strSQL = "SELECT Book_total FROM Book_Subject WHERE Booksubject_id = '" + book_name + "' ";
            SqlCommand com = new SqlCommand();
            SqlDataReader dr;
            com.Connection = Conn;
            com.CommandType = CommandType.Text;
            com.CommandText = strSQL;
            dr = com.ExecuteReader();

            if (dr.Read())
            {
                try
                {
                    int i = Convert.ToInt32(dr["Book_total"]);
                    book_total = i+1;
                }
                catch (InvalidCastException)
                {
                    msg = "error";
                }
            }
            dr.Close();
            
        }
        public int getBookTotal()
        {
            return book_total;
        }
        public int getMaxID()
        {
            string strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();
            string strSQL = "SELECT MAX(Booksubject_id) FROM Book_Subject";
            SqlCommand com = new SqlCommand();
            SqlDataReader dr;
            com.Connection = Conn;
            com.CommandType = CommandType.Text;
            com.CommandText = strSQL;
            dr = com.ExecuteReader();

            if (dr.Read())
            {
                try
                {
                    int data = Convert.ToInt32(dr[0]);
                    maxID = data + 1;
                }
                catch (InvalidCastException)
                {
                    msg = "error";
                }
            }
            dr.Close();
            return maxID;
        }
        public string getMessage()
        {
            return msg;
        }

    }
}
