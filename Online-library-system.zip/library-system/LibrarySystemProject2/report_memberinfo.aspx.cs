﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace LibrarySystemProject2
{
    public partial class WebForm23 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //dropdownadditem();
            
        }

        protected void dropdownadditem()
        {
            if (DropDownList1.Items.Equals("--Select All--") == false && DropDownList2.Items.Equals("--Select All--") == false)
            {
                DropDownList1.Items.Add(new ListItem("--Select All--", "valueEmpty"));
                DropDownList2.Items.Add(new ListItem("--Select All--", "valueEmpty"));
            }
            
        }

        protected void binddataMemberReport()
        {
            string strConn = "";
            string sqlReport = "";
            string ddvaluemembertype = DropDownList1.SelectedItem.Value;
            string ddvaluedepartment = DropDownList2.SelectedItem.Value;

            if(DropDownList1.SelectedItem.Value == "--Select All--")
            {
                ddvaluemembertype = "";
            }
            if (DropDownList2.SelectedItem.Value == "--Select All--")
            {
                ddvaluedepartment = "";
            }

            try
            {

                strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;


                if (ddvaluemembertype != "" && ddvaluedepartment != "")
                {
                    sqlReport = "SELECT Member_Info.Name, Member_Info.Student_id, Member_Info.Address, ";
                    sqlReport += " Member_Type.Membertype_name, Department.Department_name";
                    sqlReport += " FROM Member_Info, Member_Type, Department";
                    sqlReport += " WHERE Member_Type.Membertype_id = Member_Info.Membertype_id";
                    sqlReport += " AND Member_Info.Department_id = Department.Department_id";
                    sqlReport += "  AND Member_Type.Membertype_name LIKE '%" + ddvaluemembertype + "%'";
                    sqlReport += "  AND Department.Department_name LIKE '%" + ddvaluedepartment + "%'";
                }
                else if (ddvaluemembertype == "" && ddvaluedepartment != "")
                {
                    sqlReport = "SELECT Member_Info.Name, Member_Info.Student_id, Member_Info.Address, ";
                    sqlReport += " Member_Type.Membertype_name, Department.Department_name";
                    sqlReport += " FROM Member_Info, Member_Type, Department";
                    sqlReport += " WHERE Member_Type.Membertype_id = Member_Info.Membertype_id";
                    sqlReport += " AND Member_Info.Department_id = Department.Department_id";
                    sqlReport += "  AND Department.Department_name LIKE '%" + ddvaluedepartment + "%'";
                }
                else if (ddvaluedepartment == "" && ddvaluemembertype != "")
                {
                    sqlReport = "SELECT Member_Info.Name, Member_Info.Student_id, Member_Info.Address, ";
                    sqlReport += " Member_Type.Membertype_name, Department.Department_name";
                    sqlReport += " FROM Member_Info, Member_Type, Department";
                    sqlReport += " WHERE Member_Type.Membertype_id = Member_Info.Membertype_id";
                    sqlReport += " AND Member_Info.Department_id = Department.Department_id";
                    sqlReport += "  AND Member_Type.Membertype_name LIKE '%" + ddvaluemembertype + "%'";
                }
                else
                {
                    sqlReport = "SELECT Member_Info.Name, Member_Info.Student_id, Member_Info.Address, ";
                    sqlReport += " Member_Type.Membertype_name, Department.Department_name";
                    sqlReport += " FROM Member_Info, Member_Type, Department";
                    sqlReport += " WHERE Member_Type.Membertype_id = Member_Info.Membertype_id";
                    sqlReport += " AND Member_Info.Department_id = Department.Department_id";
                }

                SqlConnection Conn = new SqlConnection(strConn);
                Conn.Open();


                SqlDataAdapter da = new SqlDataAdapter(sqlReport, Conn);
                DataSet ds = new DataSet();
                da.Fill(ds, "Report");

                GridView1.DataSource = ds.Tables["Report"];
                GridView1.DataBind();

                Conn.Close();
            }
            catch (Exception er)
            {

                Label4.Text = "The system can not show the data, Please try again : " + er;
                GridView1.Visible = false;

            }

            int gridviewrow = GridView1.Rows.Count;
            if (gridviewrow != 0)
            {
                GridView1.Visible = true;
                exportexcel.Enabled = true;
                exportword.Enabled = true;
                Label5.Text = "Library Report information of member type : " + ddvaluemembertype + ", Department : " + ddvaluedepartment;

            }
            else
            {
                exportexcel.Enabled = false;
                exportword.Enabled = false;
                Label5.Text = "Not found member information";
                

            }



        }



        void ExportData(string _contentType, string fileName)
        {

            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment;filename=" + fileName);
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = _contentType;
            StringWriter sw = new StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            HtmlForm frm = new HtmlForm();
            frm.Attributes["runat"] = "server";
            frm.Controls.Add(Label5);
            frm.Controls.Add(GridView1);
            Label5.RenderControl(htw);
            GridView1.AllowPaging = false;
            binddataMemberReport();
            GridView1.RenderControl(htw);
            Response.Write(sw.ToString());
            Response.End();
        }

        void paggingcontrol()
        {
            GridView1.AllowPaging = false;
        }


        protected void exportexcel_Click(object sender, EventArgs e)
        {

            ExportData("application/vnd.xls", "Library_Member_Info_Report.xls");

        }

        protected void exportword_Click(object sender, EventArgs e)
        {

            ExportData("application/vnd.word", "Library_Member_Info_Report.doc");

        }






        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            binddataMemberReport();
        }

        protected void viewreport_Click(object sender, EventArgs e)
        {
            binddataMemberReport();
        }

        

        
    }
}
