﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using CAMT;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2
{
    public partial class Book_type : System.Web.UI.Page
    {
        SqlConnection objConn;
        SqlCommand objCmd;
        String strSQL;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();
        String strConnString  = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            if (!Page.IsPostBack)
            {
                BindData();
            }
        }
        protected void Add_Click(object sender, EventArgs e)
        {
            BookType booktype = new BookType();
            BookTypeDAO booktypeDAO = new BookTypeDAO();

            booktype.setBookTypeName(Booktype.Text.ToString());
            booktypeDAO.addBookType(booktype);

            text.Text = booktypeDAO.getMessage();
            BindData();
            //Response.Redirect("Book_type.aspx");
            
        }
        protected void BindData()
        {
            String strSQL;
            strSQL = "SELECT * FROM Book_Type";
            /*
            SqlDataReader dtReader;
            objCmd = new SqlCommand(strSQL, objConn);
            dtReader = objCmd.ExecuteReader();
            
            dtAdapter.SelectCommand = objCmd;
            //*** BindData to GridView /
            myGridView.DataSource = dtReader;
            myGridView.AllowPaging = true;
            myGridView.DataBind();

            dtReader.Close();
            dtReader = null;
            */
            SqlConnection objConn = new SqlConnection(strConnString);
            SqlCommand objCmd = new SqlCommand();
            SqlDataAdapter dtAdapter = new SqlDataAdapter();

            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;


            dtAdapter.SelectCommand = objCmd;

            dtAdapter.Fill(ds);

            //*** BindData to GridView ***//
            myGridView.DataSource = ds;
            myGridView.AllowPaging = true;
            myGridView.DataBind();

            dtAdapter = null;
            objConn.Close();
            objConn = null;
        }

        protected void Page_UnLoad()
        {
            objConn.Close();
            objConn = null;
        }

        protected void EditCommand(object sender, GridViewEditEventArgs e)
        {
            myGridView.EditIndex = e.NewEditIndex;
            myGridView.ShowFooter = false;
            BindData();
        }

        protected void modCancelCommand(object sender, GridViewCancelEditEventArgs e)
        {
            myGridView.EditIndex = -1;
            myGridView.ShowFooter = false;
            BindData();
        }

        protected void modDeleteCommand(object sender, GridViewDeleteEventArgs e)
        {
            strSQL = "DELETE FROM Book_Type WHERE Booktype_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";
            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                text.Text = "Delete book type successful";
            }
            catch (Exception ex)
            {
                text.Text = "Can't delete book type";
                //Response.Write("Cannot delete");
            }

            myGridView.EditIndex = -1;
            BindData();
        }

        protected void modUpdateCommand(object sender, GridViewUpdateEventArgs e)
        {
            //*** Name ***//
            TextBox txtName = (TextBox)myGridView.Rows[e.RowIndex].FindControl("txtEditName");
            
            strSQL = "UPDATE Book_Type SET Booktype_name = '" + txtName.Text + "'WHERE Booktype_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";

            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                text.Text = "Update book type successful";
                //Response.Write(txtName.Text);
            }
            catch (Exception ex)
            {
                text.Text = "Can't update book type";
                //Response.Write(ex.Message);
            }


            myGridView.EditIndex = -1;
            myGridView.ShowFooter = false;
            BindData();
        }
        protected void myGridView_RowDataBound(Object s, GridViewRowEventArgs e)
        {
            string totalRecord = this.myGridView.Rows.Count.ToString();
            int totalRows = Convert.ToInt16(totalRecord) + 1;
            //*** No. ***//
            Label No = (Label)(e.Row.FindControl("No"));

            if (No != null)
            {
                No.Text = "" + totalRows + "";
            }


        }
        protected void ShowPageCommand(Object s, GridViewPageEventArgs e)
        {
            myGridView.PageIndex = e.NewPageIndex;
            BindData();
        }
    }
}
