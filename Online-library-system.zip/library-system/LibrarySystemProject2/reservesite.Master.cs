﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace LibrarySystemProject2
{
    public partial class reservesite : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserAuthentication"] == null)
            {
                Response.Redirect("Default.aspx");
            }
            Session.Remove("xtable");
            Session.Remove("book");
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session.Remove("UserAuthentication");
            Response.Redirect("Default.aspx");
            Logout.Text = "Log Out";

        }
    }
}
