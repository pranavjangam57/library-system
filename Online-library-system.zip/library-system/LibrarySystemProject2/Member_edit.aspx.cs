﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Web.Configuration;
using System.Globalization;

namespace LibrarySystemProject2
{
    public partial class Member_edit : System.Web.UI.Page
    {
        SqlConnection objConn = new SqlConnection();
        SqlCommand objCmd = new SqlCommand();
        String strConnString, strSQL;
        string CurrentFileName, CurrentPath;
        System.Globalization.CultureInfo locale = new System.Globalization.CultureInfo("en-US");

        MemberInfo member = new MemberInfo();
        MemberInfoDAO memberDAO = new MemberInfoDAO();

        protected void Page_Init()
        {
            Member_panel.Visible = false;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            Search.Click += new EventHandler(Search_Click);
            //UpdateProgress1.DisplayAfter = 100;
            //UpdateProgress1.Visible = true;
            //UpdateProgress1.DynamicLayout = true;
        }
        protected void Save_Click(object sender, EventArgs e)
        {
            CurrentFileName = Picture.FileName;
            CurrentPath = Server.MapPath("~/MemberPic/");

            member.setMemberID(Convert.ToInt32(Member_id.Text));
            member.setCallname(Callname.SelectedValue);
            member.setName(Name.Text.ToString());
            member.setMemberTypeID(Convert.ToInt32(Membertype.SelectedValue));
            member.setDepartmentID(Convert.ToInt32(Department.SelectedValue));
            member.setStudentID(Studentcode.Text.ToString());
            member.setAddress(Address.Text.ToString());
            member.setPhoneNumber(Telephone.Text.ToString());
            member.setCreateDate(Registerdate.Text);
            member.setExpireDate(Expiredate.Text);
            member.setEmail(Email.Text.ToString());
            member.setMobileNumber(Mobile.Text.ToString());
            member.setImage(CurrentFileName.ToString());
            strSQL = "UPDATE Member_Info SET ";
            strSQL += "Name = '" + member.getName() + "',Student_id = '" + member.getStudentID() + "',Address = '" + member.getAddress() + "'";
            strSQL += ",Email = '" + member.getEmail() + "',Phone_number = '" + member.getPhoneNumber() + "',Mobile_number = '" + member.getMobileNumber() + "'";
            strSQL += ",Create_date = Convert(datetime, '" + member.getCreateDate() + "', 103),Expire_date = Convert(datetime, '" + member.getExpireDate() + "', 103)";
            strSQL += ",Membertype_id = '" + member.getMemberTypeID() + "',Department_id = '" + member.getDepartmentID() + "'";
            strSQL += ",Callname = '"+member.getCallname()+"'";


            if (Picture.HasFile)
            {
                FileInfo pic = new FileInfo(System.Web.Hosting.HostingEnvironment.MapPath("~/MemberPic/" + Picname.Text));
                if (pic.Exists)
                {
                    //pic.Delete();
                    //Response.Write(Picname.Text);
                }
                member.setImage(CurrentFileName.ToString()); 

                CurrentPath += CurrentFileName;
                Picture.SaveAs(CurrentPath);

                strSQL += " ,Image = '" + member.getImage() + "' WHERE Member_id = '" + member.getMemberID() + "'";
                member.setSqlQueuery(strSQL);
                memberDAO.editMember(member);
                
            }
            else
            {
                strSQL += " WHERE Member_id = '" + member.getMemberID() + "'";
                member.setSqlQueuery(strSQL);
                memberDAO.editMember(member);
            }


            Message.Visible = true;
            Message.Text = memberDAO.getMessage();
            Member_panel.Visible = true;
            //Message.Text = "Update member information success";

        }

        protected void Search_Click(object sender, EventArgs e)
        {
            searchmsg.Text = "";
            //System.Threading.Thread.Sleep(300); //ของหน่วงเวลาจะได้เห็น
            Member_panel.Visible = true;
            viewData();
        }
        public void viewData()
        {

            Message.Visible = false;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            //*** DataTable ***//
            SqlDataAdapter dtAdapter;
            DataTable dt = new DataTable();
            strSQL = "SELECT * FROM Member_Info WHERE " + Selected.SelectedValue + " = '" + this.Input_search.Text + "'";
            //strSQL = "SELECT * FROM Member_Info WHERE Member_id = 3";
            dtAdapter = new SqlDataAdapter(strSQL, objConn);
            dtAdapter.Fill(dt);
            
            if (dt.Rows.Count > 0 && dt.Rows.Count <= 1)
            {
                string registerdate = DateTime.Parse(dt.Rows[0]["Create_date"].ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                string expiredate = DateTime.Parse(dt.Rows[0]["Expire_date"].ToString()).ToString("dd/MM/yyyy", new CultureInfo("en-US"));

                this.Picname.Text = (string)dt.Rows[0]["Image"];
                this.Member_id.Text = Convert.ToString(dt.Rows[0]["Member_id"]);
                this.Image1.ImageUrl = "MemberPic/" + (string)dt.Rows[0]["Image"];
                this.Callname.SelectedValue = Convert.ToString( dt.Rows[0]["Callname"]);
                this.Name.Text = (string)dt.Rows[0]["Name"];
                this.Membertype.SelectedValue = Convert.ToString(dt.Rows[0]["Membertype_id"]);
                this.Department.SelectedValue = Convert.ToString(dt.Rows[0]["Department_id"]);
                this.Studentcode.Text = (string)dt.Rows[0]["Student_id"];
                this.Address.Text = (string)dt.Rows[0]["Address"];
                this.Mobile.Text = (string)dt.Rows[0]["Mobile_number"];
                this.Telephone.Text = (string)dt.Rows[0]["Phone_number"];
                this.Email.Text = (string)dt.Rows[0]["Email"];
                this.Registerdate.Text = registerdate;
                this.Expiredate.Text = expiredate;
            }
            else
            {
                Member_panel.Visible = false;
                //Message.Visible = true;
                searchmsg.Text = "Not found this member information";
                
            }
            
            objConn.Close();
            objConn = null;
        }
      
    }
}
