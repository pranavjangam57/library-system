﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Net.Mail;
using System.Net;

namespace LibrarySystemProject2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserAuthentication"] == null)
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                //querymailinfo();
            }


        }

        protected void querymailinfo()
        {
            string mailbody = "";
            string mailaddress = "";
            mailbody = "Library Management System :: College of Arts, Media and Technology<br>";
            mailbody += "Email Notification : แจ้งเตือนการคืนหนังสือ<br>";
            mailbody += "--------------------------------------------------------------------------------<br><br>";
            mailaddress = "wiriya_007@hotmail.com";
            sendmail(mailbody, mailaddress);

        }


        protected void sendmail(string mailbody, string mailaddress)
        {

            
            
            System.Net.Mail.MailMessage myMail = new System.Net.Mail.MailMessage();
            System.Net.NetworkCredential Cred = new System.Net.NetworkCredential("camtlibrary@gmail.com", "camtlibrary1234");

            myMail.To.Add(mailaddress);
            myMail.Subject = "CAMT Library : Email Notification : แจ้งเตือนการคืนหนังสือ!";

            myMail.From = new System.Net.Mail.MailAddress("camtlibrary@gmail.com");
            myMail.IsBodyHtml = true;
            myMail.Body = mailbody;

            System.Net.Mail.SmtpClient SmtpMail = new System.Net.Mail.SmtpClient();
            SmtpMail.Host = "smtp.gmail.com";
            SmtpMail.UseDefaultCredentials = false;
            SmtpMail.EnableSsl = true;
            SmtpMail.Credentials = Cred;
            SmtpMail.Port = 587;
            SmtpMail.Send(myMail);
            myMail = null;
        }

    }
}
