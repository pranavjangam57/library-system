﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;
using LibrarySystemProject2.Class;
using LibrarySystemProject2.DAO;

namespace LibrarySystemProject2
{
    public partial class Book_subject : System.Web.UI.Page
    {
        SqlConnection objConn;
        SqlCommand objCmd;
        String strSQL;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();
        String strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            objConn = new SqlConnection(strConnString);
            objConn.Open();
            MultiView1.SetActiveView(View1);

            if (!Page.IsPostBack)
            {
                BindData();
            }
        }
        protected void BindData()
        {
            String strSQL;
            strSQL = "SELECT * FROM Book_Subject";

            SqlConnection objConn = new SqlConnection(strConnString);
            SqlCommand objCmd = new SqlCommand();
            SqlDataAdapter dtAdapter = new SqlDataAdapter();

            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;


            dtAdapter.SelectCommand = objCmd;

            dtAdapter.Fill(ds);

            //*** BindData to GridView ***//
            myGridView.DataSource = ds;
            myGridView.AllowPaging = true;
            myGridView.DataBind();

            dtAdapter = null;
            objConn.Close();
            objConn = null;
        }

        protected void Page_UnLoad()
        {
            objConn.Close();
            objConn = null;
        }

        protected void EditCommand(object sender, GridViewEditEventArgs e)
        {
            myGridView.EditIndex = e.NewEditIndex;
            myGridView.ShowFooter = true;
            BindData();
        }

        protected void modCancelCommand(object sender, GridViewCancelEditEventArgs e)
        {
            myGridView.EditIndex = -1;
            myGridView.ShowFooter = true;
            BindData();
        }

        protected void modUpdateCommand(object sender, GridViewUpdateEventArgs e)
        {
            //*** Name ***//
            TextBox txtName = (TextBox)myGridView.Rows[e.RowIndex].FindControl("txtEditName");

            strSQL = "UPDATE Book_Subject SET Booksubject_name = '" + txtName.Text + "'WHERE Booksubject_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";

            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                msg.Text = "Update book subject successful";
            }
            catch (Exception ex)
            {
                msg.Text = "Can't update book subject";
            }


            myGridView.EditIndex = -1;
            myGridView.ShowFooter = true;
            BindData();
        }
        protected void myGridView_RowDataBound(Object s, GridViewRowEventArgs e)
        {
            string totalRecord = this.myGridView.Rows.Count.ToString();
            int totalRows = Convert.ToInt16(totalRecord) + 1;
            //*** No. ***//
            Label No = (Label)(e.Row.FindControl("No"));

            if (No != null)
            {
                No.Text = "" + totalRows + "";
            }


        }
        protected void ShowPageCommand(Object s, GridViewPageEventArgs e)
        {
            myGridView.PageIndex = e.NewPageIndex;
            BindData();
        }

        protected void Add_bt_Click(object sender, EventArgs e)
        {
            BooksubjectInfo booksubject = new BooksubjectInfo();
            BooksubjectInfoDAO booksubjectDAO = new BooksubjectInfoDAO();
            booksubject.setBooksubjectName(txtBookSubject.Text);
            booksubjectDAO.newBookSubject(booksubject);
            msg.Text = booksubjectDAO.getMessage().ToString();
            BindData();
            //Response.Redirect("Book_subject.aspx");
        }
    }
}
