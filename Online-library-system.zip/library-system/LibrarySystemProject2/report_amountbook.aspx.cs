﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;

namespace LibrarySystemProject2
{
    public partial class WebForm16 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        void BinddataBookfineReport()
        {

            string strConn = "";
            string sqlReport = "";
            Boolean checktext = true;
            string booksinfodd = DropDownList1.SelectedItem.Value;
            string bookinfoinput = inputbox.Text;
            string bookstatusdd = DropDownList2.SelectedItem.Value;
            string detailoftable = "";
            strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            if (inputbox.Text == "" && booksinfodd != "--Select All--")
            {
                //Response.Write("<script language='javascript'>");
                //Response.Write("alert('Please fill all information')");
                //Response.Write("</script>");
                Label5.Text = "Please fill all information";
                checktext = false;
                GridView1.Visible = false;
            }
            else
            {

                try
                {
                    booksinfodd = DropDownList1.SelectedItem.Value;
                    bookinfoinput = inputbox.Text;
                    bookstatusdd = DropDownList2.SelectedItem.Value;


                    if (booksinfodd == "Register number")
                    {
                        sqlReport = "SELECT Book_Info.Register_number, Book_Info.Call_number, Book_Info.ISBN, Book_Info.Title, Book_Status.Bookstatus_name";
                        sqlReport += " FROM Book_Info, Book_Status";
                        sqlReport += " WHERE Book_Info.Register_number = '" + bookinfoinput + "'";
                        sqlReport += " AND Book_Status.Bookstatus_name = '" + bookstatusdd + "'";
                        sqlReport += " AND Book_Info.Bookstatus_id=Book_Status.Bookstatus_id";
                        sqlReport += " ORDER BY Register_number";
                        detailoftable = booksinfodd + " : " + bookinfoinput;
                    }
                    else if (booksinfodd == "Call number")
                    {
                        sqlReport = "SELECT Book_Info.Register_number, Book_Info.Call_number, Book_Info.ISBN, Book_Info.Title, Book_Status.Bookstatus_name";
                        sqlReport += " FROM Book_Info, Book_Status";
                        sqlReport += " WHERE Book_Info.Call_number = '" + bookinfoinput + "'";
                        sqlReport += " AND Book_Status.Bookstatus_name = '" + bookstatusdd + "'";
                        sqlReport += " AND Book_Info.Bookstatus_id=Book_Status.Bookstatus_id";
                        sqlReport += " ORDER BY Register_number";
                        detailoftable = booksinfodd + " : " + bookinfoinput;
                    }
                    else if (booksinfodd == "ISBN")
                    {
                        sqlReport = "SELECT Book_Info.Register_number, Book_Info.Call_number, Book_Info.ISBN, Book_Info.Title, Book_Status.Bookstatus_name";
                        sqlReport += " FROM Book_Info, Book_Status";
                        sqlReport += " WHERE Book_Info.ISBN = '" + bookinfoinput + "'";
                        sqlReport += " AND Book_Status.Bookstatus_name = '" + bookstatusdd + "'";
                        sqlReport += " AND Book_Info.Bookstatus_id=Book_Status.Bookstatus_id";
                        sqlReport += " ORDER BY Register_number";
                        detailoftable = booksinfodd + " : " + bookinfoinput;
                    }

                    else if (booksinfodd == "Title")
                    {
                        sqlReport = "SELECT Book_Info.Register_number, Book_Info.Call_number, Book_Info.ISBN, Book_Info.Title, Book_Status.Bookstatus_name";
                        sqlReport += " FROM Book_Info, Book_Status";
                        sqlReport += " WHERE Book_Info.Title = '" + bookinfoinput + "'";
                        sqlReport += " AND Book_Status.Bookstatus_name = '" + bookstatusdd + "'";
                        sqlReport += " AND Book_Info.Bookstatus_id=Book_Status.Bookstatus_id";
                        sqlReport += " ORDER BY Register_number";
                        detailoftable = booksinfodd + " : " + bookinfoinput;
                    }


                    else if (booksinfodd == "--Select All--")
                    {
                        sqlReport = "SELECT Book_Info.Register_number, Book_Info.Call_number, Book_Info.ISBN, Book_Info.Title, Book_Status.Bookstatus_name";
                        sqlReport += " FROM Book_Info, Book_Status";
                        sqlReport += " WHERE Book_Status.Bookstatus_name = '" + bookstatusdd + "'";
                        sqlReport += " AND Book_Info.Bookstatus_id=Book_Status.Bookstatus_id";
                        sqlReport += " ORDER BY Register_number";
                        detailoftable = "all book";
                    }
                    else
                    {
                        sqlReport = "SELECT Book_Info.Register_number, Book_Info.Call_number, Book_Info.ISBN, Book_Info.Title, Book_Status.Bookstatus_name";
                        sqlReport += " FROM Book_Info, Book_Status";
                        sqlReport += " WHERE Book_Info.Bookstatus_id=Book_Status.Bookstatus_id";
                        sqlReport += " ORDER BY Register_number";

                    }

                    SqlConnection Conn = new SqlConnection(strConn);
                    Conn.Open();


                    SqlDataAdapter da = new SqlDataAdapter(sqlReport, Conn);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "Report");

                    GridView1.DataSource = ds.Tables["Report"];
                    GridView1.DataBind();

                    Conn.Close();
                }
                catch (Exception er)
                {

                    Label5.Text = "The system can not show the data, cause of incorrect of input, Please try again : " + er;
                    GridView1.Visible = false;
                    checktext = false;
                    Label6.Text = "error" + er;
                }
            }

            int gridviewrow = GridView1.Rows.Count;


            if (gridviewrow != 0 && checktext == true)
            {
                GridView1.Visible = true;
                exportexcel.Enabled = true;
                exportword.Enabled = true;
                Label5.Text = "Library Report information book status " + bookstatusdd + " of " + detailoftable;

            }
            else
            {
                exportexcel.Enabled = false;
                exportword.Enabled = false;
                if (inputbox.Text == "")
                {
                    Label5.Text = "Please fill all information";
                }
                else
                {

                    Label5.Text = "Not found your input information";
                }

            }
        }
        
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BinddataBookfineReport();
        }

        void ExportData(string _contentType, string fileName)
        {

            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment;filename=" + fileName);
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = _contentType;
            StringWriter sw = new StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            HtmlForm frm = new HtmlForm();
            frm.Attributes["runat"] = "server";
            frm.Controls.Add(Label5);
            frm.Controls.Add(GridView1);
            Label5.RenderControl(htw);
            GridView1.AllowPaging = false;
            BinddataBookfineReport();
            GridView1.RenderControl(htw);
            Response.Write(sw.ToString());
            Response.End();
        }

        protected void viewreport_Click(object sender, EventArgs e)
        {
            BinddataBookfineReport();
        }

        protected void exportexcel_Click(object sender, EventArgs e)
        {

            ExportData("application/vnd.xls", "Library_amount_of_book_Report.xls");

        }

        protected void exportword_Click(object sender, EventArgs e)
        {

            ExportData("application/vnd.word", "Library_amount_of_book_Report.doc");

        }

    }
}
