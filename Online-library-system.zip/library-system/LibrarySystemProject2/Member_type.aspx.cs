﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using LibrarySystemProject2.DAO;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2
{
    public partial class Member_type : System.Web.UI.Page
    {
        SqlConnection objConn;
        SqlCommand objCmd;
        String strSQL;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();

        protected void Page_Load(object sender, EventArgs e)
        {
            String strConnString;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();
            
            if (!Page.IsPostBack)
            {
                BindData();
            }
        }
        protected void Add_Click(object sender, EventArgs e)
        {
            MemberType membertype = new MemberType();
            MemberTypeDAO membertypeDAO = new MemberTypeDAO();

            membertype.setMemberTypeName(Input.Text.ToString());
            membertypeDAO.addNewMemberType(membertype);
            text.Text = membertypeDAO.getMessage();
            BindData();
            //Response.Redirect("Member_type.aspx");

        }
        protected void BindData()
        {
            String strSQL;
            strSQL = "SELECT * FROM Member_Type";

            SqlDataReader dtReader;
            objCmd = new SqlCommand(strSQL, objConn);
            dtReader = objCmd.ExecuteReader();

            dtAdapter.SelectCommand = objCmd;
            //*** BindData to GridView ***//
            myGridView.DataSource = dtReader;
            myGridView.DataBind();

            dtReader.Close();
            dtReader = null;

        }

        protected void Page_UnLoad()
        {
            objConn.Close();
            objConn = null;
        }

        protected void EditCommand(object sender, GridViewEditEventArgs e)
        {
            myGridView.EditIndex = e.NewEditIndex;
            myGridView.ShowFooter = false;
            BindData();
        }

        protected void modCancelCommand(object sender, GridViewCancelEditEventArgs e)
        {
            myGridView.EditIndex = -1;
            myGridView.ShowFooter = true;
            BindData();
        }

        protected void modDeleteCommand(object sender, GridViewDeleteEventArgs e)
        {
            strSQL = "DELETE FROM Member_Type WHERE Membertype_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";
            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                text.Text = "Delete member type successful";
            }
            catch(Exception ex)
            {
                text.Text = "can't delete this member type";
            }

            myGridView.EditIndex = -1;
            BindData();
        }

        protected void modUpdateCommand(object sender, GridViewUpdateEventArgs e)
        {
            string totalRecord = this.myGridView.Rows.Count.ToString();
            int totalRows = Convert.ToInt16(totalRecord) + 2;

            //*** Name ***//
            TextBox txtName = (TextBox)myGridView.Rows[e.RowIndex].FindControl("txtEditName");
           
            strSQL = "UPDATE Member_Type SET Membertype_name = '" + txtName.Text + "' WHERE Membertype_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";

            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                text.Text = "Update member type success";
            }
            catch (Exception ex)
            {
                text.Text = "can't update member type";
            }


            myGridView.EditIndex = -1;
            myGridView.ShowFooter = true;
            BindData();
        }

        protected void myGridView_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Add")
            {

                //*** Name ***//
                TextBox txtName = (TextBox)myGridView.FooterRow.FindControl("txtAddName");
                //*** Email ***//
                TextBox txtEmail = (TextBox)myGridView.FooterRow.FindControl("txtAddTotal");
                //*** CountryCode ***//


                strSQL = "INSERT INTO Member_Type (Membertype_name,Book_total) " +
                    " VALUES ('" + txtName.Text + "','" + txtEmail.Text + "') ";
                objCmd = new SqlCommand(strSQL, objConn);
                objCmd.ExecuteNonQuery();

                BindData();
            }

        }
        protected void myGridView_RowDataBound(Object s, GridViewRowEventArgs e)
        {
            string totalRecord = this.myGridView.Rows.Count.ToString();
            int totalRows = Convert.ToInt16(totalRecord) + 1;
            //*** No. ***//
            Label No = (Label)(e.Row.FindControl("lblMembertypeID"));

            if (No != null)
            {
                No.Text = "" + totalRows + "";
            }


        }
    }
}
