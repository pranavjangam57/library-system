﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Globalization;

namespace LibrarySystemProject2
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        DataTable dt1,dt2;
        int i = 0, j = 0;
        int totalFine = 0;
        Boolean check_duplicate = true;
        string dd_iden = "";

        //column fill in gridview
        string regno = "";
        string Callno = "";
        string Title = "";
        string membername = "";
        string duedate = "";
        DateTime date_return;
        //end
        string strConn;
        string sqlcheckborrowed = "";

        string bookinfodd = "";
        string bookinfoinput = "";

        SqlConnection Conn;
        SqlDataAdapter da;
        DateTime today = System.DateTime.Today.Date;
        DataRow dr;

        SqlConnection objConn;
        SqlCommand objCmd;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();

        protected void Page_Load(object sender, EventArgs e)
        {
            String strConnString;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            if (this.Session["xtable"] == null)
            {
                dt2= new DataTable();
                dt2.Columns.Add(new DataColumn("Register_number", typeof(string)));
                dt2.Columns.Add(new DataColumn("Call_number", typeof(string)));
                dt2.Columns.Add(new DataColumn("Title", typeof(string)));
                dt2.Columns.Add(new DataColumn("name", typeof(string)));
                dt2.Columns.Add(new DataColumn("Date_return", typeof(string)));
                dt2.Columns.Add(new DataColumn("Fine", typeof(string)));
                this.Session["xtable"] = dt2;
            }
            else
            {
                dt2 = (DataTable)this.Session["xtable"];
            }

        }


        protected void Binddata()
        {
            bookinfodd = DropDownList1.SelectedItem.Value;
            bookinfoinput = TextBox1.Text;
            MultiView1.Visible = true;
            MultiView1.SetActiveView(View1);
            

            strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            Conn = new SqlConnection(strConn);
            Conn.Open();

            if (bookinfodd == "Register No.")
            {
                sqlcheckborrowed = "SELECT History.Register_number, Book_Info.Call_number, Book_Info.Title, Member_Info.Name, History.Date_return";
                sqlcheckborrowed += " FROM History, Book_Info, Book_Status, Member_Info";
                sqlcheckborrowed += " WHERE History.Register_number = '" + TextBox1.Text + "'";
                sqlcheckborrowed += " AND Book_Status.Bookstatus_name = 'Borrowed'";
                sqlcheckborrowed += " AND Book_Status.Bookstatus_id = Book_Info.Bookstatus_id";
                sqlcheckborrowed += " AND Book_Info.Register_number = History.Register_number";
                sqlcheckborrowed += " AND History.Member_id = Member_Info.Member_id";
                sqlcheckborrowed += " AND History.Date_return_actual IS NULL";
                dd_iden = "Register Number";
            }
            else if (bookinfodd == "Call No.")
            {
                sqlcheckborrowed = "SELECT History.Register_number, Book_Info.Call_number, Book_Info.Title, Member_Info.Name, History.Date_return";
                sqlcheckborrowed += " FROM History, Book_Info, Book_Status, Member_Info";
                sqlcheckborrowed += " WHERE Book_Info.Call_number = '" + TextBox1.Text + "'";
                sqlcheckborrowed += " AND Book_Status.Bookstatus_name = 'Borrowed'";
                sqlcheckborrowed += " AND Book_Status.Bookstatus_id = Book_Info.Bookstatus_id";
                sqlcheckborrowed += " AND Book_Info.Register_number = History.Register_number";
                sqlcheckborrowed += " AND History.Member_id = Member_Info.Member_id";
                sqlcheckborrowed += " AND History.Date_return_actual IS NULL";
                dd_iden = "Call Number";
            }

            da = new SqlDataAdapter(sqlcheckborrowed, Conn);
            dt1 = new DataTable();
            try
            {

                da.Fill(dt1);
                
            }
            catch (Exception)
            {
                Label2.Text = "Can't fill table";
            }



            if (dt2.Rows.Count > 0)
            {
                for (j = 0; j < dt2.Rows.Count; j++)
                {
                    if (dd_iden == "Register Number")
                    {
                        string register_compare = "";
                        register_compare = (string)dt2.Rows[j]["Register_number"];
                        if (register_compare == bookinfoinput)
                        {
                            check_duplicate = false;
                        }
                        //Label4.Text = check_duplicate.ToString();
                    }
                    else if (dd_iden == "Call Number")
                    {
                        string call_compare = "";
                        call_compare = (string)dt2.Rows[j]["Call_number"];
                        if (call_compare == bookinfoinput)
                        {
                            check_duplicate = false;
                        }
                        //Label4.Text = check_duplicate.ToString();
                    }
                    
                }
                
            }
           

            int final_fine = 0;
            if (check_duplicate == true)
            {
                Label2.Text = "";
                if (dt1.Rows.Count > 0)
                {
                    regno = (string)dt1.Rows[0]["Register_number"];
                    Callno = (string)dt1.Rows[0]["Call_number"];
                    Title = (string)dt1.Rows[0]["Title"];
                    membername = (string)dt1.Rows[0]["Name"];
                    duedate = Convert.ToString(dt1.Rows[0]["Date_return"]);
                    date_return = (DateTime)dt1.Rows[0]["Date_return"];
                    if (today > date_return)
                    {
                        final_fine = (int)(today.Subtract((DateTime)dt1.Rows[0]["Date_return"]).Days) * 5;
                    }
                    else
                    {
                        final_fine = 0;
                    }

                }
                try
                {
                    dr = dt2.NewRow();
                    dr["Register_number"] = regno;
                    dr["Call_number"] = Callno;
                    dr["Title"] = Title;
                    dr["Name"] = membername;
                    dr["Date_return"] = Convert.ToString(dt1.Rows[0]["Date_return"]);
                    dr["Fine"] = final_fine;
                    dt2.Rows.Add(dr);
                }
                catch (Exception)
                {
                    Label2.Text = "Not found book return info";
                    if (GridView1.Rows.Count == 0)
                    {
                        MultiView1.Visible = false;
                    }
                }
                GridView1.DataSource = dt2;
                GridView1.DataBind();
                
                Conn.Close();
                Conn = null;

            }


            else
            {
                Label2.Text = "Book information of " + dd_iden + " : " + bookinfoinput + " are already in the list below";
            }
        }

        protected void view_binddata()
        {
            bookinfodd = DropDownList1.SelectedItem.Value;
            bookinfoinput = TextBox1.Text;
            MultiView1.Visible = true;
            MultiView1.SetActiveView(View1);


            strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            Conn = new SqlConnection(strConn);
            Conn.Open();

            if (bookinfodd == "Register No.")
            {
                sqlcheckborrowed = "SELECT History.Register_number, Book_Info.Call_number, Book_Info.Title, Member_Info.Name, History.Date_return";
                sqlcheckborrowed += " FROM History, Book_Info, Book_Status, Member_Info";
                sqlcheckborrowed += " WHERE History.Register_number = '" + TextBox1.Text + "'";
                sqlcheckborrowed += " AND Book_Status.Bookstatus_name = 'Borrowed'";
                sqlcheckborrowed += " AND Book_Status.Bookstatus_id = Book_Info.Bookstatus_id";
                sqlcheckborrowed += " AND Book_Info.Register_number = History.Register_number";
                sqlcheckborrowed += " AND History.Member_id = Member_Info.Member_id";
                sqlcheckborrowed += " AND History.Date_return_actual IS NULL";
                dd_iden = "Register Number";
            }
            else if (bookinfodd == "Call Number")
            {
                sqlcheckborrowed = "SELECT History.Register_number, Book_Info.Call_number, Book_Info.Title, Member_Info.Name, History.Date_return";
                sqlcheckborrowed += " FROM History, Book_Info, Book_Status, Member_Info";
                sqlcheckborrowed += " WHERE Book_Info.Call_number = '" + TextBox1.Text + "'";
                sqlcheckborrowed += " AND Book_Status.Bookstatus_name = 'Borrowed'";
                sqlcheckborrowed += " AND Book_Status.Bookstatus_id = Book_Info.Bookstatus_id";
                sqlcheckborrowed += " AND Book_Info.Register_number = History.Register_number";
                sqlcheckborrowed += " AND History.Member_id = Member_Info.Member_id";
                sqlcheckborrowed += " AND History.Date_return_actual IS NULL";
                dd_iden = "Call Number";
            }

            da = new SqlDataAdapter(sqlcheckborrowed, Conn);
            dt1 = new DataTable();
            try
            {

                da.Fill(dt1);
            }
            catch (Exception)
            {
                Label2.Text = "Can't fill table";
            }

            int final_fine = 0;

           // Label2.Text = "";
            if (dt1.Rows.Count > 0)
            {
                regno = (string)dt1.Rows[0]["Register_number"];
                Callno = (string)dt1.Rows[0]["Call_number"];
                Title = (string)dt1.Rows[0]["Title"];
                membername = (string)dt1.Rows[0]["Name"];
                duedate = Convert.ToString(dt1.Rows[0]["Date_return"]);
                final_fine = (int)(today.Subtract((DateTime)dt1.Rows[0]["Date_return"]).Days) * 5;

            }
            try
            {
                dr = dt2.NewRow();
                dr["Register_number"] = regno;
                dr["Call_number"] = Callno;
                dr["Title"] = Title;
                dr["Name"] = membername;
                dr["Date_return"] = Convert.ToString(dt1.Rows[0]["Date_return"]);
                dr["Fine"] = final_fine;
                dt2.Rows.Add(dr);
            }
            catch (Exception)
            {
                Label2.Text = "Not found book return info";
                if (GridView1.Rows.Count == 0)
                {
                    MultiView1.Visible = false;
                }
            }
            GridView1.DataSource = dt2;
            GridView1.DataBind();

            Conn.Close();
            Conn = null;


        }




        //protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        //{
         //   GridView1.DeleteRow((int)GridView1.DataKeys[e.RowIndex].value[0]);
         //   GridView1.DataBind();

        //}

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button2.Enabled = true;
            Binddata();
            TextBox1.Text = "";
        }
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                i += 1;

                totalFine += Convert.ToInt16(DataBinder.Eval(e.Row.DataItem, "Fine"));

            }
            else if (e.Row.RowType == DataControlRowType.Footer)
            {

                e.Row.Cells[7].Text = totalFine.ToString();
                e.Row.Cells[7].HorizontalAlign = HorizontalAlign.Center;
            }
        }

        protected void EditCommand(object sender, GridViewEditEventArgs e)
        {
            
            
        }
        protected void modUpdateCommand(object sender, GridViewUpdateEventArgs e)
        {
            
            
        }
        protected void modCancelCommand(object sender, GridViewCancelEditEventArgs e)
        {
            
        }


        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            
            //GridView1.DeleteRow((string)GridView1.DataKeys[e.RowIndex].value[0]);
            /*
            int k = 0;
            k = GridView1.SelectedRow.RowIndex;
            dt2.Rows.RemoveAt(k);
            Binddata();
            */
        }
        protected void CheckBox1_CheckedChanged1(object sender, EventArgs e)
        {
            CheckBox selectAllCheckBox = sender as CheckBox;
            
            foreach (GridViewRow gvr in GridView1.Rows)
            {
                CheckBox selectCheckBox = gvr.FindControl("checkfine") as CheckBox;
                selectCheckBox.Checked = selectAllCheckBox.Checked;
            }

        }

        protected int addbill(string reg_no, string fine)
        {
            string bill_number = "";
            string total_fine = "";
            string bill_date = "";
            string sqladdbill = "";
            string sqlqueryid = "";
            int returnbillid = 0;

                bill_number = reg_no + "_" + System.DateTime.Today.Date.ToString("MM_dd_yy");
                bill_date = DateTime.Today.ToString("MM/dd/yyyy", new CultureInfo("en-US"));
                total_fine = fine;

                sqladdbill = "INSERT INTO Bill (Bill_number, Total, Bill_date)";
                sqladdbill += " VALUES ('" + bill_number + "','" + total_fine + "','" + bill_date + "')";

                objCmd = new SqlCommand(sqladdbill, objConn);
                try
                {
                    objCmd.ExecuteNonQuery();
                    Label4.Text = "add bill successful ";
                }
                catch (Exception ex2)
                {

                    Label5.Text = "can't update history" + ex2;
                }

                strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
                Conn = new SqlConnection(strConn);
                Conn.Open();
                sqlqueryid = "SELECT Bill_id FROM Bill WHERE Bill_number = '" + bill_number + "' AND Total = '" + total_fine + "'";
                SqlDataAdapter daq = new SqlDataAdapter(sqlqueryid, Conn);
                DataTable dtq = new DataTable();
                try
                {

                    daq.Fill(dtq);
                }
                catch (Exception ex)
                {
                    Label6.Text = "Can't query bill id" + ex;
                }

                if (dtq.Rows.Count > 0)
                {
                    string billid = Convert.ToString(dtq.Rows[0]["Bill_id"]);
                    returnbillid = Convert.ToInt16(billid);
                }

                return returnbillid;
            
        }



        protected void update_book()
        {
            string register_num = "";
            string sqlupdatebook = "";

            for (int t = 0; t <= GridView1.Rows.Count - 1; t++)
            {
                register_num = (string)GridView1.Rows[t].Cells[2].Text;
                sqlupdatebook = "UPDATE Book_Info SET Member_id = NULL, Bookstatus_id = '1', Date_borrow = NULL, Date_return = NULL";
                sqlupdatebook += " WHERE Register_number = '" + register_num + "'";
                sqlupdatebook += " AND Bookstatus_id = '4'";
                sqlupdatebook += " AND Date_borrow IS NOT NULL";
                sqlupdatebook += " AND Date_return IS NOT NULL";


                objCmd = new SqlCommand(sqlupdatebook, objConn);
                try
                {
                    objCmd.ExecuteNonQuery();
                    Label4.Text = "Return book successful !!";
                }
                catch (Exception ex2)
                {

                    Label4.Text = "cant' return book cause of " + ex2;
                }
            }
        }



        protected void update_history()
        {
            int getresultbill = 0;
            string reg_num="";
            string date_return_actual;
            string finehis="";
            string finepay="";
            CheckBox box = new CheckBox();
            string sqlupdatehistory = "";

            for (int r = 0; r <= GridView1.Rows.Count - 1;r++)
            {
                reg_num = (string)GridView1.Rows[r].Cells[2].Text;
                date_return_actual = DateTime.Today.ToString("MM/dd/yyyy", new CultureInfo("en-US"));
                finehis = (string)GridView1.Rows[r].Cells[7].Text;
                box = (CheckBox)GridView1.Rows[r].FindControl("checkfine");
                if (box.Checked)
                {
                    finepay = "False";
                }
                else
                {
                    finepay = "True";
                }

                if (finehis != "0" )
                {
                    if (finepay == "True")
                    {
                        getresultbill = addbill(reg_num, finehis);

                        sqlupdatehistory = "UPDATE History SET Bill_id = '" + getresultbill + "', Date_return_actual = Convert(datetime,'" + date_return_actual + "',103)";
                        sqlupdatehistory += ", Fine = '" + finehis + "', Fine_pay = '" + finepay + "'";
                        sqlupdatehistory += " WHERE Register_number = '" + reg_num + "' AND Date_return_actual IS NULL";
                    }
                    else if (finepay == "False")
                    {
                        sqlupdatehistory = "UPDATE History SET Bill_id = NULL, Date_return_actual = Convert(datetime,'" + date_return_actual + "',103)";
                        sqlupdatehistory += ", Fine = '" + finehis + "', Fine_pay = '" + finepay + "'";
                        sqlupdatehistory += " WHERE Register_number = '" + reg_num + "' AND Date_return_actual IS NULL";
                    }


                }
                else if (finehis == "0")
                {

                sqlupdatehistory = "UPDATE History SET Bill_id = NULL, Date_return_actual = Convert(datetime,'" + date_return_actual + "',103)";
                sqlupdatehistory += ", Fine = '" + finehis + "', Fine_pay = '" + finepay + "'";
                sqlupdatehistory += " WHERE Register_number = '" + reg_num + "' AND Date_return_actual IS NULL";
                }
                
                objCmd = new SqlCommand(sqlupdatehistory, objConn);
                try
                {
                    objCmd.ExecuteNonQuery();
                    Label4.Text = "Return book successful !!";
                }
                catch (Exception ex2)
                {

                    Label4.Text = "cant' return book cause of " + ex2;
                }

            }
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            update_history();
            update_book();
            TextBox1.Text = "";
            Session.Remove("xtable");
            Button2.Enabled = false;
        }


        protected void Tabshow_Click(object sender, EventArgs e)
        {
            Show_panel.Visible = true;
        }

        protected void Tabhide_Click(object sender, EventArgs e)
        {
            Show_panel.Visible = false;
        }

        protected void Tabshow_Click2(object sender, EventArgs e)
        {
            Show_panel2.Visible = true;
        }

        protected void Tabhide_Click2(object sender, EventArgs e)
        {
            Show_panel2.Visible = false;
        }

    }
}
