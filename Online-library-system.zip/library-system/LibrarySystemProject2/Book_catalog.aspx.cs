﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using CAMT;
using LibrarySystemProject2.Class;
using LibrarySystemProject2.DAO;
using System.Globalization;

namespace LibrarySystemProject2
{
    public partial class Book_catalog : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string today = DateTime.Today.ToString("dd/MM/yyyy", new CultureInfo("en-US"));
            this.DateImport.Text = today;
        }

        protected void NewAuthor_bt_CheckedChanged(object sender, EventArgs e)
        {
            if((NewAuthor_bt.Checked==true))
            {
                NewAuthor.Enabled = true;
                AuthorList.Enabled = false;
            }
        }

        protected void SelectAuthor_bt_CheckedChanged(object sender, EventArgs e)
        {
            if((SelectAuthor_bt.Checked==true))
            {
                AuthorList.Enabled = true;
                NewAuthor.Enabled = false;
            }
        }

        protected void Newsubject_bt_CheckedChanged(object sender, EventArgs e)
        {
            if((Newsubject_bt.Checked==true))
            {
                NewSubject.Enabled = true;
                BookSubject.Enabled = false;
            }
        }

        protected void Selectsubject_bt_CheckedChanged(object sender, EventArgs e)
        {
            if((Selectsubject_bt.Checked==true))
            {
                NewSubject.Enabled = false;
                BookSubject.Enabled = true;
            }
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            BookInfo book = new BookInfo();
            BookInfoDAO bookInfo = new BookInfoDAO();
            AuthorInfo author = new AuthorInfo();
            AuthorInfoDAO authorDAO = new AuthorInfoDAO();
            BooksubjectInfo booksubject = new BooksubjectInfo();
            BooksubjectInfoDAO booksubjectDAO = new BooksubjectInfoDAO();

            if (TitleInput.Text == "" || Callnumber.Text == "" || RegisterNumber.Text == "" || PageInput.Text == ""
                || Volume.Text == "" || Series.Text == "" || DateImport.Text == "" || Year.Text == "" || Edition.Text == ""
                || Publisher.Text == "" || PublisherLocation.Text == "" || ISBN.Text == "" || Note.Text == ""
                || Keyword.Text == "" || BookCopy.Text == "")
            {
                Message.Text = "Please fill all information";
            }
            else
            {
                if ((NewAuthor_bt.Checked == true))
                {
                    author.setAuthorName(NewAuthor.Text);
                    book.setAuthorID(author.getMaxID());
                    authorDAO.addNewAuthorFromBook(author);
                }
                if ((SelectAuthor_bt.Checked == true))
                {
                    author.setBookTotal(AuthorList.SelectedValue);
                    book.setAuthorID(Convert.ToInt32(AuthorList.SelectedValue));
                    authorDAO.upDateBookTotal(author, book);
                }
                if ((Newsubject_bt.Checked == true))
                {
                    book.setBookSubjectID(booksubject.getMaxID());
                    booksubject.setBooksubjectName(NewSubject.Text);
                    booksubjectDAO.addNewBookSubject(booksubject);
                }
                if ((Selectsubject_bt.Checked == true))
                {
                    booksubject.setBookTotal(BookSubject.SelectedValue);
                    book.setBookSubjectID(Convert.ToInt32(BookSubject.SelectedValue));
                    booksubjectDAO.upDateBookTotal(booksubject, book);
                }

                book.setBorrowTime(0);
                book.setBookCopy(Convert.ToInt32(BookCopy.Text));
                book.setBookStatusID(Convert.ToInt32(BookStatus.SelectedValue));
                book.setBookTypeID(Convert.ToInt32(BookType.SelectedValue));
                book.setCallNumber(Callnumber.Text);
                book.setDateImport(Convert.ToDateTime(DateImport.Text));
                book.setEdition(Convert.ToInt32(Edition.Text));
                book.setISBN(ISBN.Text.ToString());
                book.setKeyword(Keyword.Text.ToString());
                book.setLocation(Location.SelectedItem.Text.ToString());
                book.setNote(Note.Text.ToString());
                book.setPage(Convert.ToInt32(PageInput.Text));
                book.setPublisher(Publisher.Text.ToString());
                book.setPublisherLocation(PublisherLocation.Text.ToString());
                book.setRegisterNumber(RegisterNumber.Text.ToString());
                book.setSeries(Series.Text.ToString());
                book.setSource(Source.SelectedValue);
                book.setTitle(TitleInput.Text.ToString());
                book.setVolume(Convert.ToInt32(Volume.Text));
                book.setYear(Year.Text.ToString());

                bookInfo.addNewBook(book);
                Message.Text = bookInfo.getMessage().ToString();
            }
        }
       
    }

}
