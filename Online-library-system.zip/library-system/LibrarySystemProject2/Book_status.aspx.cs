﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace LibrarySystemProject2
{
    public partial class Book_status : System.Web.UI.Page
    {
        SqlConnection objConn;
        SqlCommand objCmd;
        String strSQL;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();

        protected void Page_Load(object sender, EventArgs e)
        {
            String strConnString;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            if (!Page.IsPostBack)
            {
                BindData();
            }
        }
        protected void Add_Click(object sender, EventArgs e)
        {
            BookStatus bookStatus = new BookStatus();
            BookStatusDAO bookStatusDAO = new BookStatusDAO();

            bookStatus.setBookStatusName(BookStatus.Text.ToString());

            bookStatusDAO.addBookStatus(bookStatus);
            Label2.Text = bookStatusDAO.getMessage();
            //Response.Redirect("Book_status.aspx");
            BindData();
        }
        protected void BindData()
        {
            String strSQL;
            strSQL = "SELECT * FROM Book_Status";

            SqlDataReader dtReader;
            objCmd = new SqlCommand(strSQL, objConn);
            dtReader = objCmd.ExecuteReader();

            dtAdapter.SelectCommand = objCmd;
            //*** BindData to GridView ***//
            myGridView.DataSource = dtReader;
            myGridView.DataBind();

            dtReader.Close();
            dtReader = null;

        }

        protected void Page_UnLoad()
        {
            objConn.Close();
            objConn = null;
        }

        protected void EditCommand(object sender, GridViewEditEventArgs e)
        {
            myGridView.EditIndex = e.NewEditIndex;
            myGridView.ShowFooter = false;
            BindData();
        }

        protected void modCancelCommand(object sender, GridViewCancelEditEventArgs e)
        {
            myGridView.EditIndex = -1;
            myGridView.ShowFooter = false;
            BindData();
        }

        protected void modDeleteCommand(object sender, GridViewDeleteEventArgs e)
        {
            strSQL = "DELETE FROM Book_Status WHERE Bookstatus_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";
            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                Label2.Text = "Delete book status successful";
            }
            catch (Exception ex)
            {
                Label2.Text = "Cannot delete book status";
            }

            myGridView.EditIndex = -1;
            BindData();
        }

        protected void modUpdateCommand(object sender, GridViewUpdateEventArgs e)
        {
            //*** Name ***//
            TextBox txtName = (TextBox)myGridView.Rows[e.RowIndex].FindControl("txtEditName");

            strSQL = "UPDATE Book_Status SET Bookstatus_name = '" + txtName.Text + "'WHERE Bookstatus_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";

            objCmd = new SqlCommand(strSQL, objConn);
            try
            {
                objCmd.ExecuteNonQuery();
                Label2.Text = "Update book status successful";
            }
            catch (Exception ex)
            {
                Label2.Text = "Can't update book status";
            }


            myGridView.EditIndex = -1;
            myGridView.ShowFooter = false;
            BindData();
        }
        protected void myGridView_RowDataBound(Object s, GridViewRowEventArgs e)
        {
            string totalRecord = this.myGridView.Rows.Count.ToString();
            int totalRows = Convert.ToInt16(totalRecord) + 1;
            //*** No. ***//
            Label No = (Label)(e.Row.FindControl("No"));

            if (No != null)
            {
                No.Text = "" + totalRows + "";
            }
        }
    }
}
