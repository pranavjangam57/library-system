﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;
using LibrarySystemProject2.DAO;
using LibrarySystemProject2.Class;

namespace LibrarySystemProject2
{
    public partial class WebForm12 : System.Web.UI.Page
    {

        SqlConnection objConn;
        SqlCommand objCmd;
        String strSQL;
        SqlDataAdapter dtAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();

        protected void Page_Load(object sender, EventArgs e)
        {
            String strConnString;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            if (!Page.IsPostBack)
            {
                BindData();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string ddmembertype = "";
            string ddbooktype = "";
            string sqlmembertype = "";
            string sqlbooktype = "";
            string sqlcheckduplicate = "";
            Boolean checkduplicate = true;
            string membertypeid = "";
            string booktypeid = "";

            ddmembertype = DropDownList1.SelectedItem.Value;
            ddbooktype = DropDownList2.SelectedItem.Value;

            sqlmembertype = "SELECT Membertype_id FROM Member_Type WHERE Membertype_name = '" + ddmembertype + "'";
            //select member type id from membertype table

            SqlDataAdapter da = new SqlDataAdapter(sqlmembertype, objConn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0 && dt.Rows.Count <= 1)
            {
                membertypeid = Convert.ToString(dt.Rows[0]["Membertype_id"]);
            }


            sqlbooktype = "SELECT Booktype_id FROM Book_Type WHERE Booktype_name = '" + ddbooktype + "'";
            //select book type id from membertype table


            SqlDataAdapter da2 = new SqlDataAdapter(sqlbooktype, objConn);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);

            if (dt2.Rows.Count > 0 && dt2.Rows.Count <= 1)
            {
                booktypeid = Convert.ToString(dt2.Rows[0]["Booktype_id"]);
            }



            sqlcheckduplicate = "SELECT Member_Type.Membertype_name, Book_Type.Booktype_name FROM Bookcondition, Member_Type, Book_Type";
            sqlcheckduplicate += " WHERE Member_Type.Membertype_id = Bookcondition.Membertype_id";
            sqlcheckduplicate += " AND Book_Type.Booktype_id = Bookcondition.Booktype_id";

            SqlDataAdapter da3 = new SqlDataAdapter(sqlcheckduplicate, objConn);
            DataTable dt3 = new DataTable();
            da3.Fill(dt3);

            string membertypeget = "";
            string booktypeget = "";
            for (int i = 1; i <= dt3.Rows.Count; i++)
            {
                membertypeget = dt3.Rows[i-1][0].ToString();
                booktypeget = dt3.Rows[i-1][1].ToString();

                if (ddmembertype == membertypeget && ddbooktype == booktypeget)
                {
                    checkduplicate = false;
                }
                
            }







            if (TextBox1.Text != "" && TextBox2.Text != "")
            {
                BookCondition bookcondition = new BookCondition();
                BookConditionDAO bookconditiondao = new BookConditionDAO();


                if (checkduplicate == true)
                {
                    //if (TextBox2.Text.GetType)
                    //{ 
                    try
                    {
                        bookcondition.setMembertypeid(Convert.ToInt16(membertypeid));
                        bookcondition.setBooktypeid(Convert.ToInt16(booktypeid));
                        bookcondition.setBookduration(Convert.ToInt16(TextBox1.Text));
                        bookcondition.setAmountbook(Convert.ToInt16(TextBox2.Text));
                        bookconditiondao.addBookCondition(bookcondition);

                        Label5.Text = bookconditiondao.getMessage();
                        BindData();
                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        Label7.Text = "";
                        //Response.Redirect("borrowcondition.aspx");
                    }
                    catch (Exception)
                    {
                        Label5.Text = "Fail to add book condition, Please input correct type !";
                    }
                }
                else
                {
                    Label7.Text = "This member type and book type has already in the table below";
                    Label5.Text = "";
                }
                
            }
            else
            {
                Label5.Text = "Please fill all information";
                Label7.Text = "";
                //Response.Write("<script language='javascript'>");
                //Response.Write("alert('Please fill all information')");
                //Response.Write("</script>");
            }
        }


        protected void BindData()
        {
            String strSQL;
            strSQL = "SELECT Bookcondition.Bookcondition_id, Member_Type.Membertype_name, Book_Type.Booktype_name, Bookcondition.Borrow_duration, Bookcondition.Amount_book";
            strSQL += " FROM Member_Type, Bookcondition, Book_Type";
            strSQL += " WHERE Member_Type.Membertype_id = Bookcondition.Membertype_id";
            strSQL += " AND Book_Type.Booktype_id = Bookcondition.Booktype_id";
            //strSQL += " AND Bookcondition.Bookcondition_id = ''";

            SqlDataReader dtReader;
            objCmd = new SqlCommand(strSQL, objConn);
            dtReader = objCmd.ExecuteReader();

            dtAdapter.SelectCommand = objCmd;
            //*** BindData to GridView ***//
            myGridView.DataSource = dtReader;
            myGridView.DataBind();

            dtReader.Close();
            dtReader = null;

        }
        protected void Page_UnLoad()
        {
            objConn.Close();
            objConn = null;
        }

        protected void EditCommand(object sender, GridViewEditEventArgs e)
        {
            myGridView.EditIndex = e.NewEditIndex;
            myGridView.ShowFooter = false;
            BindData();
        }

        protected void modCancelCommand(object sender, GridViewCancelEditEventArgs e)
        {
            myGridView.EditIndex = -1;
            myGridView.ShowFooter = false;
            Label5.Text = "";
            BindData();
        }

        protected void modDeleteCommand(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                TextBox1.Text = "";
                TextBox2.Text = "";
                strSQL = "DELETE FROM Bookcondition WHERE Bookcondition_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";
                objCmd = new SqlCommand(strSQL, objConn);
                objCmd.ExecuteNonQuery();
                Label5.Text = "Delete successful !";
                Label7.Text = "";
            }
            catch (Exception ex)
            {
                Label5.Text = "Cannot delete cause of : " + ex;
                Label7.Text = "";

            }

            myGridView.EditIndex = -1;
            BindData();
        }

        protected void modUpdateCommand(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox txtDuration = (TextBox)myGridView.Rows[e.RowIndex].FindControl("txtDuration");
            TextBox txtAmount = (TextBox)myGridView.Rows[e.RowIndex].FindControl("txtAmount");
            strSQL = "UPDATE Bookcondition SET Borrow_duration = '" + txtDuration.Text + "', Amount_book = '" + txtAmount.Text + "' WHERE Bookcondition_id = '" + myGridView.DataKeys[e.RowIndex].Value + "'";

            objCmd = new SqlCommand(strSQL, objConn);
            
                objCmd.ExecuteNonQuery();
                Label5.Text = "Update successful !";
                Label7.Text = "";

            }
            catch (Exception ex)
            {
                Label5.Text = "Cannot update data, Please input correct type !";
                Label7.Text = "";
            }


            myGridView.EditIndex = -1;
            //myGridView.ShowFooter = false;
            BindData();
        }
        protected void myGridView_RowDataBound(Object s, GridViewRowEventArgs e)
        {
            string totalRecord = this.myGridView.Rows.Count.ToString();
            int totalRows = Convert.ToInt16(totalRecord) + 1;
            //*** No. ***//
            Label No = (Label)(e.Row.FindControl("No"));

            if (No != null)
            {
                No.Text = "" + totalRows + "";
            }
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            Label7.Text = "";
        }

        

    }
}
