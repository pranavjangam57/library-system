﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Web.Configuration;

namespace LibrarySystemProject2
{
    public partial class WebForm14 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        void BinddataReturnReport()
        {

            string strConn = "";
            string sqlReport = "";
            Boolean checktext = true;

            strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            if (startdate.Text == "" || enddate.Text == "")
            {
                Label5.Text = "Please fill all information";
                //Response.Write("<script language='javascript'>");
                //Response.Write("alert('Please fill all information')");
                //Response.Write("</script>");
                checktext = false;
                GridView1.Visible = false;
            }
            else
            {
                try
                {
                    string date1 = startdate.Text;
                    string date2 = enddate.Text;
                    string memberinfodd;
                    string memberinfoinput;


                    memberinfodd = DropDownList1.SelectedItem.Value;
                    memberinfoinput = inputbox.Text;


                    if (memberinfodd == "Student ID")
                    {
                        sqlReport = "SELECT History.Register_number, Book_Info.Call_number, Book_Info.Title, History.Date_borrow, History.Date_return";
                        sqlReport += " FROM History, Book_Info, Member_Info";
                        sqlReport += " WHERE (History.Date_return BETWEEN Convert(datetime, '" + date1 + "', 103) AND Convert(datetime, '" + date2 + "', 103))";
                        sqlReport += " AND (Member_Info.Student_id = '" + memberinfoinput + "')";
                        sqlReport += " AND (Book_Info.Register_number=History.Register_number)";
                        sqlReport += " AND (Member_Info.Member_id=History.Member_id)";
                        sqlReport += " ORDER BY Date_return";
                    }
                    else if (memberinfodd == "Member ID")
                    {
                        sqlReport = "SELECT History.Register_number, Book_Info.Call_number, Book_Info.Title, History.Date_borrow, History.Date_return";
                        sqlReport += " FROM History, Book_Info, Member_Info";
                        sqlReport += " WHERE (History.Date_return BETWEEN Convert(datetime, '" + date1 + "', 103) AND Convert(datetime, '" + date2 + "', 103))";
                        sqlReport += " AND (Member_Info.Member_id = '" + memberinfoinput + "')";
                        sqlReport += " AND (Book_Info.Register_number=History.Register_number)";
                        sqlReport += " AND (Member_Info.Member_id=History.Member_id)";
                        sqlReport += " ORDER BY Date_return";
                    }
                    else if (memberinfodd == "Member name")
                    {
                        sqlReport = "SELECT History.Register_number, Book_Info.Call_number, Book_Info.Title, History.Date_borrow, History.Date_return";
                        sqlReport += " FROM History, Book_Info, Member_Info";
                        sqlReport += " WHERE (History.Date_return BETWEEN Convert(datetime, '" + date1 + "', 103) AND Convert(datetime, '" + date2 + "', 103))";
                        sqlReport += " AND (Member_Info.Name = '" + memberinfoinput + "')";
                        sqlReport += " AND (Book_Info.Register_number=History.Register_number)";
                        sqlReport += " AND (Member_Info.Member_id=History.Member_id)";
                        sqlReport += " ORDER BY Date_return";
                    }

                    else if (memberinfodd == "--Select All--")
                    {
                        sqlReport = "SELECT History.Register_number, Book_Info.Call_number, Book_Info.Title, History.Date_borrow, History.Date_return";
                        sqlReport += " FROM History, Book_Info, Member_Info";
                        sqlReport += " WHERE (History.Date_return BETWEEN Convert(datetime, '" + date1 + "', 103) AND Convert(datetime, '" + date2 + "', 103))";
                        sqlReport += " AND (Book_Info.Register_number=History.Register_number)";
                        sqlReport += " AND (Member_Info.Member_id=History.Member_id)";
                        sqlReport += " ORDER BY Date_return";
                    }
                    else
                    {
                        sqlReport = "SELECT History.Register_number, Book_Info.Call_number, Book_Info.Title, History.Date_borrow, History.Date_return";
                        sqlReport += " FROM History, Book_Info, Member_Info";
                        sqlReport += " WHERE (Book_Info.Register_number=History.Register_number)";
                        sqlReport += " AND (Member_Info.Member_id=History.Member_id)";
                        sqlReport += " ORDER BY Date_return";
                    }

                    SqlConnection Conn = new SqlConnection(strConn);
                    Conn.Open();


                    SqlDataAdapter da = new SqlDataAdapter(sqlReport, Conn);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "Report");

                    GridView1.DataSource = ds.Tables["Report"];
                    GridView1.DataBind();

                    Conn.Close();
                }
                catch (Exception er)
                {

                    Label5.Text = "The system can not show the data, cause of incorrect of input, Please try again : " + er;
                    GridView1.Visible = false;
                    checktext = false;
                }
            }

            int gridviewrow = GridView1.Rows.Count;



            if (gridviewrow != 0 && checktext == true)
            {
                GridView1.Visible = true;
                exportexcel.Enabled = true;
                exportword.Enabled = true;
                Label5.Text = "Library Report information during " + changedateformat(startdate.Text) + " to " + changedateformat(enddate.Text);

            }
            else
            {
                exportexcel.Enabled = false;
                exportword.Enabled = false;
                if (startdate.Text == "" || enddate.Text == "")
                {
                    Label5.Text = "Please fill all information";
                }
                else
                {

                    Label5.Text = "Not found your input information";
                }

            }
        }
        protected string changedateformat(string datechange)
        {

            string[] dsplit = datechange.Split('/');
            string monthvalue = "";
            switch (dsplit[1])
            {
                case "01": monthvalue = "January"; break;
                case "02": monthvalue = "February"; break;
                case "03": monthvalue = "March"; break;
                case "04": monthvalue = "April"; break;
                case "05": monthvalue = "May"; break;
                case "06": monthvalue = "June"; break;
                case "07": monthvalue = "July"; break;
                case "08": monthvalue = "August"; break;
                case "09": monthvalue = "September"; break;
                case "10": monthvalue = "October"; break;
                case "11": monthvalue = "November"; break;
                case "12": monthvalue = "December"; break;
            }

            string dfinish = dsplit[0] + " " + monthvalue + " " + dsplit[2];
            return dfinish;
        }


        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BinddataReturnReport();
        }

        void ExportData(string _contentType, string fileName)
        {

            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment;filename=" + fileName);
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = _contentType;
            StringWriter sw = new StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            HtmlForm frm = new HtmlForm();
            frm.Attributes["runat"] = "server";
            frm.Controls.Add(Label5);
            frm.Controls.Add(GridView1);
            Label5.RenderControl(htw);
            GridView1.AllowPaging = false;
            BinddataReturnReport();
            GridView1.RenderControl(htw);
            Response.Write(sw.ToString());
            Response.End();
        }

        void paggingcontrol()
        {
            GridView1.AllowPaging = false;
        }

        protected void viewreport_Click(object sender, EventArgs e)
        {
            BinddataReturnReport();
        }

        protected void exportexcel_Click(object sender, EventArgs e)
        {

            ExportData("application/vnd.xls", "Library_Return_Report.xls");

        }

        protected void exportword_Click(object sender, EventArgs e)
        {

            ExportData("application/vnd.word", "Library_Return_Report.doc");

        }

    }
}
