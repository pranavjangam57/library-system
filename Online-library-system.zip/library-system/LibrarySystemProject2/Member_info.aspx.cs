﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Globalization;

namespace LibrarySystemProject2
{
    public partial class Member_info : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string today = DateTime.Today.ToString("dd/MM/yyyy", new CultureInfo("en-US"));
            Registerdate.Text = today;
        }
        protected void Add_member_Click(object sender, EventArgs e)
        {
            MemberInfo member = new MemberInfo();
            MemberInfoDAO memberDAO = new MemberInfoDAO();
            string CurrentFileName, CurrentPath, CurrentFileName2, CurrentPath2;

            
            CurrentFileName = Picture.FileName;
            CurrentPath = Server.MapPath("~/MemberPic/");

            CurrentFileName2 = "noimage.jpg";
            CurrentPath2 = Server.MapPath("~/MemberPic/noimage.jpg");


            if (Name.Text != "" && Studentcode.Text != "" && Address.Text != "" &&
                Email.Text != "" && Telephone.Text != "" && Mobile.Text != "" &&
                Registerdate.Text != "" && Expiredate.Text != "")
            {


                if (Picture.HasFile)
                {
                    member.setName(Name.Text.ToString());
                    member.setCallname(Callname.SelectedValue);
                    member.setMemberTypeID(Convert.ToInt32(Usertype.SelectedValue));
                    member.setDepartmentID(Convert.ToInt32(Department.SelectedValue));
                    member.setStudentID(Studentcode.Text.ToString());
                    member.setAddress(Address.Text.ToString());
                    member.setPhoneNumber(Telephone.Text.ToString());
                    member.setCreateDate(Registerdate.Text);
                    member.setExpireDate(Expiredate.Text);
                    member.setEmail(Email.Text.ToString());
                    member.setMobileNumber(Mobile.Text.ToString());
                    member.setImage(CurrentFileName.ToString());
                    memberDAO.addNewMember(member);
                    CurrentPath += CurrentFileName;
                    Picture.SaveAs(CurrentPath);
                    //Response.Write(memberDAO.getMessage());
                    Message.Text = memberDAO.getMessage();
                }
                else
                {
                    
                    member.setName(Name.Text.ToString());
                    member.setCallname(Callname.SelectedValue);
                    member.setMemberTypeID(Convert.ToInt32(Usertype.SelectedValue));
                    member.setDepartmentID(Convert.ToInt32(Department.SelectedValue));
                    member.setStudentID(Studentcode.Text.ToString());
                    member.setAddress(Address.Text.ToString());
                    member.setPhoneNumber(Telephone.Text.ToString());
                    member.setCreateDate(string.Format("{0:dd MM yyyy}",Registerdate.Text));
                    member.setExpireDate(string.Format("{0:dd MM yyyy}", Expiredate.Text));
                    member.setEmail(Email.Text.ToString());
                    member.setMobileNumber(Mobile.Text.ToString());
                    member.setImage(CurrentFileName2);
                    //member.setImage(null);
                    //Response.Write(memberDAO.getMessage());
                   
                    memberDAO.addNewMember(member);
                    Message.Text = memberDAO.getMessage();

                }
            }
            else
            {
                Message.Text = "Please fill all box";
            }


        }
    }
}
