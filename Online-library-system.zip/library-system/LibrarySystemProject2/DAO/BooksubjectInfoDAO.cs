﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using LibrarySystemProject2.Class;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2.DAO
{
    public class BooksubjectInfoDAO
    {
        string msg;
        public void addNewBookSubject(BooksubjectInfo booksubject )
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "INSERT INTO Book_Subject (Booksubject_name,Book_total) VALUES ('" + booksubject.getBooksubjectName() + "','" + booksubject.getBookTotal()+1 + "')";
            

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add new book subject successful";
            }
            catch (Exception ex)
            {
                msg = "Can't add new book subject, please try again!";
            }

            objConn.Close();
            objConn = null;
        }
        public void newBookSubject(BooksubjectInfo booksubject)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "INSERT INTO Book_Subject (Booksubject_name,Book_total) VALUES ('" + booksubject.getBooksubjectName() + "',0)";


            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add new book subject successful";
            }
            catch (Exception ex)
            {
                msg = "Can't add new book subject, please try again!";
            }

            objConn.Close();
            objConn = null;
        }
        public void editBookSubject(BooksubjectInfo booksubject)
        {

        }
        public void upDateBookTotal(BooksubjectInfo booksubject,BookInfo book)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "UPDATE Book_Subject SET Book_total = '" + booksubject.getBookTotal() + "' WHERE Booksubject_id = '"+book.getBookSubjectID()+"'";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;
            
            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Update book subject successful";
            }
            catch (Exception ex)
            {
                msg = "Can't update book subject";
            }

            objConn.Close();
            objConn = null;
        }
        public void upDateOldBookTotal(BooksubjectInfo booksubject, BookInfo book)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "UPDATE Book_Subject SET Book_total = '" + book.getOldBooksubjectTotal() + "' WHERE Booksubject_id = '" + book.getOldBooksubjectID() + "'";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Update book subject successful";
            }
            catch (Exception ex)
            {
                msg = "Can't update book subject";
            }

            objConn.Close();
            objConn = null;
        }
        public string getMessage()
        {
            return msg;
        }
    }
}
