﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2
{
    public class BookTypeDAO
    {
        string msg;
        public void addBookType(BookType booktype)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "INSERT INTO Book_Type (Booktype_name) VALUES ('" + booktype.getBookTypeName() + "')";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add new book type successful";
            }
            catch (Exception ex)
            {
                msg = "Can't add new book type, please try again!";
            }

            objConn.Close();
            objConn = null;
        }
        public void editBookType(BookType booktype)
        {
        }
        public bool deleteBookType(BookType booktype)
        {
            return true;
        }
        public string getMessage()
        {
            return msg;
        }
    }
}
