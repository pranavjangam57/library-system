﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Globalization;

namespace LibrarySystemProject2
{
    public class BookInfoDAO
    {
        string msg;
        public void addNewBook(BookInfo book)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            //DateTime dt_my_variable = DateTime.ParseExact(book.getDateImport().ToString(), "dd/MM/yyyy", new CultureInfo("en-US"));
            //string name = "Travel";
            //strSQL = "INSERT INTO Book_Info(Title,Call_number,Register_number,Page,Volume,Series,Year,Edition,Publisher,Publisher_location,ISBN,Note,Keyword,Location,Book_copy,Source)";
            //strSQL += "VALUES ('" + book.getTitle() + "','" + book.getCallNumber() + "','"+book.getRegisterNumber()+"','"+book.getPage()+"','"+book.getVolume()+"','"+book.getSeries()+"','"+book.getYear()+"','"+book.getEdition()+"','"+book.getPublisher()+"','"+book.getPublisherLocation()+"','"+book.getISBN()+"','"+book.getNote()+"','"+book.getKeyword()+"','"+book.getLocation()+"','"+book.getBookCopy()+"','"+book.getSource()+"')";
            //strSQL = "SELECT Book_total FROM Book_Subject WHERE Booksubject_name ='"+name+"'";
            strSQL = "INSERT INTO Book_Info(Title,Call_number,Register_number,Page,Volume,Series,Year,Edition,Publisher,Publisher_location,ISBN,Note,Keyword,Location,Book_copy,Source,Date_import,Bookstatus_id,Author_id,Booktype_id,Booksubject_id,Borrow_time)";
            strSQL += "VALUES ('" + book.getTitle() + "','" + book.getCallNumber() + "','" + book.getRegisterNumber() + "','" + book.getPage() + "','" + book.getVolume() + "','" + book.getSeries() + "','" + book.getYear() + "','" + book.getEdition() + "','" + book.getPublisher() + "','" + book.getPublisherLocation() + "','" + book.getISBN() + "','" + book.getNote() + "','" + book.getKeyword() + "','" + book.getLocation() + "','" + book.getBookCopy() + "','" + book.getSource() + "',Convert(datetime, '" + book.getDateImport() + "', 103),'" + book.getBookStatusID() + "','" + book.getAuthorID() + "','" + book.getBookTypeID() + "','" + book.getBookSubjectID() + "','" + book.getBorrowTime() + "')";
            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add book successful";
                //msg = objCmd.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                msg = "Can't add book, please check data and try again "+ex;
            }

            objConn.Close();
            objConn = null;
        }
        public void editBook(BookInfo book)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            //DateTime dt_my_variable = DateTime.ParseExact(book.getDateImport().ToString(), "dd/MM/yyyy", new CultureInfo("en-US")); 

            strSQL = "UPDATE Book_Info SET Title = '"+book.getTitle()+"', Call_number = '"+book.getCallNumber()+"', Register_number = '"+book.getRegisterNumber()+"'";
            strSQL += ", Page = '" + book.getPage() + "', Volume = '" + book.getVolume() + "', Series = '" + book.getSeries() + "', Date_import = Convert(datetime, '" + book.getDateImport() + "', 103)";
            strSQL += ", Year = '"+book.getYear()+"' , Edition = '"+book.getEdition()+"' , Publisher = '"+book.getPublisher()+"' , Publisher_location = '"+book.getPublisherLocation()+"'";
            strSQL += ", ISBN = '"+book.getISBN()+"' , Note = '"+book.getNote()+"' , Keyword = '"+book.getKeyword()+"' , Location = '"+book.getLocation()+"'";
            strSQL += ", Book_copy = '" + book.getBookCopy() + "'";
            strSQL += ", Source ='"+book.getSource()+"' , Bookstatus_id = '"+book.getBookStatusID()+"' , Author_id = '"+book.getAuthorID()+"'";
            strSQL += ", Booktype_id = '"+book.getBookTypeID()+"' , Booksubject_id = '"+book.getBookSubjectID()+"'";
            strSQL += "WHERE Book_id = '"+book.getBookID()+"'";
            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Edit book information successful !!!";
                //msg = objCmd.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                msg = "Can't edit book information, please check data and try again";
            }

            objConn.Close();
            objConn = null;
        }
        public string getMessage()
        {
            return msg;
        }
    }
}
