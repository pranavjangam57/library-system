﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2
{
    public class BookStatusDAO
    {
        string msg;
        public void addBookStatus(BookStatus bookstatus)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "INSERT INTO Book_Status (Bookstatus_name) VALUES ('" +bookstatus.getBookStatusName()+"')";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add book status successful";
            }
            catch (Exception ex)
            {
                msg = "Cant' add book status, please check data and try again";
            }

            objConn.Close();
            objConn = null;

        }
        public void editBookStatus(BookStatus bookstatus)
        {
        }
        public bool deleteBookStatus(BookStatus bookstatus)
        {
            return true;
        }
        public BookStatus showBookStatus(BookStatus bookstatus)
        {
            return bookstatus;
        }
        public string getMessage()
        {
            return msg;
        }
    }
}
