﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2.DAO
{
    public class MemberTypeDAO
    {
        string msg;
        public void addNewMemberType(MemberType membertype)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "INSERT INTO Member_Type (Membertype_name) VALUES ('"+membertype.getMemberTypeName().Trim()+"')";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add new member type successful";
            }
            catch (Exception ex)
            {
                msg = "Can't add new member type, please try again!";
            }

            objConn.Close();
            objConn = null;
        }
        public void editMemberType(MemberType membertype)
        {
        }
        public bool deleteMemberType(MemberType membertype)
        {
            return true;
        }
        public string getMessage()
        {
            return msg;
        }
    }
}
