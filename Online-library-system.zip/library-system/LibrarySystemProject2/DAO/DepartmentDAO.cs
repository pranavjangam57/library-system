﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using LibrarySystemProject2.Class;
using System.Data.SqlClient;
using System.Web.Configuration;


namespace LibrarySystemProject2.DAO
{
    public class DepartmentDAO
    {
        
        string msg;
        public void addDepartment(Department department)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "INSERT INTO Department (department_name) VALUES ('" + department.getDepartmentName() + "')";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add department successful";
            }
            catch (Exception ex)
            {
                msg = "Add department Error (" + ex.Message + ")";
            }

            objConn.Close();
            objConn = null;
        }
        public void editDepartment(Department department)
        {
        }
        public bool deleteDepartment(Department department)
        {
            return true;
        }
        public string getMessage()
        {
            return msg;
        }
    }
}
