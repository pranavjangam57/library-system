﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;
using LibrarySystemProject2;

namespace CAMT
{
    public class AuthorInfoDAO
    {
            string msg;
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            
        public void addNewAuthorFromBook(AuthorInfo author)
        {

            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            strSQL = "INSERT INTO Author_Info (Author_name, Book_total) VALUES ('" + author.getAuthorName() + "','"+ author.getBookTotal()+1 +"')";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add new author successful";
            }
            catch (Exception ex)
            {
                msg = "Can't add new author, please try again!";
            }

            objConn.Close();
            objConn = null;
        }
        public void addNewAuthor(AuthorInfo author)
        {
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            strSQL = "INSERT INTO Author_Info (Author_name, Book_total) VALUES ('" + author.getAuthorName() + "',0)";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add new author successful";
            }
            catch (Exception ex)
            {
                msg = "Can't add new author, please try again!";
            }

            objConn.Close();
            objConn = null;
        }
        public void upDateBookTotal(AuthorInfo author , BookInfo book)
        {
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            strSQL = "UPDATE Author_Info SET Book_total = '" + author.getBookTotal() + "' WHERE Author_id = '" + book.getAuthorID() + "'";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Update author successful";
            }
            catch (Exception ex)
            {
                msg = "Can't update author, please try again!";
            }

            objConn.Close();
            objConn = null;
        }
        public void upDateOldBookTotal(AuthorInfo author, BookInfo book)
        {
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            strSQL = "UPDATE Author_Info SET Book_total = '" + author.getOldAuthorTotal() + "' WHERE Author_id = '" + author.getOldAuthorID() + "'";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Update author successful";
            }
            catch (Exception ex)
            {
                msg = "Can't update author, please try again!";
            }

            objConn.Close();
            objConn = null;
        }
        public void editAuthor(AuthorInfo author)
        {
        }
        public Boolean deleteAuthor(AuthorInfo author)
        {
            return true;
        }
        public AuthorInfo showAuthor(AuthorInfo author)
        {
            return author;
        }
        public string getMessage()
        {
            return msg;
        }

    }
}
