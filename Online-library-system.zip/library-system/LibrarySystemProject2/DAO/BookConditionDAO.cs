﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using LibrarySystemProject2.Class;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace LibrarySystemProject2.DAO
{
    public class BookConditionDAO
    {
        string msg = "";

        public void addBookCondition(BookCondition bookcondition)
        {

            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "INSERT INTO Bookcondition (Membertype_id, Booktype_id, Borrow_duration, Amount_book)";
            strSQL += " VALUES ('" +bookcondition.getMembertypeid()+ "','" +bookcondition.getBooktypeid()+ "','" +bookcondition.getBookduration()+ "','" +bookcondition.getAmountbook()+ "')";


            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add new book borrow condition success";
            }
            catch (Exception ex)
            {
                msg = "Cannot add new book borrow condition, please try again! ";
            }

            objConn.Close();
            objConn = null;


        }

        public void editBookCondition(BookCondition bookcondition)
        {
        }
        public bool deleteBookCondition(BookCondition bookcondition)
        {
            return true;
        }
        public BookCondition showBookCondition(BookCondition bookcondition)
        {
            return bookcondition;
        }
        public string getMessage()
        {
            return msg;
        }
    }
}
