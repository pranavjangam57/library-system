﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2
{
    public class MemberInfoDAO
    {
        string msg;
        SqlConnection objConn = new SqlConnection();
        SqlCommand objCmd = new SqlCommand();
        String strConnString, strSQL;

        public void addNewMember(MemberInfo member)
        {
            
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "INSERT INTO Member_Info (Callname,Name,Student_id,Address,Email,Phone_number,Mobile_number,Create_date,Expire_date,Image,Membertype_id,Department_id)";
            strSQL += "VALUES ('" + member.getCallname() + "','" + member.getName() + "','" + member.getStudentID() + "','" + member.getAddress() + "','" + member.getEmail() + "','" + member.getPhoneNumber() + "','" + member.getMobileNumber() + "',Convert(datetime, '" + member.getCreateDate() + "', 103),Convert(datetime, '" + member.getExpireDate() + "', 103),'" + member.getImage() + "','" + member.getMemberTypeID() + "','" + member.getDepartmentID() + "')";
            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;



            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add member successful";
            }
            catch (Exception ex)
            {
                msg = "Can't add member, please check data and try again";
            }

            objConn.Close();
            objConn = null;
        }
        public void editMember(MemberInfo member)
        {
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();


            strSQL = member.getSqlQueuery();

            objCmd = new SqlCommand();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Edit member successful";
            }
            catch (Exception ex)
            {
                msg = "Can't edit member, please check data and try again";
            }
            objConn.Close();
            objConn = null;
        }
        public MemberInfo searchMember(MemberInfo member)
        {
            return member;
        }
        public string getMessage()
        {
            return msg;
        }
    }
}
