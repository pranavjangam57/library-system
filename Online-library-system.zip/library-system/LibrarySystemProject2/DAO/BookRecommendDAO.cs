﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2
{
    public class BookRecommendDAO
    {
        public void addRecommendBook(BookRecommend book)
        {
        }
        public BookRecommend showRecommendBook(BookRecommend book)
        {
            return book;
        }
    }
}
