﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;
using LibrarySystemProject2;
using System.Globalization;

namespace LibrarySystemProject2.DAO
{
    public class HolidayInfoDAO
    {
        string msg;
        public void addHoliday(HolidayInfo holiday)
        {
            

            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            strSQL = "INSERT INTO Holiday (Holiday_name,Date) VALUES ('" + holiday.getHolidayName() + "',Convert(datetime, '" + holiday.getDate() + "', 103))";

            objConn.ConnectionString = strConnString;
            objConn.Open();
            objCmd.Connection = objConn;
            objCmd.CommandText = strSQL;
            objCmd.CommandType = CommandType.Text;

            try
            {
                objCmd.ExecuteNonQuery();
                msg = "Add new holiday successful";
            }
            catch (Exception ex)
            {
                msg = "Can't add new holiday, please try again!";
            }

            objConn.Close();
            objConn = null;

        }
        public void editHoliday(HolidayInfo holiday)
        {
        }
        public bool deleteHoliday(HolidayInfo holiday)
        {
            return true;
        }
        public HolidayInfo showHoliday(HolidayInfo holiday)
        {
            return holiday;
        }
        public string getMessage()
        {
            return msg;
        }
        public int checkHoliday(string return_date)
        {
            string today = DateTime.Today.ToString("dd/MM/yyyy", new CultureInfo("en-US"));
            int data = 0;
            SqlConnection objConn = new SqlConnection();
            SqlCommand objCmd = new SqlCommand();
            DataTable dt = new DataTable();
            String strConnString, strSQL;
            strConnString = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            objConn = new SqlConnection(strConnString);
            objConn.Open();

            //*** DataTable ***//
            SqlDataAdapter dtAdapter;
            //strSQL = "SELECT * FROM Book_Info WHERE " + DropDownList1.SelectedValue + " LIKE '%" + this.BookField.Text + "%' AND Bookstatus_id = 1";
            strSQL = "SELECT Date FROM Holiday WHERE (Date >= Convert(datetime, '" + today + "', 103)) AND (Date <= Convert(datetime, '" + return_date + "', 103))";
            //strSQL = "SELECT * FROM Member_Info WHERE Member_id = 3";
            dtAdapter = new SqlDataAdapter(strSQL, objConn);
            dtAdapter.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i <= dt.Rows.Count; i++ )
                {
                    data += 1;
                }
            }
            else
            {
                
            }
            return dt.Rows.Count;
            objConn.Close();
            objConn = null;
        }
    }
}
