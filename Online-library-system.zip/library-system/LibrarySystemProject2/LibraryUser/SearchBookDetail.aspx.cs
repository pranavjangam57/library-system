﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace LibrarySystemProject2.LibraryUser
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            searchbookdetailgridview();
        }
        void searchbookdetailgridview()
        {
            string titletext = "", authortext = "";
            if ((Session["titletext"] != null) && (Session["authortext"] != null))
            {
                titletext = Session["titletext"].ToString();
                authortext = Session["authortext"].ToString();

                //Session.Remove("titletext");
                //Session.Remove("authortext");
            }
            Label14.Text = "Session are " + titletext + " and " + authortext;
            //---------------------------------------------------
            string strConn;
            string sqlBookDetail = "";
            string sqlBookDetailGridview = "";

            strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();


            sqlBookDetail = "SELECT Title, Author_Info.Author_name, Register_number, ISBN, Book_Type.Booktype_name,";
            sqlBookDetail += " Page, Volume, Series, Edition, Publisher, Book_Subject.Booksubject_name, Note, Keyword";
            sqlBookDetail += " FROM Book_Info, Author_Info, Book_Type, Book_Subject";
            sqlBookDetail += " WHERE (Title='" + titletext + "')";
            sqlBookDetail += " AND (Author_Info.Author_name='" + authortext + "')";
            sqlBookDetail += " AND (Book_Subject.Booksubject_id=Book_Info.Booksubject_id)";
            sqlBookDetail += " AND (Book_Type.Booktype_id=Book_Info.Booktype_id)";

            SqlDataAdapter da = new SqlDataAdapter(sqlBookDetail, Conn);
            DataTable dt = new DataTable();
            try
            {

                da.Fill(dt);
            }
            catch (Exception er)
            {
                Label15.Text = "error" + er;
            }

            if (dt.Rows.Count > 0)
            {

                Label2.Text = (string)dt.Rows[0]["Title"];
                Label3.Text = (string)dt.Rows[0]["Author_name"];
                Label5.Text = (string)dt.Rows[0]["ISBN"];
                Label6.Text = (string)dt.Rows[0]["Booktype_name"];
                Label7.Text = Convert.ToString(dt.Rows[0]["Page"]);
                Label8.Text = Convert.ToString(dt.Rows[0]["Volume"]);
                Label9.Text = (string)dt.Rows[0]["Series"];
                Label10.Text = Convert.ToString(dt.Rows[0]["Edition"]);
                Label11.Text = (string)dt.Rows[0]["Publisher"];
                Label12.Text = (string)dt.Rows[0]["Booksubject_name"];
                Label13.Text = (string)dt.Rows[0]["Note"];
                Label14.Text = (string)dt.Rows[0]["Keyword"];

            }
            else
            {
                Label15.Text = "can not show book search detail";
            }

            sqlBookDetailGridview = "SELECT Call_number, Location, Book_Status.Bookstatus_name";
            sqlBookDetailGridview += " FROM Book_Info, Book_Status, Author_Info";
            sqlBookDetailGridview += " WHERE (Title='" + titletext + "')";
            sqlBookDetailGridview += " AND (Author_Info.Author_name='" + authortext + "')";
            sqlBookDetailGridview += " AND (Book_Status.BookStatus_id=Book_Info.BookStatus_id)";


            SqlDataAdapter da2 = new SqlDataAdapter(sqlBookDetailGridview, Conn);
            DataSet ds = new DataSet();
            da2.Fill(ds, "BookDetailSearch");
            GridView1.DataSource = ds.Tables["BookDetailSearch"];
            GridView1.DataBind();
            Conn.Close();
        }
    }
}
