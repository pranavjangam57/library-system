﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace LibrarySystemProject2.LibraryUser
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string bookinfodd = DropDownList1.SelectedItem.Value;
            string searchget = TextBox1.Text;
            if (bookinfodd == "Author" && searchget != "")
            {
                Session["authorsearchget"] = searchget;
                Session["homesearch"] = "true";
                Response.Redirect("SearchBookSimple.aspx");
                
            }
            else if (bookinfodd == "Title" && searchget != "")
            {
                Session["titlesearchget"] = searchget;
                Session["homesearch"] = "true";
                Response.Redirect("SearchBookSimple.aspx");
                
            }
            else if (bookinfodd == "Subject" && searchget != "")
            {
                Session["subjectsearchget"] = searchget;
                Session["homesearch"] = "true";
                Response.Redirect("SearchBookSimple.aspx");
            }
            else if (bookinfodd == "Word" && searchget != "")
            {
                Session["wordsearchget"] = searchget;
                Session["homesearch"] = "true";
                Response.Redirect("SearchBookSimple.aspx");
            }
            else if (bookinfodd == "Call Number" && searchget != "")
            {
                Session["callnumbersearchget"] = searchget;
                Session["homesearch"] = "true";
                Response.Redirect("SearchBookSimple.aspx");
                
            }
            else if (bookinfodd == "ISBN" && searchget != "")
            {
                Session["isbnsearchget"] = searchget;
                Session["homesearch"] = "true";
                Response.Redirect("SearchBookSimple.aspx");
            }
            else
            {
                Label3.Text = "Please type you search in textbox";
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string membername = TextBox2.Text;
            string memberid = TextBox3.Text;

            if (membername != "" && memberid != "")
            {
                Session["membername"] = membername;
                Session["memberid"] = memberid;
                Response.Redirect("SearchMember.aspx");
            }
            else
            {
                Label4.Text = "Please type your name and member ID in textbox";
            }
        }



    }
}
