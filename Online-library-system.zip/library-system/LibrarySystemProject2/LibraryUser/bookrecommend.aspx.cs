﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Globalization;

namespace LibrarySystemProject2.LibraryUser
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Boolean checkerr = true;
            if (TextBox2.Text == "" || TextBox3.Text == "" || TextBox4.Text == "" || memname.Text == "")
            {
                Label9.Text = "Please fill all information in textbox(*)";
            }
            else
            {

                if (TextBox1.Text == "")
                {
                    TextBox1.Text = "---";
                }
                if (isbnnum.Text == "")
                {
                    isbnnum.Text = "---";
                }
                if (memid.Text == "")
                {
                    memid.Text = "---";
                }
                string strConn;

                string current_date = DateTime.Today.ToString("dd/MM/yyyy", new CultureInfo("en-US"));
                strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
                SqlConnection Conn = new SqlConnection(strConn);
                Conn.Open();
                string sqlRecommend;
                sqlRecommend = "INSERT INTO Book_Recommend (Author, Title, Saw, Suggestion, MemberID, RecommendName, ISBN, recommend_date) ";
                sqlRecommend += " VALUES ('" + TextBox1.Text + "',";
                sqlRecommend += "'" + TextBox2.Text + "',";
                sqlRecommend += "'" + TextBox3.Text + "',";
                sqlRecommend += "'" + TextBox4.Text + "',";
                sqlRecommend += "'" + memid.Text + "',";
                sqlRecommend += "'" + memname.Text + "',";
                sqlRecommend += "'" + isbnnum.Text + "',";
                sqlRecommend += " Convert(datetime,'" + current_date + "',103))";
                SqlCommand com = new SqlCommand(sqlRecommend, Conn);
                try
                {
                    com.ExecuteNonQuery();
                    Conn.Close();
                }
                catch (Exception)
                {
                    Label9.Text = "ข้อมูลผิดพลาด กรุณากรอกข้อมูลใหม่ !!";
                    checkerr = false;
                }
                if (checkerr == true)
                {
                    Label9.Visible = false;
                    Label8.Text = "Recommendbook completed !!";
                    if (Label8.Visible == true)
                    {

                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        TextBox3.Text = "";
                        TextBox4.Text = "";
                        memid.Text = "";
                        memname.Text = "";
                        isbnnum.Text = "";
                    }
                }
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            memid.Text = "";
            memname.Text = "";
            isbnnum.Text = "";
        }
    }
}
