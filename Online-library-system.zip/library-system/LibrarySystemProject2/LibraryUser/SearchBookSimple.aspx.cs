﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace LibrarySystemProject2.LibraryUser
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        string authorsearchget = "";
        string titlesearchget = "";
        string subjectsearchget = "";
        string wordsearchget = "";
        string callnumbersearchget = "";
        string isbnsearchget = "";
        




        protected void Page_Load(object sender, EventArgs e)
        {
            //MultiView1.Visible = true;
            MultiView1.SetActiveView(View1);
            //MultiView2.Visible = true;
            if (Session["homesearch"] != null)
            {
                MultiView2.SetActiveView(View8);
                binddatabooksearch();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View2);
            MultiView2.Visible = false;
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View3);
            MultiView2.Visible = false;
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View4);
            MultiView2.Visible = false;
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View5);
            MultiView2.Visible = false;
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View6);
            MultiView2.Visible = false;
        }
        protected void Button6_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View7);
            MultiView2.Visible = false;
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            MultiView2.Visible = false;
            MultiView1.Visible = true;
            MultiView1.SetActiveView(View1);
            Session.Remove("authorsearchget");
            Session.Remove("titlesearchget");
            Session.Remove("subjectsearchget");
            Session.Remove("wordsearchget");
            Session.Remove("callnumbersearchget");
            Session.Remove("isbnsearchget");

            
            
            authorbox.Text = "";
            titlebox.Text = "";
            subjectbox.Text = "";
            keywordbox.Text = "";
            callnumberbox.Text = "";
            isbnbox.Text = "";
             
        }

        


        protected void authorsearch_Click(object sender, EventArgs e)
        {
            authorsearchget = authorbox.Text;
            Session["authorsearchget"] = authorsearchget;
            MultiView2.SetActiveView(View8);
            if (authorsearchget == "")
            {
                message.Text = "Not found book search result !! , try again";
                
            }
            binddatabooksearch();
        }

        protected void authorclear_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View2);
            authorbox.Text = "";
        }

        protected void titlesearch_Click(object sender, EventArgs e)
        {
            titlesearchget = titlebox.Text;
            Session["titlesearchget"] = titlesearchget;
            MultiView2.SetActiveView(View8);
            if (titlesearchget == "")
            {
                message.Text = "Not found book search result !! , try again";
                
            }
            binddatabooksearch();
        }

        protected void titleclear_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View3);
            titlebox.Text = "";
        }

        protected void subjectsearch_Click(object sender, EventArgs e)
        {
            subjectsearchget = subjectbox.Text;
            Session["subjectsearchget"] = subjectsearchget;
            MultiView2.SetActiveView(View8);
            if (subjectsearchget == "")
            {
                message.Text = "Not found book search result !! , try again";
                
            }
            binddatabooksearch();
        }

        protected void subjectclear_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View4);
            subjectbox.Text = "";
        }

        protected void keywordsearch_Click(object sender, EventArgs e)
        {
            wordsearchget = keywordbox.Text;
            Session["wordsearchget"] = wordsearchget;
            MultiView2.SetActiveView(View8);
            if (wordsearchget == "")
            {
                message.Text = "Not found book search result !! , try again";
                
            }
            binddatabooksearch();
        }

        protected void keywordclear_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View5);
            keywordbox.Text = "";
        }

        protected void callnumbersearch_Click(object sender, EventArgs e)
        {
            callnumbersearchget = callnumberbox.Text;
            Session["callnumbersearchget"] = callnumbersearchget;
            MultiView2.SetActiveView(View8);
            if (callnumbersearchget == "")
            {
                message.Text = "Not found book search result !! , try again";
               
            }
            binddatabooksearch();
        }

        protected void callnumberclear_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View6);
            callnumberbox.Text = "";
        }

        protected void isbnsearch_Click(object sender, EventArgs e)
        {
            isbnsearchget = isbnbox.Text;
            Session["isbnsearchget"] = isbnsearchget;
            MultiView2.SetActiveView(View8);
            if (isbnsearchget == "")
            {
                message.Text = "Not found book search result !! , try again";
            
            }
            binddatabooksearch();

        }

        protected void isbnclear_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View7);
            isbnbox.Text = "";
        }

        protected void binddatabooksearch()
        {
            MultiView2.Visible = true;
            string strConn = "";
            string sqlBooksearch = "";
            GridViewB.Visible = true;
            MultiView1.Visible = false;
            Session.Remove("homesearch");

            strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();

            if (Session["authorsearchget"] != null) 
            {
                sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                sqlBooksearch += " FROM Book_Info, Author_Info";
                sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                sqlBooksearch += " AND (Author_Info.Author_name LIKE '%" + Session["authorsearchget"].ToString() + "%')";
                
            
            }
            else if (Session["titlesearchget"] != null)
            {
                sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                sqlBooksearch += " FROM Book_Info, Author_Info";
                sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                sqlBooksearch += " AND (Book_Info.Title LIKE '%" + Session["titlesearchget"].ToString() + "%')";
                
            }
            else if (Session["subjectsearchget"] != null)
            {
                sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                sqlBooksearch += " FROM Book_Info, Author_Info, Book_Subject";
                sqlBooksearch += " WHERE (Book_Info.Booksubject_id=Book_Subject.Booksubject_id)";
                sqlBooksearch += " AND (Book_Subject.Booksubject_name LIKE '%" + Session["subjectsearchget"].ToString() + "%')";
                sqlBooksearch += " AND (Author_Info.Author_id = Book_Info.Author_id)";

                
            }
            else if (Session["wordsearchget"] != null)
            {
                sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                sqlBooksearch += " FROM Book_Info, Author_Info";
                sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                sqlBooksearch += " AND (Book_Info.Keyword LIKE '%" + Session["wordsearchget"].ToString() + "%')";

                
            
            }
            else if (Session["callnumbersearchget"] != null)
            {
                sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                sqlBooksearch += " FROM Book_Info, Author_Info";
                sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                sqlBooksearch += " AND (Book_Info.Call_number LIKE '%" + Session["callnumbersearchget"].ToString() + "%')";

                
            
            }
            else if (Session["isbnsearchget"] != null)
            {
                sqlBooksearch = "SELECT Title, Author_Info.Author_name";
                sqlBooksearch += " FROM Book_Info, Author_Info";
                sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
                sqlBooksearch += " AND (Book_Info.ISBN LIKE '%" + Session["isbnsearchget"].ToString() + "%')";
                
            }
            else
            {
                message.Text = "Not found book search result !! , try again";
                
                GridViewB.Visible = false;
                
            }

            SqlDataAdapter da = new SqlDataAdapter(sqlBooksearch, Conn);

            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds, "BookSearch");
            }

            catch (Exception ex)
            {
                message.Text = "Not found book search result !! , try again " + ex;
               
                
             authorbox.Text = "";
             titlebox.Text = "";
             subjectbox.Text = "";
             keywordbox.Text = "";
             callnumberbox.Text = "";
             isbnbox.Text = "";
              
            }


            GridViewB.DataSource = ds.Tables["BookSearch"];
            GridViewB.DataBind();



            if (GridViewB.Rows.Count == 0)
           {

             message.Text = "Not found book search result !! , try again";
            
             
            authorbox.Text = "";
            titlebox.Text = "";
            subjectbox.Text = "";
            keywordbox.Text = "";
            callnumberbox.Text = "";
            isbnbox.Text = "";
             
           }
           else
          {
           message.Text = "";
           
                
            authorbox.Text = "";
            titlebox.Text = "";
            subjectbox.Text = "";
            keywordbox.Text = "";
            callnumberbox.Text = "";
            isbnbox.Text = "";
             
          }

        
        }


        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridViewB.PageIndex = e.NewPageIndex;
            binddatabooksearch();
        }


        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

            string titletext, authortext;
            //LinkButton titletextb = GridView1.SelectedRow.FindControl("LinkButton1") as LinkButton;

            authortext = GridViewB.SelectedRow.Cells[2].Text;
            titletext = GridViewB.SelectedRow.Cells[1].Text;
            Session["titletext"] = titletext;
            Session["authortext"] = authortext;

            ScriptManager.RegisterStartupScript(this, typeof(string), "OPEN_WINDOW", "window.open( 'SearchBookDetail.aspx',null, 'width = 1280, height = 800,resizable=yes,status=yes,toolbar=yes,menubar=yes,location=yes,scrollbars=yes,directories=yes' );", true);
            
            Session.Timeout = 5;

        }

        



    }
}
