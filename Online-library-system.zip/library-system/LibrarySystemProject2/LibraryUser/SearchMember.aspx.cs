﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace LibrarySystemProject2.LibraryUser
{
    public partial class WebForm5 : System.Web.UI.Page
    {

        string membername = "";
        string memberid = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View1);
            if (Session["membername"] != null && Session["memberid"] != null)
            {
                MultiView1.SetActiveView(View2);
                BinddataMembersearch();
                //membername = Session["membername"].ToString();
                //memberid = Session["memberid"].ToString();
            }
        }




        void BinddataMembersearch()
        {
            MultiView1.SetActiveView(View2);
            if (Session["membername"] == null && Session["memberid"] == null)
            {
                membername = TextBox1.Text;
                memberid = TextBox2.Text;
            }

            else
            {
                membername = Session["membername"].ToString();
                memberid = Session["memberid"].ToString();
                Session.Remove("membername");
                Session.Remove("memberid");
            }
            
            string strConn = "";
            string sqlMembersearch = "";
            string sqlMemberDetailGridview = "";

            string SqlMemberFine = "";
            string SqlMemberFine2 = "";
            int Allfine = 0;
            DateTime calfinedate;
            int finalFine = 0;
            int all_fine_remain = 0;
            DateTime today;


            if (membername != "" && memberid != "")
            {
                strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;

                SqlConnection Conn = new SqlConnection(strConn);
                Conn.Open();


                sqlMembersearch = "SELECT Member_id, Member_type.Membertype_name, Name, Department.Department_name, Student_id, Email, Create_date, Phone_number, Expire_date, Mobile_number, Address, Image";
                sqlMembersearch += " FROM Member_Info, Member_Type, Department";
                sqlMembersearch += " WHERE (Member_id='" + memberid + "')";
                sqlMembersearch += " AND (name='" + membername + "')";
                sqlMembersearch += " AND (Member_Info.Membertype_id=Member_type.MemberType_id)";
                sqlMembersearch += " AND (Member_Info.Department_id=Department.Department_id)";


                SqlDataAdapter da = new SqlDataAdapter(sqlMembersearch, Conn);
                DataTable dt = new DataTable();
                try
                {

                    da.Fill(dt);
                }
                catch (Exception ex)
                {
                    MultiView1.SetActiveView(View3);

                    message.Text = "Not found member search result !! , try again" + ex;

                }

                if (dt.Rows.Count > 0 && dt.Rows.Count <= 1)
                {
                    MultiView1.SetActiveView(View2);

                    Memberpic.ImageUrl = "~/MemberPic/" + (string)dt.Rows[0]["Image"];
                    Label2.Text = Convert.ToString(dt.Rows[0]["Member_id"]);
                    Label3.Text = (string)dt.Rows[0]["Membertype_name"];
                    Label4.Text = (string)dt.Rows[0]["Name"];
                    Label5.Text = (string)dt.Rows[0]["Department_name"];
                    Label6.Text = Convert.ToString(dt.Rows[0]["Student_id"]);
                    Label7.Text = (string)dt.Rows[0]["Email"];
                    Label8.Text = Convert.ToString(dt.Rows[0]["Create_date"]);
                    Label9.Text = (string)dt.Rows[0]["Phone_number"];
                    Label10.Text = Convert.ToString(dt.Rows[0]["Expire_date"]);
                    Label11.Text = (string)dt.Rows[0]["Mobile_number"];
                    Label12.Text = (string)dt.Rows[0]["Address"];

                }
                else
                {
                    MultiView1.SetActiveView(View3);
                    message.Text = "Not found member search result !! , try again";
                }

                sqlMemberDetailGridview = "SELECT Book_Info.Register_number, Book_Info.Call_number, Book_Info.Title, Book_Info.Date_return";
                sqlMemberDetailGridview += " FROM Book_Info, Book_Status";
                sqlMemberDetailGridview += " WHERE Member_id=" + Label2.Text + " AND Book_Status.Bookstatus_name = 'Borrowed' AND Book_Info.Bookstatus_id = Book_Status.Bookstatus_id";


                try
                {
                    SqlDataAdapter da2 = new SqlDataAdapter(sqlMemberDetailGridview, Conn);
                    DataSet ds = new DataSet();
                    da2.Fill(ds, "MemberDetailSearch");
                    GridView2.DataSource = ds.Tables["MemberDetailSearch"];
                    GridView2.DataBind();
                    Label15.Text = "";

                }
                catch (Exception)
                {
                    Label15.Text = "Not found member borrow record !";
                }
                if (GridView2.Rows.Count == 0)
                {
                    Label15.Text = "Not found member borrow record !";
                }


                //show book fine of overdue
                SqlMemberFine = "SELECT Date_return FROM History WHERE Member_id='" + Label2.Text + "' AND Date_return_actual IS NULL ";
                SqlMemberFine2 = "SELECT Fine FROM History WHERE Member_id='" + Label2.Text + "' AND Fine_pay = 'false'";

                SqlDataAdapter da3 = new SqlDataAdapter(SqlMemberFine, Conn);
                DataTable dt3 = new DataTable();
                try
                {

                    da3.Fill(dt3);
                }
                catch (Exception)
                {
                    Label13.Text = "Can't calculate all fine";
                }

                if (dt3.Rows.Count > 0)
                {

                    for (int i = 0; i < dt3.Rows.Count; i++)
                    {
                        today = System.DateTime.Today.Date;
                        string finedate = Convert.ToString(dt3.Rows[i]["Date_return"]);
                        calfinedate = Convert.ToDateTime(finedate);

                        if (today > calfinedate)
                        {
                            Allfine = today.Subtract(calfinedate).Days;
                            Allfine = Allfine * 5;
                            finalFine += Allfine;
                        }
                        else
                        {
                            Allfine = 0;
                            finalFine += Allfine;
                        }
                    }
                }

                else
                {
                    Label13.Text = "Can't calculate all fine2";
                }

                Label13.Text = "" + finalFine + " บาท";  //ค่าปรับคืนเกินเวลา



                //show book fine of arrears
                SqlMemberFine2 = "SELECT Fine FROM History WHERE Member_id='" + Label2.Text + "' AND Fine_pay = 'false'";
                SqlDataAdapter da4 = new SqlDataAdapter(SqlMemberFine2, Conn);
                DataTable dt4 = new DataTable();
                try
                {

                    da4.Fill(dt4);
                }
                catch (Exception)
                {
                    Label16.Text = "Can't calculate all fine";
                }

                if (dt4.Rows.Count > 0)
                {

                    for (int i = 0; i < dt4.Rows.Count; i++)
                    {
                        int fine_remain = Convert.ToInt16(dt4.Rows[i]["Fine"]);
                        all_fine_remain += fine_remain;
                    }
                }

                else
                {
                    Label16.Text = "Can't calculate all fine2";
                }
                Label16.Text = "" + all_fine_remain + " บาท";  //ค่าปรับค้างจ่าย


                Label17.Text = "" + (finalFine + all_fine_remain) + " บาท";  //ค่าปรับทั้งหมด
                Conn.Close();
            }
            else
            {
                MultiView1.SetActiveView(View3);
                message.Text = "Please input both name and Member ID";
            }


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View2);
            BinddataMembersearch();

        }

        protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView2.PageIndex = e.NewPageIndex;
            BinddataMembersearch();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View1);
            TextBox1.Text = "";
            TextBox2.Text = "";
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View1);
            TextBox1.Text = "";
            TextBox2.Text = "";
        }



    }
}
