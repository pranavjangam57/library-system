﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace LibrarySystemProject2.LibraryUser
{
    public partial class WebForm4 : System.Web.UI.Page
    {

        string authorget = "";
        string titleget = "";
        string subjectget = "";
        string locationget = "";
        string yearget = "";
        string publisherget = "";
        string sortby = "";


        protected void Page_Load(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View1);
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View1);
        }

        protected void binddatasearchadvance()
        {
            MultiView1.SetActiveView(View2);
            authorget = TextBox1.Text;
            titleget = TextBox2.Text;
            subjectget = TextBox3.Text;
            locationget = Location.SelectedItem.Value;
            yearget = TextBox5.Text;
            publisherget = TextBox6.Text;
            sortby = DropDownList1.SelectedItem.Value;


            string strConn = "";
            string sqlBooksearch = "";

            strConn = WebConfigurationManager.ConnectionStrings["library_db"].ConnectionString;
            SqlConnection Conn = new SqlConnection(strConn);
            Conn.Open();

            sqlBooksearch = "SELECT Title, Author_Info.Author_name";
            sqlBooksearch += " FROM Book_Info, Author_Info, Book_Subject";
            sqlBooksearch += " WHERE (Book_Info.Author_id=Author_Info.Author_id)";
            sqlBooksearch += " AND (Book_Info.Booksubject_id=Book_Subject.Booksubject_id)";
            sqlBooksearch += " AND (Book_Info.Title LIKE '%" + titleget + "%')";
            sqlBooksearch += " AND (Author_Info.Author_name LIKE '%" + authorget + "%')";
            sqlBooksearch += " AND (Book_Subject.Booksubject_name LIKE '%" + subjectget + "%')";
            sqlBooksearch += " AND (Book_Info.Location LIKE '%" + locationget + "%')";
            sqlBooksearch += " AND (Book_Info.Year LIKE '%" + yearget + "%')";
            sqlBooksearch += " AND (Book_Info.Publisher LIKE '%" + publisherget + "%')";
            sqlBooksearch += " ORDER BY " + sortby;

            SqlDataAdapter da = new SqlDataAdapter(sqlBooksearch, Conn);

            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds, "BookSearch");
            }
            catch (Exception ex)
            {
                message.Text = "Not found book search result !! , try again " + ex;
                GridViewB.Visible = false;
            }

            GridViewB.DataSource = ds.Tables["BookSearch"];
            GridViewB.DataBind();



            if (GridViewB.Rows.Count == 0)
            {

                message.Text = "Not found book search result !! , try again";
                GridViewB.Visible = false;
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox5.Text = "";
                TextBox6.Text = "";
            }
            else
            {
                message.Text = "";
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox5.Text = "";
                TextBox6.Text = "";
            }

        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View2);
            binddatasearchadvance();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
        }


        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridViewB.PageIndex = e.NewPageIndex;
            binddatasearchadvance();
        }


        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View2);
            string titletext, authortext;
            //LinkButton titletextb = GridView1.SelectedRow.FindControl("LinkButton1") as LinkButton;

            authortext = GridViewB.SelectedRow.Cells[2].Text;
            titletext = GridViewB.SelectedRow.Cells[1].Text;
            Session["titletext"] = titletext;
            Session["authortext"] = authortext;

            ScriptManager.RegisterStartupScript(this, typeof(string), "OPEN_WINDOW", "window.open( 'SearchBookDetail.aspx',null, 'width = 1280, height = 800,resizable=yes,status=yes,toolbar=yes,menubar=yes,location=yes,scrollbars=yes,directories=yes' );", true);

            Session.Timeout = 5;

        }




    }
}
